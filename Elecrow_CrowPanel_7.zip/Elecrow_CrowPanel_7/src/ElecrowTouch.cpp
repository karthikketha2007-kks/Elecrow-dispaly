#include "ElecrowTouch.h"
#include "ElecrowDiagnostics.h"

namespace {
constexpr uint16_t GT911_PRODUCT_ID  = 0x8140;  // 4 ASCII bytes, "911"
constexpr uint16_t GT911_CONFIG_VER  = 0x8047;
constexpr uint16_t GT911_X_RES       = 0x8048;  // little endian, 2 bytes
constexpr uint16_t GT911_POINT_INFO  = 0x814E;  // bit7 = buffer ready, bits3..0 = points
constexpr uint16_t GT911_FIRST_POINT = 0x814F;  // 8 bytes per point
constexpr uint8_t  GT911_POINT_SIZE  = 8;

int32_t mapClamp(int32_t v, int32_t in_min, int32_t in_max, int32_t out_max) {
  if (in_max == in_min) return 0;
  int32_t r = (v - in_min) * out_max / (in_max - in_min);
  if (r < 0) r = 0;
  if (r > out_max) r = out_max;
  return r;
}
}  // namespace

const char* elecrowGestureName(ElecrowGesture g) {
  switch (g) {
    case ElecrowGesture::None:       return "none";
    case ElecrowGesture::Tap:        return "tap";
    case ElecrowGesture::LongPress:  return "long-press";
    case ElecrowGesture::SwipeLeft:  return "swipe-left";
    case ElecrowGesture::SwipeRight: return "swipe-right";
    case ElecrowGesture::SwipeUp:    return "swipe-up";
    case ElecrowGesture::SwipeDown:  return "swipe-down";
  }
  return "?";
}

// ---------------------------------------------------------------------------
ElecrowError ElecrowTouch::begin(const ElecrowTouchConfig& cfg, ElecrowBoardRevision rev, ElecrowPCA9557* pca,
                                 uint16_t panel_w, uint16_t panel_h, bool run_reset) {
  _cfg = cfg;
  _rev = rev;
  _pca = pca;
  _panel_w = panel_w;
  _panel_h = panel_h;
  _wire = cfg.wire ? cfg.wire : &Wire;
  _ready = false;

  if (!_cfg.enabled) { _last_error = ElecrowError::None; return ElecrowError::None; }
  if (!startBus()) { _last_error = ElecrowError::I2CInitFailed; return _last_error; }

  if (run_reset && _rev == ElecrowBoardRevision::V3 && _pca) {
    if (!_pca->resetTouchV3()) ELECROW_LOGW("PCA9557 touch reset sequence reported an I2C error");
  }

  if (!probe()) {
    _last_error = ElecrowError::TouchNotFound;
    ELECROW_LOGE("%s", elecrowErrorString(_last_error));
    return _last_error;
  }
  _ready = true;
  _consecutive_errors = 0;
  _last_error = ElecrowError::None;
  return ElecrowError::None;
}

void ElecrowTouch::end() {
  _ready = false;
  forceRelease();
}

bool ElecrowTouch::startBus() {
  // Wire.begin() on an already running bus with the same pins is harmless on
  // Arduino-ESP32 2.x and 3.x; it returns true.
  const bool ok = _wire->begin(_cfg.sda, _cfg.scl, _cfg.i2c_freq);
  if (!ok) ELECROW_LOGE("I2C begin failed (SDA %d, SCL %d)", _cfg.sda, _cfg.scl);
  return ok;
}

bool ElecrowTouch::probe() {
  uint8_t candidates[2] = {ElecrowPins::GT911_ADDR_PRIMARY, ElecrowPins::GT911_ADDR_SECONDARY};
  uint8_t n = 2;
  if (_cfg.address) { candidates[0] = _cfg.address; n = 1; }

  for (uint8_t i = 0; i < n; ++i) {
    _addr = candidates[i];
    uint8_t id[4];
    if (!readRegs(GT911_PRODUCT_ID, id, sizeof(id))) continue;
    memcpy(_product_id, id, 4);
    _product_id[4] = 0;
    for (auto& c : _product_id) if (c && (c < 0x20 || c > 0x7E)) c = '?';

    uint8_t cfgbuf[5];
    if (readRegs(GT911_CONFIG_VER, cfgbuf, sizeof(cfgbuf))) {
      _config_version = cfgbuf[0];
      _ctrl_w = (uint16_t)cfgbuf[1] | ((uint16_t)cfgbuf[2] << 8);
      _ctrl_h = (uint16_t)cfgbuf[3] | ((uint16_t)cfgbuf[4] << 8);
    }
    if (_cfg.use_controller_resolution && _ctrl_w > 0 && _ctrl_h > 0 && _ctrl_w < 4096 && _ctrl_h < 4096) {
      _cfg.raw_x_min = 0;
      _cfg.raw_x_max = _ctrl_w - 1;
      _cfg.raw_y_min = 0;
      _cfg.raw_y_max = _ctrl_h - 1;
      if ((_ctrl_w < _ctrl_h) != (_panel_w < _panel_h)) {
        ELECROW_LOGW("GT911 reports %ux%u but panel is %ux%u - set touch.swap_xy if axes are swapped",
                     _ctrl_w, _ctrl_h, _panel_w, _panel_h);
      }
    }
    writeReg(GT911_POINT_INFO, 0);  // discard stale data
    ELECROW_LOGI("GT911 found at 0x%02X, product \"%s\", config v%u, resolution %ux%u", _addr, _product_id,
                 _config_version, _ctrl_w, _ctrl_h);
    return true;
  }
  _addr = 0;
  return false;
}

bool ElecrowTouch::readRegs(uint16_t reg, uint8_t* buf, size_t len) {
  if (!_wire || !_addr) return false;
  _wire->beginTransmission(_addr);
  _wire->write((uint8_t)(reg >> 8));
  _wire->write((uint8_t)(reg & 0xFF));
  if (_wire->endTransmission(false) != 0) return false;
  if ((size_t)_wire->requestFrom((int)_addr, (int)len) != len) return false;
  for (size_t i = 0; i < len; ++i) buf[i] = (uint8_t)_wire->read();
  return true;
}

bool ElecrowTouch::writeReg(uint16_t reg, uint8_t value) {
  if (!_wire || !_addr) return false;
  _wire->beginTransmission(_addr);
  _wire->write((uint8_t)(reg >> 8));
  _wire->write((uint8_t)(reg & 0xFF));
  _wire->write(value);
  return _wire->endTransmission() == 0;
}

// ---------------------------------------------------------------------------
void ElecrowTouch::setRotation(uint8_t rotation) { _rotation = rotation & 7; }

void ElecrowTouch::setCalibration(uint16_t raw_x_min, uint16_t raw_x_max, uint16_t raw_y_min, uint16_t raw_y_max,
                                  bool swap_xy, bool invert_x, bool invert_y) {
  _cfg.use_controller_resolution = false;
  _cfg.raw_x_min = raw_x_min;
  _cfg.raw_x_max = raw_x_max;
  _cfg.raw_y_min = raw_y_min;
  _cfg.raw_y_max = raw_y_max;
  _cfg.swap_xy = swap_xy;
  _cfg.invert_x = invert_x;
  _cfg.invert_y = invert_y;
}

void ElecrowTouch::mapPoint(uint16_t rx, uint16_t ry, int16_t& x, int16_t& y) const {
  if (_cfg.swap_xy) { uint16_t t = rx; rx = ry; ry = t; }
  // 1) raw -> native panel pixels
  int32_t nx = mapClamp(rx, _cfg.raw_x_min, _cfg.raw_x_max, _panel_w - 1);
  int32_t ny = mapClamp(ry, _cfg.raw_y_min, _cfg.raw_y_max, _panel_h - 1);
  if (_cfg.invert_x) nx = (_panel_w - 1) - nx;
  if (_cfg.invert_y) ny = (_panel_h - 1) - ny;

  // 2) native -> logical, exact inverse of LovyanGFX Panel_FrameBufferBase:
  //    forward: if r in {1,2,4,7} y=H-1-y; if (r&2) x=W-1-x; if (r&1) swap(x,y)
  const uint8_t r = _rotation;
  int32_t lx = nx, ly = ny;
  int32_t lw = _panel_w, lh = _panel_h;
  if (r & 1) { int32_t t = lx; lx = ly; ly = t; lw = _panel_h; lh = _panel_w; }
  if (r & 2) lx = (lw - 1) - lx;
  if ((1u << r) & 0b10010110) ly = (lh - 1) - ly;
  x = (int16_t)lx;
  y = (int16_t)ly;
}

bool ElecrowTouch::readRaw(uint16_t& raw_x, uint16_t& raw_y) {
  if (!_ready) return false;
  uint8_t status;
  if (!readRegs(GT911_POINT_INFO, &status, 1)) { commError(); return false; }
  if (!(status & 0x80) || (status & 0x0F) == 0 || (status & 0x0F) > MAX_POINTS) return false;
  uint8_t p[GT911_POINT_SIZE];
  if (!readRegs(GT911_FIRST_POINT, p, sizeof(p))) { commError(); return false; }
  raw_x = (uint16_t)p[1] | ((uint16_t)p[2] << 8);
  raw_y = (uint16_t)p[3] | ((uint16_t)p[4] << 8);
  writeReg(GT911_POINT_INFO, 0);
  return true;
}

// ---------------------------------------------------------------------------
bool ElecrowTouch::update() {
  if (!_cfg.enabled) return false;
  const uint32_t now = millis();

  if (!_ready) return false;
  if ((uint32_t)(now - _last_poll) < _cfg.poll_interval_ms) {
    // Still evaluate the long-press timer between samples.
    if (_pressed && !_long_fired && !_moved && (now - _press_time) >= _cfg.long_press_ms) {
      _long_fired = true;
      _ev_gesture = ElecrowGesture::LongPress;
      emit(ElecrowTouchEventType::LongPress, ElecrowGesture::LongPress);
    }
    return false;
  }
  _last_poll = now;

  uint8_t status = 0;
  if (!readRegs(GT911_POINT_INFO, &status, 1)) { commError(); return false; }

  if (!(status & 0x80)) {
    // No new frame from the controller yet.
    if (_pressed && _cfg.release_timeout_ms && (now - _last_data) > _cfg.release_timeout_ms) forceRelease();
    handleSample(_pressed);  // keeps long-press timing alive
    return false;
  }

  uint8_t n = status & 0x0F;
  if (n > MAX_POINTS) n = 0;  // invalid frame, treat as release
  if (n) {
    uint8_t buf[MAX_POINTS * GT911_POINT_SIZE];
    if (!readRegs(GT911_FIRST_POINT, buf, (size_t)n * GT911_POINT_SIZE)) { commError(); return false; }
    for (uint8_t i = 0; i < n; ++i) {
      const uint8_t* p = &buf[i * GT911_POINT_SIZE];
      const uint16_t rx = (uint16_t)p[1] | ((uint16_t)p[2] << 8);
      const uint16_t ry = (uint16_t)p[3] | ((uint16_t)p[4] << 8);
      _points[i].id = p[0];
      _points[i].size = (uint16_t)p[5] | ((uint16_t)p[6] << 8);
      mapPoint(rx, ry, _points[i].x, _points[i].y);
    }
  }
  _count = n;
  writeReg(GT911_POINT_INFO, 0);  // acknowledge frame
  _consecutive_errors = 0;
  _last_data = now;
  handleSample(n > 0);
  return true;
}

void ElecrowTouch::handleSample(bool pressed) {
  const uint32_t now = millis();
  if (pressed && !_pressed) {
    _pressed = true;
    _press_time = now;
    _start_x = _last_x = _points[0].x;
    _start_y = _last_y = _points[0].y;
    _moved = false;
    _long_fired = false;
    _ev_pressed = true;
    emit(ElecrowTouchEventType::Press);
  } else if (pressed && _pressed) {
    const int32_t dx = (int32_t)_points[0].x - _start_x;
    const int32_t dy = (int32_t)_points[0].y - _start_y;
    const int32_t tol = _cfg.move_tolerance_px;
    if (dx * dx + dy * dy > tol * tol) _moved = true;
    if (_points[0].x != _last_x || _points[0].y != _last_y) {
      _last_x = _points[0].x;
      _last_y = _points[0].y;
      emit(ElecrowTouchEventType::Move);
    }
    if (!_long_fired && !_moved && (now - _press_time) >= _cfg.long_press_ms) {
      _long_fired = true;
      _ev_gesture = ElecrowGesture::LongPress;
      emit(ElecrowTouchEventType::LongPress, ElecrowGesture::LongPress);
    }
  } else if (!pressed && _pressed) {
    _pressed = false;
    _count = 0;
    _ev_released = true;
    const uint32_t dur = now - _press_time;
    emit(ElecrowTouchEventType::Release);

    const int32_t dx = (int32_t)_last_x - _start_x;
    const int32_t dy = (int32_t)_last_y - _start_y;
    const int32_t adx = dx < 0 ? -dx : dx, ady = dy < 0 ? -dy : dy;
    if (!_long_fired) {
      if ((adx >= _cfg.swipe_min_distance_px || ady >= _cfg.swipe_min_distance_px) && dur <= _cfg.swipe_max_ms) {
        ElecrowGesture g = (adx >= ady) ? (dx > 0 ? ElecrowGesture::SwipeRight : ElecrowGesture::SwipeLeft)
                                        : (dy > 0 ? ElecrowGesture::SwipeDown : ElecrowGesture::SwipeUp);
        _ev_gesture = g;
        emit(ElecrowTouchEventType::Swipe, g);
      } else if (!_moved && dur <= _cfg.tap_max_ms) {
        _ev_gesture = ElecrowGesture::Tap;
        emit(ElecrowTouchEventType::Tap, ElecrowGesture::Tap);
      }
    }
  }
}

void ElecrowTouch::emit(ElecrowTouchEventType type, ElecrowGesture g) {
  if (!_callback) return;
  ElecrowTouchEvent e;
  e.type = type;
  e.gesture = g;
  e.x = _last_x;
  e.y = _last_y;
  if (type == ElecrowTouchEventType::Press || type == ElecrowTouchEventType::Move) {
    e.x = _points[0].x;
    e.y = _points[0].y;
  }
  e.start_x = _start_x;
  e.start_y = _start_y;
  e.duration_ms = millis() - _press_time;
  e.points = _count;
  _callback(e);
}

void ElecrowTouch::forceRelease() {
  if (_pressed) handleSample(false);
  _count = 0;
}

void ElecrowTouch::commError() {
  ++_errors_total;
  _last_error = ElecrowError::TouchCommFailed;
  if (_consecutive_errors < 255) ++_consecutive_errors;
  if (_consecutive_errors == 1) ELECROW_LOGD("GT911 I2C error");
  if (_consecutive_errors >= _cfg.errors_before_recovery &&
      (uint32_t)(millis() - _last_recovery) >= _cfg.recovery_interval_ms) {
    forceRelease();
    recover();
  }
}

bool ElecrowTouch::recover() {
  _last_recovery = millis();
  ++_recoveries;
  ELECROW_LOGW("touch recovery #%u (errors so far: %u)", (unsigned)_recoveries, (unsigned)_errors_total);
  forceRelease();
  _wire->end();
  ElecrowDiagnostics::i2cBusClear(_cfg.sda, _cfg.scl);
  if (!startBus()) { _ready = false; _last_error = ElecrowError::I2CInitFailed; return false; }
  if (_rev == ElecrowBoardRevision::V3 && _pca) _pca->resetTouchV3();
  _ready = probe();
  _consecutive_errors = 0;
  _last_error = _ready ? ElecrowError::None : ElecrowError::TouchNotFound;
  if (!_ready) ELECROW_LOGE("touch recovery failed");
  return _ready;
}

// ---------------------------------------------------------------------------
bool ElecrowTouch::touched() {
  update();
  return _pressed;
}

bool ElecrowTouch::getPoint(int16_t& px, int16_t& py) {
  update();
  if (!_pressed) return false;
  px = _points[0].x;
  py = _points[0].y;
  return true;
}

bool ElecrowTouch::inArea(int16_t ax, int16_t ay, int16_t aw, int16_t ah) const {
  return _pressed && _points[0].x >= ax && _points[0].x < ax + aw && _points[0].y >= ay && _points[0].y < ay + ah;
}

bool ElecrowTouch::justPressed() {
  update();
  const bool v = _ev_pressed;
  _ev_pressed = false;
  return v;
}

bool ElecrowTouch::justReleased() {
  update();
  const bool v = _ev_released;
  _ev_released = false;
  return v;
}

ElecrowGesture ElecrowTouch::gesture() {
  update();
  const ElecrowGesture g = _ev_gesture;
  _ev_gesture = ElecrowGesture::None;
  return g;
}
