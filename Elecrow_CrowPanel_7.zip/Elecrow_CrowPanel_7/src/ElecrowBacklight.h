/**
 * @file ElecrowBacklight.h
 * @brief GPIO2 backlight control (boost LED driver EN pin, active HIGH).
 *
 * brightness 0   -> pin driven LOW (PWM detached)
 * brightness 255 -> pin driven HIGH (PWM detached) = Elecrow's own behaviour
 * 1..254         -> LEDC PWM on the EN pin (optional, cfg.pwm)
 */
#pragma once
#include "ElecrowConfig.h"

class ElecrowBacklight {
public:
  /// Configures the pin and forces the backlight OFF. Safe to call early.
  bool begin(const ElecrowBacklightConfig& cfg);
  void end();

  void setBrightness(uint8_t level);
  uint8_t brightness() const { return _level; }
  void on()  { setBrightness(_last_on_level ? _last_on_level : 255); }
  void off() { setBrightness(0); }
  bool isOn() const { return _level > 0; }

  /// Non-blocking fade. Call update() (ElecrowDisplay::update() does) to progress.
  void fadeTo(uint8_t level, uint16_t duration_ms);
  void update();
  bool fading() const { return _fading; }

private:
  void writeDigital(bool high);
  bool attachPwm();
  void detachPwm();

  ElecrowBacklightConfig _cfg;
  bool _ready = false;
  bool _pwm_attached = false;
  uint8_t _level = 0;
  uint8_t _last_on_level = 255;

  bool _fading = false;
  uint8_t _fade_from = 0, _fade_to = 0;
  uint32_t _fade_start = 0;
  uint16_t _fade_ms = 0;
};
