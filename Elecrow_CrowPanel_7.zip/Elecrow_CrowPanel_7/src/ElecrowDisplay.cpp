#include "ElecrowDisplay.h"
#include <stdarg.h>

bool ElecrowDisplay::begin() { return begin(ElecrowConfig::defaults()); }

bool ElecrowDisplay::fail(ElecrowError e) {
  _error = e;
  _ready = false;
  ELECROW_LOGE("begin() failed: %s", elecrowErrorString(e));
  _backlight.off();  // never light up a panel that is not driven correctly
  return false;
}

bool ElecrowDisplay::begin(const ElecrowConfig& cfg) {
  if (_begun) return _ready;
  _begun = true;
  _cfg = cfg;
  _bg = cfg.clear_color;
  ElecrowDiagnostics::setLog(cfg.log, cfg.log_level);
  ELECROW_LOGI("Elecrow CrowPanel 7.0 driver %s starting", ELECROW_CROWPANEL7_VERSION);

  // 0) Backlight off first (avoids a white flash while the panel starts).
  if (!_backlight.begin(cfg.backlight)) return fail(ElecrowError::InvalidPin);

  // 1) Validate configuration.
  const ElecrowError pin_err = ElecrowDiagnostics::validatePins(cfg);
  if (pin_err != ElecrowError::None) return fail(pin_err);

  // 2) I2C + board revision. The bus is needed for the V3.0 PCA9557 even if
  //    touch is disabled, because the expander also gates the touch reset line.
  TwoWire& wire = cfg.touch.wire ? *cfg.touch.wire : Wire;
  const bool need_i2c = cfg.touch.enabled || cfg.revision != ElecrowBoardRevision::V1_V2;
  bool i2c_ok = false;
  if (need_i2c) {
    i2c_ok = wire.begin(cfg.touch.sda, cfg.touch.scl, cfg.touch.i2c_freq);
    if (!i2c_ok) ELECROW_LOGE("I2C begin failed on SDA %d / SCL %d", cfg.touch.sda, cfg.touch.scl);
  }

  _revision = cfg.revision;
  const bool pca_found = i2c_ok && _pca.begin(wire, cfg.pca9557_address);
  if (_revision == ElecrowBoardRevision::Auto) {
    _revision = pca_found ? ElecrowBoardRevision::V3 : ElecrowBoardRevision::V1_V2;
    ELECROW_LOGI("board revision detected: %s", boardRevisionString());
  } else if (_revision == ElecrowBoardRevision::V3 && !pca_found) {
    ELECROW_LOGW("%s - touch reset sequence skipped", elecrowErrorString(ElecrowError::PCA9557NotFound));
  }

  // 3) V3.0: touch timing control through the PCA9557 BEFORE the RGB bus starts
  //    (same order as Elecrow's LVGL_Arduino7.0 example).
  if (_revision == ElecrowBoardRevision::V3 && pca_found) {
    if (_pca.resetTouchV3()) ELECROW_LOGI("PCA9557 V3.0 touch reset sequence done");
    else ELECROW_LOGW("PCA9557 touch reset sequence had I2C errors");
  }

  // 4) RGB panel + framebuffer (PSRAM checked inside).
  const ElecrowError rgb_err = _rgb.begin(cfg);
  if (rgb_err != ElecrowError::None) return fail(rgb_err);
  gfx().setRotation(cfg.rotation & 7);
  if (cfg.clear_on_begin) gfx().fillScreen(cfg.clear_color);
  gfx().setTextColor(0xFFFF);
  gfx().setTextSize(1);

  // 5) Touch. The PCA9557 reset already ran above, so run_reset = false; the
  //    expander is still handed over so automatic recovery can reset the GT911.
  if (cfg.touch.enabled) {
    ElecrowError t = ElecrowError::I2CInitFailed;
    if (i2c_ok) {
      t = _touch.begin(cfg.touch, _revision, pca_found ? &_pca : nullptr, cfg.width, cfg.height, false);
    }
    _touch.setRotation(cfg.rotation & 7);
    if (t != ElecrowError::None) {
      if (cfg.require_touch) return fail(t);
      ELECROW_LOGW("continuing without touch: %s", elecrowErrorString(t));
    }
  }

  // 6) Backlight on last.
  if (cfg.backlight_on_begin) _backlight.setBrightness(cfg.backlight.initial_brightness);

  _ready = true;
  _error = ElecrowError::None;
  ELECROW_LOGI("ready (%s, touch %s)", boardRevisionString(), _touch.ready() ? "OK" : "not available");
  return true;
}

const char* ElecrowDisplay::boardRevisionString() const {
  switch (_revision) {
    case ElecrowBoardRevision::V1_V2: return "V1.0/V2.0";
    case ElecrowBoardRevision::V3:    return "V3.0";
    default:                          return "unknown";
  }
}

void ElecrowDisplay::update() {
  _backlight.update();
  if (_ready) _touch.update();
}

void ElecrowDisplay::printDiagnostics(Print& out) {
  ElecrowDiagnostics::printSystemInfo(out);
  ElecrowDiagnostics::printPinMap(out, _cfg);
  out.println(F("---- Driver ----"));
  out.printf("Status   : %s (%s)\n", _ready ? "ready" : "NOT ready", errorString());
  out.printf("Board    : %s\n", boardRevisionString());
  if (_rgb.ready()) {
    out.printf("Panel    : %dx%d logical, rotation %u, PCLK %u Hz, ~%.1f Hz, init %u ms\n", (int)width(),
               (int)height(), getRotation(), (unsigned)_cfg.timing.pclk_hz, _rgb.refreshRate(),
               (unsigned)_rgb.initTimeMs());
    out.printf("Frame buf: %p, %u bytes (PSRAM)\n", (void*)_rgb.framebuffer(), (unsigned)_rgb.framebufferBytes());
  }
  out.printf("Backlight: %u/255\n", _backlight.brightness());
  if (_touch.ready()) {
    out.printf("Touch    : GT911 \"%s\" @0x%02X, %ux%u, errors %u, recoveries %u\n", _touch.productId(),
               _touch.address(), _touch.controllerWidth(), _touch.controllerHeight(), (unsigned)_touch.errorCount(),
               (unsigned)_touch.recoveryCount());
  } else {
    out.printf("Touch    : not available (%s)\n", elecrowErrorString(_touch.lastError()));
  }
  if (_cfg.touch.wire) ElecrowDiagnostics::i2cScan(*_cfg.touch.wire, out);
}

// ---- screen ---------------------------------------------------------------------
int32_t ElecrowDisplay::width() { return _rgb.ready() ? gfx().width() : 0; }
int32_t ElecrowDisplay::height() { return _rgb.ready() ? gfx().height() : 0; }

void ElecrowDisplay::setRotation(uint8_t r) {
  r &= 7;
  _cfg.rotation = r;
  if (_rgb.ready()) gfx().setRotation(r);
  _touch.setRotation(r);
}

uint8_t ElecrowDisplay::getRotation() { return _rgb.ready() ? gfx().getRotation() : _cfg.rotation; }

void ElecrowDisplay::fillScreen(uint16_t c) { if (guard()) gfx().fillScreen(c); }
void ElecrowDisplay::startWrite() { if (guard()) gfx().startWrite(); }
void ElecrowDisplay::endWrite() { if (guard()) gfx().endWrite(); }

// ---- text -------------------------------------------------------------------------
void ElecrowDisplay::setTextSize(float s) { if (guard()) gfx().setTextSize(s); }
void ElecrowDisplay::setTextSize(float sx, float sy) { if (guard()) gfx().setTextSize(sx, sy); }
void ElecrowDisplay::setTextColor(uint16_t fg) { if (guard()) gfx().setTextColor(fg); }
void ElecrowDisplay::setTextColor(uint16_t fg, uint16_t bg) { if (guard()) gfx().setTextColor(fg, bg); }
void ElecrowDisplay::setFont(const lgfx::IFont* f) { if (guard()) gfx().setFont(f ? f : &lgfx::fonts::Font0); }
void ElecrowDisplay::setTextDatum(lgfx::textdatum_t d) { if (guard()) gfx().setTextDatum(d); }
void ElecrowDisplay::setTextWrap(bool w) { if (guard()) gfx().setTextWrap(w); }
void ElecrowDisplay::setCursor(int32_t x, int32_t y) { if (guard()) gfx().setCursor(x, y); }

int32_t ElecrowDisplay::drawText(const char* text, int32_t x, int32_t y) {
  if (!guard() || !text) return 0;
  return (int32_t)gfx().drawString(text, x, y);
}

int32_t ElecrowDisplay::drawTextCentered(const char* text, int32_t cx, int32_t cy) {
  if (!guard() || !text) return 0;
  const auto d = gfx().getTextDatum();
  gfx().setTextDatum(lgfx::textdatum_t::middle_center);
  const int32_t w = (int32_t)gfx().drawString(text, cx, cy);
  gfx().setTextDatum(d);
  return w;
}

int32_t ElecrowDisplay::drawTextRight(const char* text, int32_t right_x, int32_t y) {
  if (!guard() || !text) return 0;
  const auto d = gfx().getTextDatum();
  gfx().setTextDatum(lgfx::textdatum_t::top_right);
  const int32_t w = (int32_t)gfx().drawString(text, right_x, y);
  gfx().setTextDatum(d);
  return w;
}

int32_t ElecrowDisplay::drawTextf(int32_t x, int32_t y, const char* fmt, ...) {
  if (!guard() || !fmt) return 0;
  char buf[256];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  return (int32_t)gfx().drawString(buf, x, y);
}

int32_t ElecrowDisplay::textWidth(const char* text) { return guard() && text ? gfx().textWidth(text) : 0; }
int32_t ElecrowDisplay::fontHeight() { return guard() ? gfx().fontHeight() : 0; }

size_t ElecrowDisplay::write(uint8_t c) { return guard() ? gfx().write(c) : 0; }
size_t ElecrowDisplay::write(const uint8_t* buf, size_t len) { return guard() ? gfx().write(buf, len) : 0; }

// ---- primitives -------------------------------------------------------------------
void ElecrowDisplay::drawPixel(int32_t x, int32_t y, uint16_t c) { if (guard()) gfx().drawPixel(x, y, c); }
void ElecrowDisplay::drawLine(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t c) {
  if (guard()) gfx().drawLine(x0, y0, x1, y1, c);
}
void ElecrowDisplay::drawWideLine(int32_t x0, int32_t y0, int32_t x1, int32_t y1, float w, uint16_t c) {
  if (guard()) gfx().drawWideLine(x0, y0, x1, y1, w / 2.0f, c);
}
void ElecrowDisplay::drawFastHLine(int32_t x, int32_t y, int32_t w, uint16_t c) { if (guard()) gfx().drawFastHLine(x, y, w, c); }
void ElecrowDisplay::drawFastVLine(int32_t x, int32_t y, int32_t h, uint16_t c) { if (guard()) gfx().drawFastVLine(x, y, h, c); }
void ElecrowDisplay::drawRectangle(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c) { if (guard()) gfx().drawRect(x, y, w, h, c); }
void ElecrowDisplay::fillRectangle(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t c) { if (guard()) gfx().fillRect(x, y, w, h, c); }
void ElecrowDisplay::drawRoundRectangle(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c) {
  if (guard()) gfx().drawRoundRect(x, y, w, h, r, c);
}
void ElecrowDisplay::fillRoundRectangle(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t c) {
  if (guard()) gfx().fillRoundRect(x, y, w, h, r, c);
}
void ElecrowDisplay::drawCircle(int32_t x, int32_t y, int32_t r, uint16_t c) { if (guard()) gfx().drawCircle(x, y, r, c); }
void ElecrowDisplay::fillCircle(int32_t x, int32_t y, int32_t r, uint16_t c) { if (guard()) gfx().fillCircle(x, y, r, c); }
void ElecrowDisplay::drawEllipse(int32_t x, int32_t y, int32_t rx, int32_t ry, uint16_t c) { if (guard()) gfx().drawEllipse(x, y, rx, ry, c); }
void ElecrowDisplay::fillEllipse(int32_t x, int32_t y, int32_t rx, int32_t ry, uint16_t c) { if (guard()) gfx().fillEllipse(x, y, rx, ry, c); }
void ElecrowDisplay::drawTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, uint16_t c) {
  if (guard()) gfx().drawTriangle(x0, y0, x1, y1, x2, y2, c);
}
void ElecrowDisplay::fillTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, uint16_t c) {
  if (guard()) gfx().fillTriangle(x0, y0, x1, y1, x2, y2, c);
}
void ElecrowDisplay::drawArc(int32_t x, int32_t y, int32_t r0, int32_t r1, float a0, float a1, uint16_t c) {
  if (guard()) gfx().drawArc(x, y, r0, r1, a0, a1, c);
}
void ElecrowDisplay::fillArc(int32_t x, int32_t y, int32_t r0, int32_t r1, float a0, float a1, uint16_t c) {
  if (guard()) gfx().fillArc(x, y, r0, r1, a0, a1, c);
}
void ElecrowDisplay::fillGradientRect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t top, uint16_t bottom) {
  if (!guard() || h <= 0) return;
  gfx().startWrite();
  for (int32_t i = 0; i < h; ++i) {
    gfx().drawFastHLine(x, y + i, w, elecrowBlend565(top, bottom, (uint8_t)(i * 255 / (h > 1 ? h - 1 : 1))));
  }
  gfx().endWrite();
}

// ---- images -------------------------------------------------------------------------
void ElecrowDisplay::drawImage(int32_t x, int32_t y, int32_t w, int32_t h, const uint16_t* data, bool swapped) {
  if (!guard() || !data) return;
  if (swapped) gfx().pushImage(x, y, w, h, reinterpret_cast<const lgfx::swap565_t*>(data));
  else gfx().pushImage(x, y, w, h, reinterpret_cast<const lgfx::rgb565_t*>(data));
}

void ElecrowDisplay::drawImageTransparent(int32_t x, int32_t y, int32_t w, int32_t h, const uint16_t* data,
                                          uint16_t transparent, bool swapped) {
  if (!guard() || !data) return;
  if (swapped) {
    gfx().pushImage(x, y, w, h, reinterpret_cast<const lgfx::swap565_t*>(data),
                    lgfx::swap565_t((uint16_t)((transparent >> 8) | (transparent << 8))));
  } else {
    gfx().pushImage(x, y, w, h, reinterpret_cast<const lgfx::rgb565_t*>(data), lgfx::rgb565_t(transparent));
  }
}

void ElecrowDisplay::drawBitmap(int32_t x, int32_t y, const uint8_t* bmp, int32_t w, int32_t h, uint16_t c) {
  if (guard() && bmp) gfx().drawBitmap(x, y, bmp, w, h, c);
}
void ElecrowDisplay::drawBitmap(int32_t x, int32_t y, const uint8_t* bmp, int32_t w, int32_t h, uint16_t fg, uint16_t bg) {
  if (guard() && bmp) gfx().drawBitmap(x, y, bmp, w, h, fg, bg);
}
void ElecrowDisplay::drawXBitmap(int32_t x, int32_t y, const uint8_t* bmp, int32_t w, int32_t h, uint16_t c) {
  if (guard() && bmp) gfx().drawXBitmap(x, y, bmp, w, h, c);
}
bool ElecrowDisplay::drawJpg(const uint8_t* d, size_t len, int32_t x, int32_t y, float scale) {
  return guard() && d && gfx().drawJpg(d, (uint32_t)len, x, y, 0, 0, 0, 0, scale, scale);
}
bool ElecrowDisplay::drawPng(const uint8_t* d, size_t len, int32_t x, int32_t y, float scale) {
  return guard() && d && gfx().drawPng(d, (uint32_t)len, x, y, 0, 0, 0, 0, scale, scale);
}
bool ElecrowDisplay::drawBmp(const uint8_t* d, size_t len, int32_t x, int32_t y) {
  return guard() && d && gfx().drawBmp(d, (uint32_t)len, x, y);
}
void ElecrowDisplay::drawIcon(ElecrowIcon icon, int32_t cx, int32_t cy, int32_t size, uint16_t color, uint16_t bg,
                              int value) {
  if (guard()) elecrowDrawIcon(gfx(), icon, cx, cy, size, color, bg, value);
}

// ---- touch ----------------------------------------------------------------------------
bool ElecrowDisplay::touched() { return _ready && _touch.touched(); }

bool ElecrowDisplay::touchedIn(int16_t x, int16_t y, int16_t w, int16_t h) {
  if (!_ready) return false;
  _touch.update();
  return _touch.inArea(x, y, w, h);
}
