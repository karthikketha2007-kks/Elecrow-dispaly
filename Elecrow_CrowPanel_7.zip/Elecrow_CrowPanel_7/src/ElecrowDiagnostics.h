/**
 * @file ElecrowDiagnostics.h
 * @brief Logging, memory checks, pin validation and I2C scanning.
 */
#pragma once
#include "ElecrowConfig.h"

/// Snapshot of heap usage.
struct ElecrowMemoryInfo {
  bool     psram_found = false;
  uint32_t psram_total = 0;
  uint32_t psram_free = 0;
  uint32_t psram_largest_block = 0;
  uint32_t internal_free = 0;
  uint32_t internal_min_free = 0;     ///< Low-water mark since boot
  uint32_t internal_largest_block = 0;
  uint32_t dma_free = 0;              ///< Internal DMA-capable RAM
};

class ElecrowDiagnostics {
public:
  // ---- logging ---------------------------------------------------------------
  static void setLog(Print* out, ElecrowLogLevel level) { _out = out; _level = level; }
  static ElecrowLogLevel level() { return _level; }
  static void log(ElecrowLogLevel lvl, const char* fmt, ...) __attribute__((format(printf, 2, 3)));

  // ---- memory ------------------------------------------------------------------
  static ElecrowMemoryInfo memory();
  static void printMemory(Print& out);

  /// True if PSRAM exists and has one free block of at least @p bytes.
  static bool psramHasBlock(uint32_t bytes);

  // ---- pins --------------------------------------------------------------------
  /// True if @p pin can be used as an output on an ESP32-S3-WROOM-1-N4R8.
  /// Rejects non-existent GPIOs, flash pins (26-32) and octal-PSRAM pins (33-37).
  static bool isUsableOutputPin(int8_t pin);

  /// Validates every pin in @p cfg (existence + duplicates). Logs each problem.
  static ElecrowError validatePins(const ElecrowConfig& cfg);

  /// Prints which board peripherals share pins with the display/touch setup.
  static void printPinMap(Print& out, const ElecrowConfig& cfg);

  // ---- I2C ---------------------------------------------------------------------
  /// Scans 0x08..0x77 and prints every responding address with a known name.
  static uint8_t i2cScan(TwoWire& wire, Print& out);
  /// True if a device ACKs at @p addr.
  static bool i2cProbe(TwoWire& wire, uint8_t addr);
  /// Releases a stuck I2C bus (slave holding SDA low) by clocking SCL 9 times.
  /// Must be called while the Wire peripheral is NOT running on these pins.
  static bool i2cBusClear(int8_t sda, int8_t scl);

  // ---- system ------------------------------------------------------------------
  static void printSystemInfo(Print& out);
  static const char* resetReasonString();

private:
  static Print* _out;
  static ElecrowLogLevel _level;
};

#define ELECROW_LOGE(...) ElecrowDiagnostics::log(ElecrowLogLevel::Error, __VA_ARGS__)
#define ELECROW_LOGW(...) ElecrowDiagnostics::log(ElecrowLogLevel::Warning, __VA_ARGS__)
#define ELECROW_LOGI(...) ElecrowDiagnostics::log(ElecrowLogLevel::Info, __VA_ARGS__)
#define ELECROW_LOGD(...) ElecrowDiagnostics::log(ElecrowLogLevel::Debug, __VA_ARGS__)
