#include "ElecrowPCA9557.h"

bool ElecrowPCA9557::begin(TwoWire& wire, uint8_t address) {
  _wire = &wire;
  _addr = address;
  return present();
}

bool ElecrowPCA9557::present() {
  if (!_wire) return false;
  _wire->beginTransmission(_addr);
  return _wire->endTransmission() == 0;
}

bool ElecrowPCA9557::writeReg(uint8_t reg, uint8_t value) {
  if (!_wire) return false;
  _wire->beginTransmission(_addr);
  _wire->write(reg);
  _wire->write(value);
  return _wire->endTransmission() == 0;
}

bool ElecrowPCA9557::readReg(uint8_t reg, uint8_t& value) {
  if (!_wire) return false;
  _wire->beginTransmission(_addr);
  _wire->write(reg);
  if (_wire->endTransmission(false) != 0) return false;
  if (_wire->requestFrom((int)_addr, 1) != 1) return false;
  value = (uint8_t)_wire->read();
  return true;
}

bool ElecrowPCA9557::updateBit(uint8_t reg, uint8_t pin, bool set) {
  if (pin > 7) return false;
  uint8_t v;
  if (!readReg(reg, v)) return false;
  v = set ? (uint8_t)(v | (1u << pin)) : (uint8_t)(v & ~(1u << pin));
  return writeReg(reg, v);
}

bool ElecrowPCA9557::reset() {
  bool ok = writeReg(REG_CONFIG, 0xFF);
  ok &= writeReg(REG_OUTPUT, 0xFF);
  ok &= writeReg(REG_POLARITY, 0x00);
  return ok;
}

bool ElecrowPCA9557::setPinMode(uint8_t pin, bool input) { return updateBit(REG_CONFIG, pin, input); }
bool ElecrowPCA9557::setAllMode(bool input) { return writeReg(REG_CONFIG, input ? 0xFF : 0x00); }
bool ElecrowPCA9557::setPin(uint8_t pin, bool high) { return updateBit(REG_OUTPUT, pin, high); }

bool ElecrowPCA9557::readPin(uint8_t pin, bool& high) {
  uint8_t v;
  if (pin > 7 || !readReg(REG_INPUT, v)) return false;
  high = (v >> pin) & 1u;
  return true;
}

bool ElecrowPCA9557::resetTouchV3() {
  bool ok = reset();
  ok &= setAllMode(false);   // Out.setMode(IO_OUTPUT)
  ok &= setPin(0, false);    // Out.setState(IO0, IO_LOW)
  ok &= setPin(1, false);    // Out.setState(IO1, IO_LOW)
  delay(20);
  ok &= setPin(0, true);     // Out.setState(IO0, IO_HIGH)
  delay(100);
  ok &= setPinMode(1, true); // Out.setMode(IO1, IO_INPUT)
  return ok;
}
