/**
 * @file ElecrowDisplay.h
 * @brief Main entry point of the Elecrow CrowPanel 7.0" (DIS08070H) driver.
 *
 *   #include <ElecrowDisplay.h>
 *   ElecrowDisplay display;
 *
 *   void setup() {
 *     Serial.begin(115200);
 *     if (!display.begin()) { Serial.println(display.errorString()); }
 *     display.clear();
 *     display.drawText("Hello", 100, 100);
 *   }
 *   void loop() {
 *     if (display.touched()) Serial.printf("%d,%d\n", display.touchX(), display.touchY());
 *   }
 *
 * begin() order (taken from Elecrow's V3.0 examples):
 *   backlight forced OFF -> I2C -> board revision detect -> PCA9557 touch reset (V3.0)
 *   -> PSRAM check -> RGB panel + framebuffer -> GT911 -> clear -> backlight ON.
 *
 * Everything the facade does not wrap is still reachable:
 *   display.gfx()       full LovyanGFX device (sprites, fonts, JPEG/PNG, ...)
 *   display.touch()     GT911 driver (multi-touch, gestures, callbacks)
 *   display.backlight() PWM backlight
 */
#pragma once

#include "ElecrowConfig.h"
#include "ElecrowRGB.h"
#include "ElecrowTouch.h"
#include "ElecrowPCA9557.h"
#include "ElecrowBacklight.h"
#include "ElecrowGraphics.h"
#include "ElecrowDiagnostics.h"

class ElecrowDisplay : public Print {
public:
  ElecrowDisplay() = default;
  ElecrowDisplay(const ElecrowDisplay&) = delete;
  ElecrowDisplay& operator=(const ElecrowDisplay&) = delete;

  // ---- lifecycle -----------------------------------------------------------------
  /// Initializes everything with the verified defaults. Returns false on error;
  /// see error() / errorString(). Safe to call once; a second call returns the
  /// first result.
  bool begin();
  bool begin(const ElecrowConfig& cfg);

  /// Call from loop(): polls touch (rate-limited), advances backlight fades.
  /// Never blocks except during automatic touch recovery.
  void update();

  bool ready() const { return _ready; }
  ElecrowError error() const { return _error; }
  const char* errorString() const { return elecrowErrorString(_error); }
  ElecrowBoardRevision boardRevision() const { return _revision; }
  const char* boardRevisionString() const;
  const ElecrowConfig& config() const { return _cfg; }
  bool touchAvailable() const { return _touch.ready(); }

  /// Prints system, memory, pin and peripheral status.
  void printDiagnostics(Print& out = Serial);

  // ---- direct access to sub-drivers --------------------------------------------
  ElecrowLGFX& gfx() { return _rgb.gfx(); }
  ElecrowTouch& touch() { return _touch; }
  ElecrowBacklight& backlight() { return _backlight; }
  ElecrowPCA9557& expander() { return _pca; }
  ElecrowRGB& rgb() { return _rgb; }

  // ---- screen ----------------------------------------------------------------------
  int32_t width();   ///< logical width after rotation
  int32_t height();  ///< logical height after rotation
  void setRotation(uint8_t r);  ///< 0..3 (+4..7 mirrored). Touch follows automatically.
  uint8_t getRotation();

  void setBrightness(uint8_t level) { _backlight.setBrightness(level); }  ///< 0..255
  uint8_t getBrightness() const { return _backlight.brightness(); }

  void setBackgroundColor(uint16_t c) { _bg = c; }
  uint16_t backgroundColor() const { return _bg; }
  void clear() { fillScreen(_bg); }
  void clear(uint16_t color) { fillScreen(color); }
  void fillScreen(uint16_t color);

  /// Writes pending framebuffer changes from the CPU cache to PSRAM. Normally
  /// not needed: LovyanGFX does this after every drawing call (or at
  /// endWrite() when batching with startWrite()/endWrite()).
  void flush() { if (_ready) gfx().display(); }
  void startWrite();
  void endWrite();

  // ---- text ------------------------------------------------------------------------
  void setTextSize(float size);
  void setTextSize(float sx, float sy);
  void setTextColor(uint16_t fg);
  void setTextColor(uint16_t fg, uint16_t bg);  ///< bg filled behind glyphs (no flicker on redraw)
  void setFont(const lgfx::IFont* font);        ///< e.g. &fonts::FreeSansBold18pt7b; nullptr = default
  void setTextDatum(lgfx::textdatum_t datum);   ///< anchor, e.g. lgfx::textdatum_t::middle_center
  void setTextWrap(bool wrap);
  void setCursor(int32_t x, int32_t y);
  int32_t drawText(const char* text, int32_t x, int32_t y);
  int32_t drawText(const String& text, int32_t x, int32_t y) { return drawText(text.c_str(), x, y); }
  int32_t drawTextCentered(const char* text, int32_t cx, int32_t cy);
  int32_t drawTextRight(const char* text, int32_t right_x, int32_t y);
  /// printf-style text at a position (max 255 chars).
  int32_t drawTextf(int32_t x, int32_t y, const char* fmt, ...) __attribute__((format(printf, 4, 5)));
  int32_t textWidth(const char* text);
  int32_t fontHeight();

  /// Print interface: display.print(), println(), printf() at the cursor.
  size_t write(uint8_t c) override;
  size_t write(const uint8_t* buf, size_t len) override;

  // ---- primitives (colours are RGB565) ---------------------------------------
  void drawPixel(int32_t x, int32_t y, uint16_t color);
  void drawLine(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint16_t color);
  void drawWideLine(int32_t x0, int32_t y0, int32_t x1, int32_t y1, float width, uint16_t color);
  void drawFastHLine(int32_t x, int32_t y, int32_t w, uint16_t color);
  void drawFastVLine(int32_t x, int32_t y, int32_t h, uint16_t color);
  void drawRectangle(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t color);
  void fillRectangle(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t color);
  void drawRoundRectangle(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t color);
  void fillRoundRectangle(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r, uint16_t color);
  void drawCircle(int32_t x, int32_t y, int32_t r, uint16_t color);
  void fillCircle(int32_t x, int32_t y, int32_t r, uint16_t color);
  void drawEllipse(int32_t x, int32_t y, int32_t rx, int32_t ry, uint16_t color);
  void fillEllipse(int32_t x, int32_t y, int32_t rx, int32_t ry, uint16_t color);
  void drawTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, uint16_t color);
  void fillTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, uint16_t color);
  /// Arc ring between radii r0..r1, angles in degrees (0 = 3 o'clock, clockwise).
  void drawArc(int32_t x, int32_t y, int32_t r0, int32_t r1, float a0, float a1, uint16_t color);
  void fillArc(int32_t x, int32_t y, int32_t r0, int32_t r1, float a0, float a1, uint16_t color);
  void fillGradientRect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t top, uint16_t bottom);

  // ---- images ------------------------------------------------------------------
  /// RGB565 pixel array, native little-endian (LVGL / most converters).
  /// Set @p byte_swapped for big-endian arrays (TFT_eSPI / some converters).
  void drawImage(int32_t x, int32_t y, int32_t w, int32_t h, const uint16_t* data, bool byte_swapped = false);
  /// Same, skipping pixels equal to @p transparent.
  void drawImageTransparent(int32_t x, int32_t y, int32_t w, int32_t h, const uint16_t* data, uint16_t transparent,
                            bool byte_swapped = false);
  /// 1-bit bitmap, MSB first, rows padded to bytes (Adafruit GFX format).
  void drawBitmap(int32_t x, int32_t y, const uint8_t* bitmap, int32_t w, int32_t h, uint16_t color);
  void drawBitmap(int32_t x, int32_t y, const uint8_t* bitmap, int32_t w, int32_t h, uint16_t fg, uint16_t bg);
  /// 1-bit bitmap, LSB first (XBM format).
  void drawXBitmap(int32_t x, int32_t y, const uint8_t* bitmap, int32_t w, int32_t h, uint16_t color);
  /// Encoded images from memory (flash/PSRAM). scale 1.0 = original size.
  bool drawJpg(const uint8_t* data, size_t len, int32_t x = 0, int32_t y = 0, float scale = 1.0f);
  bool drawPng(const uint8_t* data, size_t len, int32_t x = 0, int32_t y = 0, float scale = 1.0f);
  bool drawBmp(const uint8_t* data, size_t len, int32_t x = 0, int32_t y = 0);
  /// Built-in vector icon (see ElecrowIcon).
  void drawIcon(ElecrowIcon icon, int32_t cx, int32_t cy, int32_t size, uint16_t color, uint16_t bg = 0x0000,
                int value = -1);

  // ---- touch shortcuts (all poll the controller, rate-limited) -----------------
  bool touched();
  int16_t touchX() const { return _touch.x(); }
  int16_t touchY() const { return _touch.y(); }
  bool getTouch(int16_t& x, int16_t& y) { return _touch.getPoint(x, y); }
  uint8_t touchCount() { _touch.update(); return _touch.count(); }
  bool touchedIn(int16_t x, int16_t y, int16_t w, int16_t h);  ///< pressed inside rectangle
  bool justPressed() { return _touch.justPressed(); }
  bool justReleased() { return _touch.justReleased(); }
  ElecrowGesture gesture() { return _touch.gesture(); }
  void onTouch(ElecrowTouchCallback cb) { _touch.onEvent(cb); }

private:
  bool fail(ElecrowError e);
  bool guard() const { return _ready; }

  ElecrowConfig _cfg;
  ElecrowRGB _rgb;
  ElecrowTouch _touch;
  ElecrowPCA9557 _pca;
  ElecrowBacklight _backlight;
  ElecrowBoardRevision _revision = ElecrowBoardRevision::Auto;
  ElecrowError _error = ElecrowError::NotInitialized;
  bool _ready = false;
  bool _begun = false;
  uint16_t _bg = 0x0000;
};
