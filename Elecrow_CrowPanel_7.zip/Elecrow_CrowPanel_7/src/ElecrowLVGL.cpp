// Compiled only when LVGL is available to this build, so projects that do not
// use LVGL are not affected (Arduino IDE / PlatformIO compile every .cpp in src/).
#if __has_include(<lvgl.h>)
#include "ElecrowLVGL.h"
#include <esp_heap_caps.h>

ElecrowDisplay* ElecrowLVGL::_display = nullptr;
ElecrowLVGLConfig ElecrowLVGL::_cfg;
lv_indev_t* ElecrowLVGL::_lv_indev = nullptr;
void* ElecrowLVGL::_buf1 = nullptr;
void* ElecrowLVGL::_buf2 = nullptr;
size_t ElecrowLVGL::_buf_bytes = 0;
bool ElecrowLVGL::_buf_psram = false;
#if LVGL_VERSION_MAJOR >= 9
lv_display_t* ElecrowLVGL::_lv_disp = nullptr;
#else
lv_disp_t* ElecrowLVGL::_lv_disp = nullptr;
uint32_t ElecrowLVGL::_last_tick = 0;
#endif

void* ElecrowLVGL::allocBuffer(size_t bytes, bool& in_psram) {
  void* p = nullptr;
  if (_cfg.prefer_internal_ram) {
    const size_t free_int = heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (free_int > bytes + _cfg.min_internal_free) {
      p = heap_caps_aligned_alloc(64, bytes, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    }
  }
  in_psram = false;
  if (!p) {
    p = heap_caps_aligned_alloc(64, bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    in_psram = p != nullptr;
  }
  return p;
}

bool ElecrowLVGL::begin(ElecrowDisplay& display, const ElecrowLVGLConfig& cfg) {
  if (_display) return true;
  if (!display.ready()) {
    ELECROW_LOGE("ElecrowLVGL::begin(): display.begin() did not succeed (%s)", display.errorString());
    return false;
  }
  _cfg = cfg;
  if (_cfg.mode == ElecrowLVGLRenderMode::Direct && display.getRotation() != 0) {
    ELECROW_LOGW("LVGL Direct mode needs rotation 0 - falling back to Partial mode");
    _cfg.mode = ElecrowLVGLRenderMode::Partial;
  }

  const int32_t w = display.width();
  const int32_t h = display.height();

  // ---- buffers ----
  if (_cfg.mode == ElecrowLVGLRenderMode::Direct) {
    _buf1 = display.rgb().framebuffer();
    _buf2 = nullptr;
    _buf_bytes = display.rgb().framebufferBytes();
    _buf_psram = true;
    if (!_buf1 || display.rgb().framebufferStride() != w) {
      ELECROW_LOGE("LVGL Direct mode: framebuffer not usable");
      return false;
    }
  } else {
    uint16_t lines = _cfg.buffer_lines;
    if (lines < 4) lines = 4;
    if (lines > h) lines = (uint16_t)h;
    _buf_bytes = (size_t)w * lines * 2;
    bool p1 = false, p2 = false;
    _buf1 = allocBuffer(_buf_bytes, p1);
    if (_cfg.double_buffer) _buf2 = allocBuffer(_buf_bytes, p2);
    if (!_buf1 || (_cfg.double_buffer && !_buf2)) {
      ELECROW_LOGE("LVGL draw buffer allocation failed (%u bytes each)", (unsigned)_buf_bytes);
      heap_caps_free(_buf1);
      heap_caps_free(_buf2);
      _buf1 = _buf2 = nullptr;
      return false;
    }
    _buf_psram = p1 || p2;
  }

  if (!lv_is_initialized()) lv_init();

#if LVGL_VERSION_MAJOR >= 9
  lv_tick_set_cb(tickCb);
  _lv_disp = lv_display_create(w, h);
  if (!_lv_disp) { ELECROW_LOGE("lv_display_create failed"); return false; }
  lv_display_set_color_format(_lv_disp, LV_COLOR_FORMAT_RGB565);
  lv_display_set_flush_cb(_lv_disp, flushCb);
  lv_display_set_buffers(_lv_disp, _buf1, _buf2, (uint32_t)_buf_bytes,
                         _cfg.mode == ElecrowLVGLRenderMode::Direct ? LV_DISPLAY_RENDER_MODE_DIRECT
                                                                    : LV_DISPLAY_RENDER_MODE_PARTIAL);
  if (_cfg.enable_touch && display.touchAvailable()) {
    _lv_indev = lv_indev_create();
    lv_indev_set_type(_lv_indev, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(_lv_indev, touchCb);
    lv_indev_set_display(_lv_indev, _lv_disp);
  }
#else
  static lv_disp_draw_buf_t draw_buf;
  static lv_disp_drv_t disp_drv;
  static lv_indev_drv_t indev_drv;
  lv_disp_draw_buf_init(&draw_buf, _buf1, _buf2, (uint32_t)(_buf_bytes / sizeof(lv_color_t)));
  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res = (lv_coord_t)w;
  disp_drv.ver_res = (lv_coord_t)h;
  disp_drv.flush_cb = flushCb;
  disp_drv.draw_buf = &draw_buf;
  disp_drv.direct_mode = _cfg.mode == ElecrowLVGLRenderMode::Direct ? 1 : 0;
  _lv_disp = lv_disp_drv_register(&disp_drv);
  if (!_lv_disp) { ELECROW_LOGE("lv_disp_drv_register failed"); return false; }
  if (_cfg.enable_touch && display.touchAvailable()) {
    lv_indev_drv_init(&indev_drv);
    indev_drv.type = LV_INDEV_TYPE_POINTER;
    indev_drv.read_cb = touchCb;
    indev_drv.disp = _lv_disp;
    _lv_indev = lv_indev_drv_register(&indev_drv);
  }
  _last_tick = millis();
#endif

  _display = &display;
  ELECROW_LOGI("LVGL %d.%d.%d ready: %s mode, %s, %u bytes x %d buffer(s)%s", LVGL_VERSION_MAJOR, LVGL_VERSION_MINOR,
               LVGL_VERSION_PATCH, _cfg.mode == ElecrowLVGLRenderMode::Direct ? "Direct" : "Partial",
               _buf_psram ? "PSRAM" : "internal RAM", (unsigned)_buf_bytes, _buf2 ? 2 : 1,
               _lv_indev ? ", touch registered" : ", no touch");
  return true;
}

uint32_t ElecrowLVGL::handler() {
  if (!_display) return 100;
  _display->backlight().update();
#if LVGL_VERSION_MAJOR < 9
#if !LV_TICK_CUSTOM
  const uint32_t now = millis();
  lv_tick_inc(now - _last_tick);
  _last_tick = now;
#endif
#endif
  return lv_timer_handler();
}

bool ElecrowLVGL::setRotation(uint8_t rotation) {
  if (!_display) return false;
  if (_cfg.mode == ElecrowLVGLRenderMode::Direct && rotation != 0) {
    ELECROW_LOGW("LVGL Direct mode supports rotation 0 only");
    return false;
  }
  _display->setRotation(rotation);
#if LVGL_VERSION_MAJOR >= 9
  lv_display_set_resolution(_lv_disp, _display->width(), _display->height());
#else
  _lv_disp->driver->hor_res = (lv_coord_t)_display->width();
  _lv_disp->driver->ver_res = (lv_coord_t)_display->height();
  lv_disp_drv_update(_lv_disp, _lv_disp->driver);
#endif
  return true;
}

#if LVGL_VERSION_MAJOR >= 9
uint32_t ElecrowLVGL::tickCb() { return (uint32_t)millis(); }

void ElecrowLVGL::flushCb(lv_display_t* disp, const lv_area_t* a, uint8_t* px) {
  const int32_t w = a->x2 - a->x1 + 1;
  const int32_t h = a->y2 - a->y1 + 1;
  auto& g = _display->gfx();
  if (_cfg.mode == ElecrowLVGLRenderMode::Direct) {
    g.display(a->x1, a->y1, w, h);  // write CPU cache back to PSRAM for this area
  } else {
    g.pushImage(a->x1, a->y1, w, h, reinterpret_cast<const lgfx::rgb565_t*>(px));
  }
  lv_display_flush_ready(disp);
}

void ElecrowLVGL::touchCb(lv_indev_t* indev, lv_indev_data_t* data) {
  (void)indev;
  ElecrowTouch& t = _display->touch();
  t.update();
  if (t.isPressed()) {
    data->point.x = t.x();
    data->point.y = t.y();
    data->state = LV_INDEV_STATE_PRESSED;
  } else {
    data->state = LV_INDEV_STATE_RELEASED;
  }
}
#else
void ElecrowLVGL::flushCb(lv_disp_drv_t* drv, const lv_area_t* a, lv_color_t* px) {
  const int32_t w = a->x2 - a->x1 + 1;
  const int32_t h = a->y2 - a->y1 + 1;
  auto& g = _display->gfx();
  if (_cfg.mode == ElecrowLVGLRenderMode::Direct) {
    g.display(a->x1, a->y1, w, h);
  } else {
    g.pushImage(a->x1, a->y1, w, h, reinterpret_cast<const lgfx::rgb565_t*>(px));
  }
  lv_disp_flush_ready(drv);
}

void ElecrowLVGL::touchCb(lv_indev_drv_t* drv, lv_indev_data_t* data) {
  (void)drv;
  ElecrowTouch& t = _display->touch();
  t.update();
  if (t.isPressed()) {
    data->point.x = (lv_coord_t)t.x();
    data->point.y = (lv_coord_t)t.y();
    data->state = LV_INDEV_STATE_PR;
  } else {
    data->state = LV_INDEV_STATE_REL;
  }
}
#endif

#endif  // __has_include(<lvgl.h>)
