/**
 * @file ElecrowConfig.h
 * @brief Run-time configuration and shared types for the CrowPanel 7.0" driver.
 *
 * Usage:
 *   ElecrowConfig cfg = ElecrowConfig::defaults();   // verified board values
 *   cfg.timing.pclk_hz = 15000000;                   // change only with a reason
 *   display.begin(cfg);
 *
 * Every default comes from ElecrowPins.h or from Elecrow's official examples.
 * See docs/HARDWARE.md for where each value was verified.
 */
#pragma once

#include <Arduino.h>
#include <Wire.h>
#include "ElecrowPins.h"

/// Library version (keep in sync with library.properties / library.json).
#define ELECROW_CROWPANEL7_VERSION       "1.0.0"
#define ELECROW_CROWPANEL7_VERSION_MAJOR 1
#define ELECROW_CROWPANEL7_VERSION_MINOR 0
#define ELECROW_CROWPANEL7_VERSION_PATCH 0

/// Hardware revision of the CrowPanel 7.0" main board.
enum class ElecrowBoardRevision : uint8_t {
  Auto = 0,  ///< Detect: PCA9557 answering at 0x18 means V3.0, otherwise V1.0/V2.0
  V1_V2,     ///< V1.0 / V2.0: no PCA9557, GT911 reset tied to EN, INT on GPIO38
  V3         ///< V3.0: GT911 RESET/INT driven through PCA9557 IO0/IO1
};

/// Result / error codes. Every public begin()/init() reports one of these.
enum class ElecrowError : uint8_t {
  None = 0,
  NotInitialized,
  AlreadyInitialized,
  InvalidConfig,
  InvalidPin,
  PinConflict,
  NoPSRAM,
  PSRAMTooSmall,
  FramebufferAllocFailed,
  RGBInitFailed,
  I2CInitFailed,
  PCA9557NotFound,
  TouchNotFound,
  TouchCommFailed,
  OutOfMemory,
  LVGLInitFailed
};

/// Human readable text for an ElecrowError.
const char* elecrowErrorString(ElecrowError err);

/// How chatty the driver is on the log stream.
enum class ElecrowLogLevel : uint8_t { None = 0, Error, Warning, Info, Debug };

/// RGB parallel interface pins (RGB565, 16 data lines).
struct ElecrowRGBPins {
  /// d[0..15] = B0..B4, G0..G5, R0..R4 (LovyanGFX pin_d0..pin_d15 order).
  int8_t data[16] = {
      ElecrowPins::LCD_B0, ElecrowPins::LCD_B1, ElecrowPins::LCD_B2, ElecrowPins::LCD_B3,
      ElecrowPins::LCD_B4, ElecrowPins::LCD_G0, ElecrowPins::LCD_G1, ElecrowPins::LCD_G2,
      ElecrowPins::LCD_G3, ElecrowPins::LCD_G4, ElecrowPins::LCD_G5, ElecrowPins::LCD_R0,
      ElecrowPins::LCD_R1, ElecrowPins::LCD_R2, ElecrowPins::LCD_R3, ElecrowPins::LCD_R4};
  int8_t de    = ElecrowPins::LCD_DE;
  int8_t vsync = ElecrowPins::LCD_VSYNC;
  int8_t hsync = ElecrowPins::LCD_HSYNC;
  int8_t pclk  = ElecrowPins::LCD_PCLK;
};

/**
 * RGB timing. Defaults = Elecrow wiki / V1.0-V2.0 Arduino example (15 MHz).
 * Elecrow's V3.0 examples use the same porches with pclk_hz = 24 MHz, but
 * together with a patched LovyanGFX double-buffer driver; see HARDWARE.md.
 */
struct ElecrowRGBTiming {
  uint32_t pclk_hz        = 15000000;
  bool    hsync_polarity  = 0;
  uint8_t hsync_front_porch = 40;
  uint8_t hsync_pulse_width = 48;
  uint8_t hsync_back_porch  = 40;
  bool    vsync_polarity  = 0;
  uint8_t vsync_front_porch = 1;
  uint8_t vsync_pulse_width = 31;
  uint8_t vsync_back_porch  = 13;
  bool    pclk_active_neg = 1;
  bool    de_idle_high    = 0;
  bool    pclk_idle_high  = 0;

  /// Theoretical refresh rate for a given active area (Hz).
  float refreshRate(uint16_t w, uint16_t h) const {
    const uint32_t ht = (uint32_t)w + hsync_front_porch + hsync_pulse_width + hsync_back_porch;
    const uint32_t vt = (uint32_t)h + vsync_front_porch + vsync_pulse_width + vsync_back_porch;
    return (float)pclk_hz / (float)(ht * vt);
  }
};

/// GT911 capacitive touch configuration.
struct ElecrowTouchConfig {
  bool enabled = true;
  TwoWire* wire = &Wire;            ///< I2C peripheral (Wire or Wire1)
  int8_t sda = ElecrowPins::I2C_SDA;
  int8_t scl = ElecrowPins::I2C_SCL;
  uint32_t i2c_freq = 400000;       ///< GT911 supports 400 kHz fast mode
  uint8_t address = 0;              ///< 0 = auto (try 0x5D then 0x14)
  int8_t int_pin = -1;              ///< Optional GT911 INT GPIO (unused by Elecrow; polling)
  uint16_t poll_interval_ms = 10;   ///< Minimum time between controller reads
  /// Force a release if the controller reports no new frame for this long while
  /// pressed (0 = off). Off by default: a lost release is already handled by
  /// recovery, and a timeout risks false releases during a still long-press.
  uint16_t release_timeout_ms = 0;

  // Calibration: raw controller range -> panel pixels (native, rotation 0).
  bool use_controller_resolution = true;  ///< Read X/Y max from GT911 config (0x8048)
  uint16_t raw_x_min = 0, raw_x_max = ElecrowPins::PANEL_WIDTH - 1;
  uint16_t raw_y_min = 0, raw_y_max = ElecrowPins::PANEL_HEIGHT - 1;
  bool swap_xy  = false;
  bool invert_x = false;
  bool invert_y = false;

  // Gesture thresholds.
  uint16_t long_press_ms = 600;
  uint16_t tap_max_ms = 400;
  uint16_t move_tolerance_px = 12;   ///< Movement still treated as "not moved"
  uint16_t swipe_min_distance_px = 80;
  uint16_t swipe_max_ms = 800;

  // Recovery.
  uint8_t errors_before_recovery = 5;  ///< Consecutive I2C failures before bus/controller recovery
  uint16_t recovery_interval_ms = 1000;///< Minimum time between recovery attempts
};

/// Backlight (GPIO2 -> boost LED driver EN, active high).
struct ElecrowBacklightConfig {
  int8_t pin = ElecrowPins::LCD_BACKLIGHT;
  bool pwm = true;            ///< false = on/off only (exactly what Elecrow's V3.0 code does)
  uint32_t pwm_freq = 300;    ///< Hz. 300 Hz is the value in Elecrow's legacy dimming code
  uint8_t pwm_resolution = 8; ///< bits
  uint8_t pwm_channel = 7;    ///< LEDC channel, only used on Arduino-ESP32 core 2.x
  uint8_t initial_brightness = 255;
};

/// Complete driver configuration.
struct ElecrowConfig {
  uint16_t width  = ElecrowPins::PANEL_WIDTH;
  uint16_t height = ElecrowPins::PANEL_HEIGHT;
  ElecrowRGBPins rgb;
  ElecrowRGBTiming timing;
  ElecrowTouchConfig touch;
  ElecrowBacklightConfig backlight;

  ElecrowBoardRevision revision = ElecrowBoardRevision::Auto;
  uint8_t pca9557_address = ElecrowPins::PCA9557_ADDR;

  uint8_t rotation = 0;           ///< 0..3 (90 deg steps), 4..7 mirrored (LovyanGFX semantics)
  bool clear_on_begin = true;     ///< Fill the framebuffer before the backlight turns on
  uint16_t clear_color = 0x0000;  ///< RGB565
  bool backlight_on_begin = true; ///< Turn the backlight on at the end of begin()

  /// Abort begin() if touch is not found (default: continue without touch).
  bool require_touch = false;

  Print* log = &Serial;
  ElecrowLogLevel log_level = ElecrowLogLevel::Info;

  /// Returns the verified defaults (same as a default-constructed object).
  static ElecrowConfig defaults() { return ElecrowConfig(); }
};
