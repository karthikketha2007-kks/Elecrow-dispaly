#include "ElecrowBacklight.h"
#include "ElecrowDiagnostics.h"

bool ElecrowBacklight::begin(const ElecrowBacklightConfig& cfg) {
  _cfg = cfg;
  if (_cfg.pin < 0) { _ready = false; return true; }  // backlight not controlled
  if (!ElecrowDiagnostics::isUsableOutputPin(_cfg.pin)) {
    ELECROW_LOGE("backlight pin GPIO%d invalid", _cfg.pin);
    return false;
  }
  if (_cfg.pwm_resolution < 1 || _cfg.pwm_resolution > 14) _cfg.pwm_resolution = 8;
  _ready = true;
  writeDigital(false);  // keep dark until the panel is stable
  _level = 0;
  return true;
}

void ElecrowBacklight::end() {
  if (!_ready) return;
  writeDigital(false);
  _level = 0;
  _ready = false;
}

void ElecrowBacklight::writeDigital(bool high) {
  detachPwm();
  pinMode(_cfg.pin, OUTPUT);
  digitalWrite(_cfg.pin, high ? HIGH : LOW);
}

bool ElecrowBacklight::attachPwm() {
  if (_pwm_attached) return true;
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  _pwm_attached = ledcAttach(_cfg.pin, _cfg.pwm_freq, _cfg.pwm_resolution);
#else
  ledcSetup(_cfg.pwm_channel, _cfg.pwm_freq, _cfg.pwm_resolution);
  ledcAttachPin(_cfg.pin, _cfg.pwm_channel);
  _pwm_attached = true;
#endif
  if (!_pwm_attached) ELECROW_LOGW("backlight PWM attach failed, using on/off only");
  return _pwm_attached;
}

void ElecrowBacklight::detachPwm() {
  if (!_pwm_attached) return;
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcDetach(_cfg.pin);
#else
  ledcDetachPin(_cfg.pin);
#endif
  _pwm_attached = false;
}

void ElecrowBacklight::setBrightness(uint8_t level) {
  _fading = false;
  if (!_ready) { _level = level; return; }
  if (level == 0) {
    writeDigital(false);
  } else if (level == 255 || !_cfg.pwm) {
    writeDigital(true);
  } else if (attachPwm()) {
    const uint32_t max_duty = (1UL << _cfg.pwm_resolution) - 1;
    const uint32_t duty = ((uint32_t)level * max_duty + 127) / 255;
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcWrite(_cfg.pin, duty);
#else
    ledcWrite(_cfg.pwm_channel, duty);
#endif
  } else {
    writeDigital(true);
  }
  _level = level;
  if (level) _last_on_level = level;
}

void ElecrowBacklight::fadeTo(uint8_t level, uint16_t duration_ms) {
  if (duration_ms == 0 || !_ready) { setBrightness(level); return; }
  _fade_from = _level;
  _fade_to = level;
  _fade_ms = duration_ms;
  _fade_start = millis();
  _fading = true;
}

void ElecrowBacklight::update() {
  if (!_fading) return;
  const uint32_t t = millis() - _fade_start;
  if (t >= _fade_ms) { setBrightness(_fade_to); return; }
  const int32_t span = (int32_t)_fade_to - (int32_t)_fade_from;
  const uint8_t v = (uint8_t)((int32_t)_fade_from + span * (int32_t)t / (int32_t)_fade_ms);
  const bool keep = true;
  setBrightness(v);   // clears _fading
  _fading = keep;
}
