/**
 * @file ElecrowLVGL.h
 * @brief OPTIONAL LVGL adapter for ElecrowDisplay. Include this header only in
 *        projects that use LVGL; the core driver never depends on LVGL.
 *
 * Supported: LVGL 9.x (tested to compile with 9.1.0 and 9.2.2) and LVGL 8.3.x.
 * Required LVGL configuration (lv_conf.h or -D build flags):
 *   LV_COLOR_DEPTH 16          (both versions)
 *   LV_COLOR_16_SWAP 0         (LVGL 8 only)
 *   LVGL 8: either LV_TICK_CUSTOM 1 with millis(), or leave it 0 (the adapter
 *           then feeds lv_tick_inc() from handler()).
 *
 *   #include <ElecrowDisplay.h>
 *   #include <ElecrowLVGL.h>
 *   ElecrowDisplay display;
 *   void setup() {
 *     display.begin();
 *     ElecrowLVGL::begin(display);           // registers display + touch
 *     lv_obj_t* l = lv_label_create(lv_screen_active());  // LVGL 9
 *     lv_label_set_text(l, "Hello LVGL");
 *   }
 *   void loop() { ElecrowLVGL::handler(); }   // replaces lv_timer_handler()
 *
 * Render modes:
 *   Partial (default): LVGL renders into 1-2 small buffers (internal RAM if
 *     possible, PSRAM fallback); flush copies the area into the framebuffer.
 *     Works with every rotation.
 *   Direct: LVGL renders straight into the scanned-out PSRAM framebuffer;
 *     flush only writes the CPU cache back. No copy, no extra RAM, rotation 0
 *     only; possible tearing during large redraws (single framebuffer).
 */
#pragma once

// Unconditional include on purpose: it lets the Arduino IDE / PlatformIO
// dependency scanners discover LVGL from this header.
#include <lvgl.h>
#include "ElecrowDisplay.h"

#if LVGL_VERSION_MAJOR < 8 || (LVGL_VERSION_MAJOR == 8 && LVGL_VERSION_MINOR < 3)
#error "ElecrowLVGL needs LVGL 8.3.x or 9.x"
#endif
#if LV_COLOR_DEPTH != 16
#error "ElecrowLVGL needs LV_COLOR_DEPTH 16 (RGB565). Set it in lv_conf.h or with -D LV_COLOR_DEPTH=16"
#endif
#if LVGL_VERSION_MAJOR == 8 && defined(LV_COLOR_16_SWAP) && LV_COLOR_16_SWAP != 0
#error "ElecrowLVGL needs LV_COLOR_16_SWAP 0 for the RGB parallel panel"
#endif

enum class ElecrowLVGLRenderMode : uint8_t { Partial = 0, Direct };

struct ElecrowLVGLConfig {
  ElecrowLVGLRenderMode mode = ElecrowLVGLRenderMode::Partial;
  uint16_t buffer_lines = 40;        ///< Partial mode: lines per draw buffer (800*40*2 = 64 KB)
  bool double_buffer = true;         ///< Partial mode: two buffers (render while copying)
  bool prefer_internal_ram = true;   ///< Partial mode: try internal RAM first (faster), PSRAM fallback
  uint32_t min_internal_free = 64 * 1024;  ///< Keep at least this much internal RAM free (Wi-Fi/BLE need it)
  bool enable_touch = true;          ///< Register the GT911 as an LVGL pointer device
};

class ElecrowLVGL {
public:
  /// Calls lv_init() (if not done yet), creates the LVGL display + touch input.
  /// Call AFTER display.begin() and after display.setRotation().
  static bool begin(ElecrowDisplay& display, const ElecrowLVGLConfig& cfg = ElecrowLVGLConfig());

  /// Run LVGL. Call from loop(); returns ms until LVGL wants to run again.
  static uint32_t handler();

  /// Rotates the panel, touch and LVGL resolution together (Partial mode only).
  static bool setRotation(uint8_t rotation);

  static bool ready() { return _display != nullptr; }
  static size_t bufferBytes() { return _buf_bytes; }
  static bool buffersInPSRAM() { return _buf_psram; }
  static ElecrowLVGLRenderMode mode() { return _cfg.mode; }

#if LVGL_VERSION_MAJOR >= 9
  static lv_display_t* lvDisplay() { return _lv_disp; }
  static lv_indev_t* lvInput() { return _lv_indev; }
#else
  static lv_disp_t* lvDisplay() { return _lv_disp; }
  static lv_indev_t* lvInput() { return _lv_indev; }
#endif

private:
  static void* allocBuffer(size_t bytes, bool& in_psram);
#if LVGL_VERSION_MAJOR >= 9
  static void flushCb(lv_display_t* disp, const lv_area_t* area, uint8_t* px);
  static void touchCb(lv_indev_t* indev, lv_indev_data_t* data);
  static uint32_t tickCb();
  static lv_display_t* _lv_disp;
#else
  static void flushCb(lv_disp_drv_t* drv, const lv_area_t* area, lv_color_t* px);
  static void touchCb(lv_indev_drv_t* drv, lv_indev_data_t* data);
  static lv_disp_t* _lv_disp;
  static uint32_t _last_tick;
#endif
  static lv_indev_t* _lv_indev;
  static ElecrowDisplay* _display;
  static ElecrowLVGLConfig _cfg;
  static void* _buf1;
  static void* _buf2;
  static size_t _buf_bytes;
  static bool _buf_psram;
};

