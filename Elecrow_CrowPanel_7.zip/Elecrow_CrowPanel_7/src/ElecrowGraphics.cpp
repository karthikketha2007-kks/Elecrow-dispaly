#include "ElecrowGraphics.h"
#include <math.h>

uint16_t elecrowBlend565(uint16_t a, uint16_t b, uint8_t alpha) {
  const uint32_t ar = (a >> 11) & 0x1F, ag = (a >> 5) & 0x3F, ab = a & 0x1F;
  const uint32_t br = (b >> 11) & 0x1F, bg = (b >> 5) & 0x3F, bb = b & 0x1F;
  const uint32_t r = (ar * (255 - alpha) + br * alpha) / 255;
  const uint32_t g = (ag * (255 - alpha) + bg * alpha) / 255;
  const uint32_t bl = (ab * (255 - alpha) + bb * alpha) / 255;
  return (uint16_t)((r << 11) | (g << 5) | bl);
}

// ---------------------------------------------------------------------------
// Icons. Geometry is expressed in a 24-unit design grid and scaled to `size`.
void elecrowDrawIcon(lgfx::LovyanGFX& g, ElecrowIcon icon, int32_t cx, int32_t cy, int32_t size, uint16_t c,
                     uint16_t bg, int value) {
  const float s = size / 24.0f;
  auto X = [&](float u) { return (int32_t)lroundf(cx + (u - 12.0f) * s); };
  auto Y = [&](float u) { return (int32_t)lroundf(cy + (u - 12.0f) * s); };
  auto L = [&](float u) { int32_t v = (int32_t)lroundf(u * s); return v < 1 ? 1 : v; };
  const int32_t t = L(2);  // stroke thickness

  auto thickLine = [&](float x0, float y0, float x1, float y1) {
    g.drawWideLine(X(x0), Y(y0), X(x1), Y(y1), t / 2.0f + 0.5f, c);
  };

  g.startWrite();
  switch (icon) {
    case ElecrowIcon::Home:
      g.fillTriangle(X(12), Y(3), X(2), Y(12), X(22), Y(12), c);
      g.fillRect(X(5), Y(11), L(14), L(10), c);
      g.fillRect(X(10), Y(15), L(4), L(6), bg);
      break;
    case ElecrowIcon::Settings: {
      for (int i = 0; i < 8; ++i) {
        const float a = i * (float)M_PI / 4.0f;
        const float ca = cosf(a), sa = sinf(a);
        g.drawWideLine(X(12 + ca * 6), Y(12 + sa * 6), X(12 + ca * 10.5f), Y(12 + sa * 10.5f), L(1.8f), c);
      }
      g.fillCircle(cx, cy, L(7.5f), c);
      g.fillCircle(cx, cy, L(3), bg);
      break;
    }
    case ElecrowIcon::WiFi:
      g.fillArc(X(12), Y(20), L(15), L(17.5f), 225, 315, c);
      g.fillArc(X(12), Y(20), L(9.5f), L(12), 225, 315, c);
      g.fillArc(X(12), Y(20), L(4), L(6.5f), 225, 315, c);
      g.fillCircle(X(12), Y(20), L(1.6f), c);
      break;
    case ElecrowIcon::Battery: {
      g.drawRoundRect(X(2), Y(7), L(18), L(10), L(2), c);
      g.drawRoundRect(X(2) + 1, Y(7) + 1, L(18) - 2, L(10) - 2, L(2), c);
      g.fillRect(X(20), Y(10), L(2.5f), L(4), c);
      int lvl = value < 0 ? 100 : (value > 100 ? 100 : value);
      const uint16_t fc = lvl <= 15 ? ElecrowColor::RED : (lvl <= 35 ? ElecrowColor::ORANGE : c);
      const int32_t wmax = L(14);
      g.fillRect(X(4), Y(9), wmax * lvl / 100, L(6), fc);
      break;
    }
    case ElecrowIcon::Check:
      thickLine(4, 13, 10, 19);
      thickLine(10, 19, 20, 6);
      break;
    case ElecrowIcon::Close:
      thickLine(5, 5, 19, 19);
      thickLine(19, 5, 5, 19);
      break;
    case ElecrowIcon::ArrowLeft:
      g.fillTriangle(X(3), Y(12), X(12), Y(4), X(12), Y(20), c);
      g.fillRect(X(11), Y(9), L(10), L(6), c);
      break;
    case ElecrowIcon::ArrowRight:
      g.fillTriangle(X(21), Y(12), X(12), Y(4), X(12), Y(20), c);
      g.fillRect(X(3), Y(9), L(10), L(6), c);
      break;
    case ElecrowIcon::ArrowUp:
      g.fillTriangle(X(12), Y(3), X(4), Y(12), X(20), Y(12), c);
      g.fillRect(X(9), Y(11), L(6), L(10), c);
      break;
    case ElecrowIcon::ArrowDown:
      g.fillTriangle(X(12), Y(21), X(4), Y(12), X(20), Y(12), c);
      g.fillRect(X(9), Y(3), L(6), L(10), c);
      break;
    case ElecrowIcon::Plus:
      g.fillRect(X(4), Y(10.5f), L(16), L(3), c);
      g.fillRect(X(10.5f), Y(4), L(3), L(16), c);
      break;
    case ElecrowIcon::Minus:
      g.fillRect(X(4), Y(10.5f), L(16), L(3), c);
      break;
    case ElecrowIcon::Power:
      g.fillArc(X(12), Y(13), L(7), L(9.2f), -50, 230, c);
      g.fillRect(X(10.9f), Y(2), L(2.2f), L(10), c);
      break;
    case ElecrowIcon::Thermometer:
      g.fillRoundRect(X(9.5f), Y(2), L(5), L(14), L(2.5f), c);
      g.fillCircle(X(12), Y(18), L(4.5f), c);
      g.fillRoundRect(X(11), Y(4), L(2), L(11), L(1), bg);
      g.fillCircle(X(12), Y(18), L(2.5f), bg);
      g.fillRect(X(11), Y(9), L(2), L(8), ElecrowColor::RED);
      g.fillCircle(X(12), Y(18), L(2.2f), ElecrowColor::RED);
      break;
    case ElecrowIcon::Drop:
      g.fillTriangle(X(12), Y(2), X(6), Y(13), X(18), Y(13), c);
      g.fillCircle(X(12), Y(15), L(6.2f), c);
      break;
    case ElecrowIcon::Bell:
      g.fillCircle(X(12), Y(10), L(6), c);
      g.fillRect(X(6), Y(10), L(12), L(6), c);
      g.fillTriangle(X(4), Y(18), X(6), Y(14), X(6), Y(18), c);
      g.fillTriangle(X(20), Y(18), X(18), Y(14), X(18), Y(18), c);
      g.fillRect(X(4), Y(16), L(16), L(2), c);
      g.fillCircle(X(12), Y(20), L(2), c);
      break;
    case ElecrowIcon::Info:
      g.fillCircle(cx, cy, L(10), c);
      g.fillRect(X(10.8f), Y(10), L(2.4f), L(8), bg);
      g.fillCircle(X(12), Y(6.5f), L(1.5f), bg);
      break;
    case ElecrowIcon::Warning:
      g.fillTriangle(X(12), Y(2), X(1.5f), Y(21), X(22.5f), Y(21), c);
      g.fillRect(X(10.8f), Y(8), L(2.4f), L(7), bg);
      g.fillCircle(X(12), Y(18), L(1.4f), bg);
      break;
    case ElecrowIcon::Menu:
      g.fillRect(X(3), Y(5), L(18), L(2.5f), c);
      g.fillRect(X(3), Y(10.75f), L(18), L(2.5f), c);
      g.fillRect(X(3), Y(16.5f), L(18), L(2.5f), c);
      break;
    case ElecrowIcon::Lightbulb:
      g.fillCircle(X(12), Y(9), L(7), c);
      g.fillRect(X(9), Y(14), L(6), L(4), c);
      g.fillRect(X(9.5f), Y(19), L(5), L(1.5f), c);
      g.fillRect(X(10.5f), Y(21), L(3), L(1.5f), c);
      break;
  }
  g.endWrite();
}

// ---------------------------------------------------------------------------
void ElecrowButton::setLabel(const char* label) {
  strncpy(_label, label ? label : "", sizeof(_label) - 1);
  _label[sizeof(_label) - 1] = 0;
}

void ElecrowButton::setColors(uint16_t fill, uint16_t text, uint16_t border, uint16_t pressed_fill) {
  _fill = fill;
  _text = text;
  _border = border;
  _pressed_fill = pressed_fill;
}

void ElecrowButton::setTheme(const ElecrowTheme& t) {
  _fill = t.surface;
  _text = t.text;
  _border = t.border;
  _pressed_fill = t.primary;
  _on_fill = t.accent;
}

void ElecrowButton::draw(lgfx::LovyanGFX& g) {
  uint16_t fill = _pressed ? _pressed_fill : (_toggle && _on ? _on_fill : _fill);
  uint16_t text = _enabled ? _text : elecrowBlend565(_text, fill, 160);
  g.startWrite();
  g.fillRoundRect(_x, _y, _w, _h, _radius, fill);
  g.drawRoundRect(_x, _y, _w, _h, _radius, _border);

  const lgfx::IFont* old_font = g.getFont();
  const auto old_datum = g.getTextDatum();
  g.setFont(_font ? _font : &lgfx::fonts::FreeSansBold12pt7b);
  g.setTextColor(text, fill);
  g.setTextDatum(lgfx::textdatum_t::middle_center);

  int32_t text_cx = _x + _w / 2;
  if (_has_icon) {
    const int32_t isz = _h * 5 / 10;
    if (_label[0]) {
      const int32_t tw = g.textWidth(_label);
      const int32_t total = isz + 8 + tw;
      const int32_t left = _x + (_w - total) / 2;
      elecrowDrawIcon(g, _icon, left + isz / 2, _y + _h / 2, isz, text, fill);
      text_cx = left + isz + 8 + tw / 2;
    } else {
      elecrowDrawIcon(g, _icon, _x + _w / 2, _y + _h / 2, isz, text, fill);
    }
  }
  if (_label[0]) g.drawString(_label, text_cx, _y + _h / 2);
  g.setTextDatum(old_datum);
  g.setFont(old_font);
  g.endWrite();
}

bool ElecrowButton::update(lgfx::LovyanGFX& g, ElecrowTouch& touch) {
  if (!_enabled) return false;
  touch.update();
  const bool down = touch.isPressed();
  // A button only reacts to touches that STARTED inside it (no edge event is
  // consumed, so any number of buttons can share one ElecrowTouch).
  const bool owned = down && contains(touch.startX(), touch.startY());
  const bool inside = owned && contains(touch.x(), touch.y());
  bool clicked = false;

  if (inside && !_pressed) {
    _pressed = true;
    draw(g);
  } else if (!inside && _pressed) {
    _pressed = false;
    clicked = !down;  // released while still inside -> click; slid off -> cancel
    if (clicked && _toggle) _on = !_on;
    draw(g);
  }
  return clicked;
}

// ---------------------------------------------------------------------------
void ElecrowProgressBar::setValue(lgfx::LovyanGFX& g, float v, bool force) {
  if (v < _min) v = _min;
  if (v > _max) v = _max;
  if (!force && v == _value) return;
  _value = v;
  const float frac = (_max > _min) ? (v - _min) / (_max - _min) : 0.0f;
  const int32_t r = _h / 2;
  const int32_t fw = (int32_t)lroundf(frac * (_w - 4));

  g.startWrite();
  g.fillRoundRect(_x, _y, _w, _h, r, _track);
  if (fw > 0) g.fillRoundRect(_x + 2, _y + 2, fw < _h - 4 ? _h - 4 : fw, _h - 4, r - 2 > 0 ? r - 2 : 0, _bar);
  g.drawRoundRect(_x, _y, _w, _h, r, _border);
  if (_show_pct && _h >= 14) {
    char txt[8];
    snprintf(txt, sizeof(txt), "%d%%", (int)lroundf(frac * 100));
    const lgfx::IFont* old_font = g.getFont();
    const auto old_datum = g.getTextDatum();
    if (_h >= 28) g.setFont(&lgfx::fonts::FreeSansBold12pt7b); else g.setFont(&lgfx::fonts::Font2);
    g.setTextDatum(lgfx::textdatum_t::middle_center);
    g.setTextColor(0xFFFF);
    g.drawString(txt, _x + _w / 2, _y + _h / 2);
    g.setTextDatum(old_datum);
    g.setFont(old_font);
  }
  g.endWrite();
}

// ---------------------------------------------------------------------------
void ElecrowGauge::setLabel(const char* label, const char* unit) {
  strncpy(_label, label ? label : "", sizeof(_label) - 1);
  strncpy(_unit, unit ? unit : "", sizeof(_unit) - 1);
}

void ElecrowGauge::setValue(lgfx::LovyanGFX& g, float v, bool force) {
  if (!force && v == _value) return;
  _value = v;
  float c = v;
  if (c < _min) c = _min;
  if (c > _max) c = _max;
  const float frac = (_max > _min) ? (c - _min) / (_max - _min) : 0.0f;
  const float a0 = 135.0f, sweep = 270.0f;
  const int32_t thick = _r / 6 > 4 ? _r / 6 : 4;

  g.startWrite();
  g.fillArc(_cx, _cy, _r - thick, _r, a0, a0 + sweep, _track);
  if (frac > 0.001f) g.fillArc(_cx, _cy, _r - thick, _r, a0, a0 + sweep * frac, _arc);
  g.fillCircle(_cx, _cy, _r - thick - 1, _bg);

  const lgfx::IFont* old_font = g.getFont();
  const auto old_datum = g.getTextDatum();
  char txt[24];
  snprintf(txt, sizeof(txt), "%.*f%s", _decimals, v, _unit);
  g.setTextDatum(lgfx::textdatum_t::middle_center);
  g.setTextColor(_text, _bg);
  if (_r >= 70) g.setFont(&lgfx::fonts::FreeSansBold18pt7b); else g.setFont(&lgfx::fonts::FreeSansBold12pt7b);
  g.drawString(txt, _cx, _cy);
  if (_label[0]) {
    g.setFont(&lgfx::fonts::FreeSans9pt7b);
    g.setTextColor(elecrowBlend565(_text, _bg, 90), _bg);
    g.drawString(_label, _cx, _cy + _r * 6 / 10);
  }
  g.setTextDatum(old_datum);
  g.setFont(old_font);
  g.endWrite();
}

// ---------------------------------------------------------------------------
void ElecrowLineChart::add(float v) {
  _buf[_head] = v;
  _head = (uint16_t)((_head + 1) % _cap);
  if (_n < _cap) ++_n;
}

void ElecrowLineChart::draw(lgfx::LovyanGFX& g) {
  g.startWrite();
  g.fillRect(_x, _y, _w, _h, _bg);
  for (int i = 1; i < 4; ++i) g.drawFastHLine(_x, _y + _h * i / 4, _w, _grid);
  g.drawRect(_x, _y, _w, _h, _grid);
  if (_n >= 2) {
    float lo = _min, hi = _max;
    const uint16_t start = (uint16_t)((_head + _cap - _n) % _cap);
    if (lo == hi) {
      lo = hi = _buf[start];
      for (uint16_t i = 0; i < _n; ++i) {
        const float v = _buf[(start + i) % _cap];
        if (v < lo) lo = v;
        if (v > hi) hi = v;
      }
      if (hi - lo < 1e-6f) { hi += 0.5f; lo -= 0.5f; }
    }
    int32_t px = 0, py = 0;
    for (uint16_t i = 0; i < _n; ++i) {
      float v = _buf[(start + i) % _cap];
      if (v < lo) v = lo;
      if (v > hi) v = hi;
      const int32_t x = _x + 1 + (int32_t)((int32_t)(_w - 3) * i / (_cap > 1 ? _cap - 1 : 1));
      const int32_t y = _y + _h - 2 - (int32_t)lroundf((v - lo) / (hi - lo) * (_h - 4));
      if (i) g.drawLine(px, py, x, y, _line);
      px = x;
      py = y;
    }
  }
  g.endWrite();
}
