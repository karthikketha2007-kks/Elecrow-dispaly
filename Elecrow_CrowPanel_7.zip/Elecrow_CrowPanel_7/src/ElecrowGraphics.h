/**
 * @file ElecrowGraphics.h
 * @brief Colours, built-in vector icons and small reusable UI widgets.
 *
 * Widgets draw into any lgfx::LovyanGFX target: the screen (display.gfx())
 * or an off-screen LGFX_Sprite, so they can be used for flicker-free
 * double-buffered rendering as well.
 *
 * All colours are RGB565 (uint16_t).
 */
#pragma once
#include <LovyanGFX.hpp>
#include "ElecrowTouch.h"

/// Build an RGB565 colour from 8-bit R, G, B.
constexpr uint16_t elecrowRGB565(uint8_t r, uint8_t g, uint8_t b) {
  return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}
/// Blend two RGB565 colours. alpha 0 = a, 255 = b.
uint16_t elecrowBlend565(uint16_t a, uint16_t b, uint8_t alpha);

/// Predefined RGB565 colours.
namespace ElecrowColor {
constexpr uint16_t BLACK      = 0x0000;
constexpr uint16_t WHITE      = 0xFFFF;
constexpr uint16_t RED        = 0xF800;
constexpr uint16_t GREEN      = 0x07E0;
constexpr uint16_t BLUE       = 0x001F;
constexpr uint16_t YELLOW     = 0xFFE0;
constexpr uint16_t CYAN       = 0x07FF;
constexpr uint16_t MAGENTA    = 0xF81F;
constexpr uint16_t ORANGE     = elecrowRGB565(255, 165, 0);
constexpr uint16_t GRAY       = elecrowRGB565(128, 128, 128);
constexpr uint16_t GREY       = GRAY;
constexpr uint16_t DARKGRAY   = elecrowRGB565(64, 64, 64);
constexpr uint16_t LIGHTGRAY  = elecrowRGB565(192, 192, 192);
constexpr uint16_t NAVY       = elecrowRGB565(0, 0, 128);
constexpr uint16_t DARKGREEN  = elecrowRGB565(0, 100, 0);
constexpr uint16_t DARKCYAN   = elecrowRGB565(0, 128, 128);
constexpr uint16_t MAROON     = elecrowRGB565(128, 0, 0);
constexpr uint16_t PURPLE     = elecrowRGB565(128, 0, 128);
constexpr uint16_t OLIVE      = elecrowRGB565(128, 128, 0);
constexpr uint16_t PINK       = elecrowRGB565(255, 130, 198);
constexpr uint16_t BROWN      = elecrowRGB565(150, 75, 0);
constexpr uint16_t GOLD       = elecrowRGB565(255, 215, 0);
constexpr uint16_t SKYBLUE    = elecrowRGB565(135, 206, 235);
constexpr uint16_t VIOLET     = elecrowRGB565(180, 46, 226);
}  // namespace ElecrowColor

// Bring the colour names into the global namespace so `display.fill(RED)`
// works. Define ELECROW_NO_GLOBAL_COLORS before including the library if the
// names clash with another library (then use ElecrowColor::RED).
#ifndef ELECROW_NO_GLOBAL_COLORS
using namespace ElecrowColor;
#endif

/// A simple colour theme shared by the widgets.
struct ElecrowTheme {
  uint16_t background = elecrowRGB565(18, 22, 30);
  uint16_t surface    = elecrowRGB565(36, 42, 56);
  uint16_t primary    = elecrowRGB565(33, 150, 243);
  uint16_t accent     = elecrowRGB565(0, 200, 140);
  uint16_t warning    = elecrowRGB565(255, 170, 0);
  uint16_t danger     = elecrowRGB565(230, 60, 60);
  uint16_t text       = 0xFFFF;
  uint16_t text_muted = elecrowRGB565(150, 160, 175);
  uint16_t border     = elecrowRGB565(70, 80, 100);
};

/// Built-in vector icons (scale to any size, no image data needed).
enum class ElecrowIcon : uint8_t {
  Home, Settings, WiFi, Battery, Check, Close, ArrowLeft, ArrowRight, ArrowUp, ArrowDown,
  Plus, Minus, Power, Thermometer, Drop, Bell, Info, Warning, Menu, Lightbulb
};

/// Draws @p icon centred at (cx, cy) inside a size x size box.
/// @p value is used by icons with a level (Battery: 0..100).
void elecrowDrawIcon(lgfx::LovyanGFX& g, ElecrowIcon icon, int32_t cx, int32_t cy, int32_t size, uint16_t color,
                     uint16_t bg = 0x0000, int value = -1);

// ---------------------------------------------------------------------------
/// Push button with label, optional icon, pressed state and click detection.
class ElecrowButton {
public:
  ElecrowButton() = default;
  ElecrowButton(int16_t x, int16_t y, int16_t w, int16_t h, const char* label) { setBounds(x, y, w, h); setLabel(label); }

  void setBounds(int16_t x, int16_t y, int16_t w, int16_t h) { _x = x; _y = y; _w = w; _h = h; }
  void setLabel(const char* label);
  void setColors(uint16_t fill, uint16_t text, uint16_t border, uint16_t pressed_fill);
  void setTheme(const ElecrowTheme& t);
  void setFont(const lgfx::IFont* font) { _font = font; }
  void setRadius(uint8_t r) { _radius = r; }
  void setIcon(ElecrowIcon icon) { _icon = icon; _has_icon = true; }
  void setEnabled(bool en) { _enabled = en; }
  void setToggle(bool toggle) { _toggle = toggle; }   ///< toggle buttons flip state on click
  void setState(bool on) { _on = on; }
  bool state() const { return _on; }

  void draw(lgfx::LovyanGFX& g);
  bool contains(int16_t px, int16_t py) const { return px >= _x && px < _x + _w && py >= _y && py < _y + _h; }

  /// Feed touch; redraws on press/release; returns true once per click
  /// (press and release both inside the button).
  bool update(lgfx::LovyanGFX& g, ElecrowTouch& touch);

  int16_t x() const { return _x; }
  int16_t y() const { return _y; }
  int16_t width() const { return _w; }
  int16_t height() const { return _h; }

private:
  int16_t _x = 0, _y = 0, _w = 120, _h = 50;
  char _label[32] = {0};
  uint16_t _fill = elecrowRGB565(36, 42, 56), _text = 0xFFFF, _border = elecrowRGB565(70, 80, 100);
  uint16_t _pressed_fill = elecrowRGB565(33, 150, 243), _on_fill = elecrowRGB565(0, 200, 140);
  const lgfx::IFont* _font = nullptr;
  uint8_t _radius = 10;
  ElecrowIcon _icon = ElecrowIcon::Home;
  bool _has_icon = false, _enabled = true, _toggle = false, _on = false;
  bool _pressed = false;
};

/// Horizontal progress / level bar.
class ElecrowProgressBar {
public:
  ElecrowProgressBar() = default;
  ElecrowProgressBar(int16_t x, int16_t y, int16_t w, int16_t h) { setBounds(x, y, w, h); }
  void setBounds(int16_t x, int16_t y, int16_t w, int16_t h) { _x = x; _y = y; _w = w; _h = h; }
  void setRange(float min, float max) { _min = min; _max = max; }
  void setColors(uint16_t bar, uint16_t track, uint16_t border) { _bar = bar; _track = track; _border = border; }
  void showPercent(bool show) { _show_pct = show; }
  /// Redraws only if the value changed (unless force).
  void setValue(lgfx::LovyanGFX& g, float value, bool force = false);
  float value() const { return _value; }

private:
  int16_t _x = 0, _y = 0, _w = 200, _h = 24;
  float _min = 0, _max = 100, _value = NAN;
  uint16_t _bar = elecrowRGB565(0, 200, 140), _track = elecrowRGB565(36, 42, 56), _border = elecrowRGB565(70, 80, 100);
  bool _show_pct = true;
};

/// Circular arc gauge with centred value text.
class ElecrowGauge {
public:
  ElecrowGauge() = default;
  ElecrowGauge(int16_t cx, int16_t cy, int16_t r) { setPosition(cx, cy, r); }
  void setPosition(int16_t cx, int16_t cy, int16_t r) { _cx = cx; _cy = cy; _r = r; }
  void setRange(float min, float max) { _min = min; _max = max; }
  void setColors(uint16_t arc, uint16_t track, uint16_t text, uint16_t bg) { _arc = arc; _track = track; _text = text; _bg = bg; }
  void setLabel(const char* label, const char* unit);
  void setDecimals(uint8_t d) { _decimals = d; }
  void setValue(lgfx::LovyanGFX& g, float value, bool force = false);

private:
  int16_t _cx = 100, _cy = 100, _r = 80;
  float _min = 0, _max = 100, _value = NAN;
  uint16_t _arc = elecrowRGB565(33, 150, 243), _track = elecrowRGB565(50, 56, 70), _text = 0xFFFF, _bg = 0x0000;
  char _label[20] = {0}, _unit[8] = {0};
  uint8_t _decimals = 1;
};

/// Scrolling line chart with a fixed-size ring buffer (no dynamic allocation).
class ElecrowLineChart {
public:
  static constexpr uint16_t MAX_SAMPLES = 200;

  ElecrowLineChart() = default;
  ElecrowLineChart(int16_t x, int16_t y, int16_t w, int16_t h) { setBounds(x, y, w, h); }
  void setBounds(int16_t x, int16_t y, int16_t w, int16_t h) { _x = x; _y = y; _w = w; _h = h; }
  /// Fixed Y range. If min == max the chart autoscales.
  void setRange(float min, float max) { _min = min; _max = max; }
  void setColors(uint16_t line, uint16_t bg, uint16_t grid) { _line = line; _bg = bg; _grid = grid; }
  void setCapacity(uint16_t n) { _cap = n == 0 ? 1 : (n > MAX_SAMPLES ? MAX_SAMPLES : n); clear(); }
  void clear() { _n = 0; _head = 0; }
  void add(float v);
  uint16_t size() const { return _n; }
  void draw(lgfx::LovyanGFX& g);

private:
  int16_t _x = 0, _y = 0, _w = 300, _h = 120;
  float _min = 0, _max = 0;
  uint16_t _line = elecrowRGB565(0, 200, 140), _bg = 0x0000, _grid = elecrowRGB565(40, 46, 60);
  float _buf[MAX_SAMPLES];
  uint16_t _cap = 100, _n = 0, _head = 0;
};
