#include "ElecrowRGB.h"
#include "ElecrowDiagnostics.h"

void ElecrowLGFX::configure(const ElecrowConfig& c) {
  {
    auto cfg = bus.config();
    cfg.panel = &panel;
    for (int i = 0; i < 16; ++i) cfg.pin_data[i] = c.rgb.data[i];
    cfg.pin_henable = c.rgb.de;
    cfg.pin_vsync   = c.rgb.vsync;
    cfg.pin_hsync   = c.rgb.hsync;
    cfg.pin_pclk    = c.rgb.pclk;
    cfg.freq_write  = c.timing.pclk_hz;

    cfg.hsync_polarity    = c.timing.hsync_polarity;
    cfg.hsync_front_porch = c.timing.hsync_front_porch;
    cfg.hsync_pulse_width = c.timing.hsync_pulse_width;
    cfg.hsync_back_porch  = c.timing.hsync_back_porch;

    cfg.vsync_polarity    = c.timing.vsync_polarity;
    cfg.vsync_front_porch = c.timing.vsync_front_porch;
    cfg.vsync_pulse_width = c.timing.vsync_pulse_width;
    cfg.vsync_back_porch  = c.timing.vsync_back_porch;

    cfg.pclk_active_neg = c.timing.pclk_active_neg;
    cfg.de_idle_high    = c.timing.de_idle_high;
    cfg.pclk_idle_high  = c.timing.pclk_idle_high;
    bus.config(cfg);
  }
  {
    auto cfg = panel.config();
    cfg.memory_width  = c.width;
    cfg.memory_height = c.height;
    cfg.panel_width   = c.width;
    cfg.panel_height  = c.height;
    cfg.offset_x = 0;
    cfg.offset_y = 0;
    panel.config(cfg);
  }
  panel.setBus(&bus);
  setPanel(&panel);
}

ElecrowError ElecrowRGB::begin(const ElecrowConfig& cfg) {
  if (_ready) return ElecrowError::AlreadyInitialized;

  if (cfg.width == 0 || cfg.height == 0 || cfg.width > 1024 || cfg.height > 1024 || (cfg.width & 3)) {
    ELECROW_LOGE("invalid panel size %ux%u (width must be a multiple of 4)", cfg.width, cfg.height);
    return ElecrowError::InvalidConfig;
  }
  if (cfg.timing.pclk_hz < 1000000 || cfg.timing.pclk_hz > 40000000) {
    ELECROW_LOGE("pclk_hz %u out of range (1..40 MHz)", (unsigned)cfg.timing.pclk_hz);
    return ElecrowError::InvalidConfig;
  }

  // LovyanGFX's Bus_RGB does not check its PSRAM allocation, so check first.
  _stride = (cfg.width + 3) & ~3;
  _fb_bytes = (size_t)_stride * cfg.height * 2;
  if (!psramFound()) {
    ELECROW_LOGE("%s", elecrowErrorString(ElecrowError::NoPSRAM));
    return ElecrowError::NoPSRAM;
  }
  const size_t largest = heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM);
  if (largest < _fb_bytes + 4096) {
    ELECROW_LOGE("framebuffer needs %u bytes PSRAM, largest free block is %u", (unsigned)_fb_bytes,
                 (unsigned)largest);
    return ElecrowError::PSRAMTooSmall;
  }

  const uint32_t t0 = millis();
  _lcd.configure(cfg);
  if (!_lcd.init()) {
    ELECROW_LOGE("%s", elecrowErrorString(ElecrowError::RGBInitFailed));
    return ElecrowError::RGBInitFailed;
  }
  if (_lcd.bus.getDMABuffer(0) == nullptr) {
    ELECROW_LOGE("%s", elecrowErrorString(ElecrowError::FramebufferAllocFailed));
    return ElecrowError::FramebufferAllocFailed;
  }
  _init_ms = millis() - t0;
  _refresh_hz = cfg.timing.refreshRate(cfg.width, cfg.height);
  _ready = true;
  ELECROW_LOGI("RGB panel %ux%u up: PCLK %.1f MHz, ~%.1f Hz refresh, framebuffer %u bytes @ %p", cfg.width,
               cfg.height, cfg.timing.pclk_hz / 1e6f, _refresh_hz, (unsigned)_fb_bytes, framebuffer());
  return ElecrowError::None;
}

uint16_t* ElecrowRGB::framebuffer() {
  return _ready ? reinterpret_cast<uint16_t*>(_lcd.bus.getDMABuffer(0)) : nullptr;
}
