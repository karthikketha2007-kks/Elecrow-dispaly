#include "ElecrowDiagnostics.h"
#include <stdarg.h>
#include <esp_heap_caps.h>
#include <esp_system.h>
#include <soc/soc_caps.h>

Print* ElecrowDiagnostics::_out = &Serial;
ElecrowLogLevel ElecrowDiagnostics::_level = ElecrowLogLevel::Info;

const char* elecrowErrorString(ElecrowError err) {
  switch (err) {
    case ElecrowError::None:                   return "OK";
    case ElecrowError::NotInitialized:         return "driver not initialized (call begin())";
    case ElecrowError::AlreadyInitialized:     return "already initialized";
    case ElecrowError::InvalidConfig:          return "invalid configuration value";
    case ElecrowError::InvalidPin:             return "invalid GPIO in configuration";
    case ElecrowError::PinConflict:            return "same GPIO used twice in configuration";
    case ElecrowError::NoPSRAM:                return "PSRAM not found (Arduino: Tools > PSRAM > OPI PSRAM; PlatformIO: board_build.arduino.memory_type = qio_opi)";
    case ElecrowError::PSRAMTooSmall:          return "not enough free PSRAM for the framebuffer";
    case ElecrowError::FramebufferAllocFailed: return "framebuffer allocation failed";
    case ElecrowError::RGBInitFailed:          return "RGB panel / LCD_CAM init failed";
    case ElecrowError::I2CInitFailed:          return "I2C bus init failed";
    case ElecrowError::PCA9557NotFound:        return "PCA9557 (V3.0 touch reset expander) not found at 0x18";
    case ElecrowError::TouchNotFound:          return "GT911 touch controller not found at 0x5D/0x14";
    case ElecrowError::TouchCommFailed:        return "GT911 communication error";
    case ElecrowError::OutOfMemory:            return "out of memory";
    case ElecrowError::LVGLInitFailed:         return "LVGL integration init failed";
  }
  return "unknown error";
}

void ElecrowDiagnostics::log(ElecrowLogLevel lvl, const char* fmt, ...) {
  if (_out == nullptr || lvl == ElecrowLogLevel::None || (uint8_t)lvl > (uint8_t)_level) return;
  static const char* const tags[] = {"", "E", "W", "I", "D"};
  char buf[256];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  _out->printf("[Elecrow][%s] %s\n", tags[(uint8_t)lvl], buf);
}

ElecrowMemoryInfo ElecrowDiagnostics::memory() {
  ElecrowMemoryInfo m;
  m.psram_found = psramFound();
  m.psram_total = heap_caps_get_total_size(MALLOC_CAP_SPIRAM);
  m.psram_free = heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
  m.psram_largest_block = heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM);
  m.internal_free = heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  m.internal_min_free = heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  m.internal_largest_block = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  m.dma_free = heap_caps_get_free_size(MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
  return m;
}

void ElecrowDiagnostics::printMemory(Print& out) {
  const ElecrowMemoryInfo m = memory();
  out.printf("PSRAM    : %s, total %u, free %u, largest block %u\n", m.psram_found ? "yes" : "NO",
             (unsigned)m.psram_total, (unsigned)m.psram_free, (unsigned)m.psram_largest_block);
  out.printf("Internal : free %u, min free %u, largest block %u, DMA free %u\n", (unsigned)m.internal_free,
             (unsigned)m.internal_min_free, (unsigned)m.internal_largest_block, (unsigned)m.dma_free);
}

bool ElecrowDiagnostics::psramHasBlock(uint32_t bytes) {
  if (!psramFound()) return false;
  return heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM) >= bytes;
}

bool ElecrowDiagnostics::isUsableOutputPin(int8_t pin) {
  if (pin < 0 || pin > 48) return false;
  if (pin >= 22 && pin <= 25) return false;  // do not exist on ESP32-S3
  if (pin >= 26 && pin <= 32) return false;  // SPI flash / PSRAM
  if (pin >= 33 && pin <= 37) return false;  // octal PSRAM on the N4R8 module
  return true;
}

ElecrowError ElecrowDiagnostics::validatePins(const ElecrowConfig& cfg) {
  struct Named { const char* name; int8_t pin; };
  Named pins[24];
  uint8_t n = 0;
  static const char* const dn[16] = {"B0", "B1", "B2", "B3", "B4", "G0", "G1", "G2",
                                     "G3", "G4", "G5", "R0", "R1", "R2", "R3", "R4"};
  for (uint8_t i = 0; i < 16; ++i) pins[n++] = {dn[i], cfg.rgb.data[i]};
  pins[n++] = {"DE", cfg.rgb.de};
  pins[n++] = {"VSYNC", cfg.rgb.vsync};
  pins[n++] = {"HSYNC", cfg.rgb.hsync};
  pins[n++] = {"PCLK", cfg.rgb.pclk};
  if (cfg.backlight.pin >= 0) pins[n++] = {"BACKLIGHT", cfg.backlight.pin};
  if (cfg.touch.enabled) {
    pins[n++] = {"I2C_SDA", cfg.touch.sda};
    pins[n++] = {"I2C_SCL", cfg.touch.scl};
    if (cfg.touch.int_pin >= 0) pins[n++] = {"TOUCH_INT", cfg.touch.int_pin};
  }

  ElecrowError result = ElecrowError::None;
  for (uint8_t i = 0; i < n; ++i) {
    if (!isUsableOutputPin(pins[i].pin)) {
      ELECROW_LOGE("pin %s = GPIO%d is not usable on ESP32-S3-WROOM-1-N4R8", pins[i].name, pins[i].pin);
      result = ElecrowError::InvalidPin;
      continue;
    }
    for (uint8_t j = i + 1; j < n; ++j) {
      if (pins[i].pin == pins[j].pin) {
        ELECROW_LOGE("pin conflict: %s and %s both use GPIO%d", pins[i].name, pins[j].name, pins[i].pin);
        if (result == ElecrowError::None) result = ElecrowError::PinConflict;
      }
    }
  }

  // Warn (do not fail) when display pins collide with other on-board peripherals.
  struct Periph { const char* name; int8_t pin; };
  static const Periph periph[] = {
      {"SD_MOSI", ElecrowPins::SD_MOSI}, {"SD_MISO", ElecrowPins::SD_MISO}, {"SD_CLK", ElecrowPins::SD_CLK},
      {"SD_CS", ElecrowPins::SD_CS},     {"I2S_LRCLK", ElecrowPins::I2S_LRCLK}, {"I2S_BCLK", ElecrowPins::I2S_BCLK},
      {"I2S_SDIN", ElecrowPins::I2S_SDIN}, {"UART_RX", ElecrowPins::UART_RX}, {"UART_TX", ElecrowPins::UART_TX},
      {"GPIO_D", ElecrowPins::GPIO_D}};
  for (uint8_t i = 0; i < n; ++i) {
    for (const auto& p : periph) {
      if (pins[i].pin == p.pin) {
        ELECROW_LOGW("%s = GPIO%d is also the board's %s line", pins[i].name, pins[i].pin, p.name);
      }
    }
  }
  return result;
}

void ElecrowDiagnostics::printPinMap(Print& out, const ElecrowConfig& cfg) {
  out.println(F("---- CrowPanel 7.0 pin map ----"));
  out.print(F("RGB data B0..B4,G0..G5,R0..R4:"));
  for (int i = 0; i < 16; ++i) out.printf(" %d", cfg.rgb.data[i]);
  out.printf("\nDE %d  VSYNC %d  HSYNC %d  PCLK %d  BL %d\n", cfg.rgb.de, cfg.rgb.vsync, cfg.rgb.hsync,
             cfg.rgb.pclk, cfg.backlight.pin);
  out.printf("I2C (touch/PCA9557) SDA %d SCL %d @ %u Hz\n", cfg.touch.sda, cfg.touch.scl, (unsigned)cfg.touch.i2c_freq);
  out.printf("Free for the application: GPIO_D %d, UART RX %d TX %d, I2S LRCLK %d BCLK %d SDIN %d,\n"
             "  SD MOSI %d MISO %d CLK %d CS %d\n",
             ElecrowPins::GPIO_D, ElecrowPins::UART_RX, ElecrowPins::UART_TX, ElecrowPins::I2S_LRCLK,
             ElecrowPins::I2S_BCLK, ElecrowPins::I2S_SDIN, ElecrowPins::SD_MOSI, ElecrowPins::SD_MISO,
             ElecrowPins::SD_CLK, ElecrowPins::SD_CS);
  out.println(F("Notes: GPIO0 (PCLK) is the BOOT button; GPIO38 doubles as GT911 INT on V1/V2 boards."));
}

bool ElecrowDiagnostics::i2cProbe(TwoWire& wire, uint8_t addr) {
  wire.beginTransmission(addr);
  return wire.endTransmission() == 0;
}

uint8_t ElecrowDiagnostics::i2cScan(TwoWire& wire, Print& out) {
  uint8_t found = 0;
  out.println(F("I2C scan:"));
  for (uint8_t a = 0x08; a < 0x78; ++a) {
    if (!i2cProbe(wire, a)) continue;
    ++found;
    const char* name = "";
    switch (a) {
      case 0x5D: case 0x14: name = "GT911 touch"; break;
      case 0x18: name = "PCA9557 expander (V3.0)"; break;
      case 0x38: name = "DHT20/AHT20 (external)"; break;
      default: break;
    }
    out.printf("  0x%02X %s\n", a, name);
  }
  if (!found) out.println(F("  no devices"));
  return found;
}

bool ElecrowDiagnostics::i2cBusClear(int8_t sda, int8_t scl) {
  if (sda < 0 || scl < 0) return false;
  pinMode(sda, INPUT_PULLUP);
  pinMode(scl, INPUT_PULLUP);
  delayMicroseconds(10);
  if (digitalRead(sda) == HIGH && digitalRead(scl) == HIGH) return true;  // bus idle
  pinMode(scl, OUTPUT_OPEN_DRAIN);
  for (int i = 0; i < 9 && digitalRead(sda) == LOW; ++i) {
    digitalWrite(scl, LOW);
    delayMicroseconds(5);
    digitalWrite(scl, HIGH);
    delayMicroseconds(5);
  }
  // Generate a STOP condition: SDA low -> high while SCL high.
  pinMode(sda, OUTPUT_OPEN_DRAIN);
  digitalWrite(sda, LOW);
  delayMicroseconds(5);
  digitalWrite(scl, HIGH);
  delayMicroseconds(5);
  digitalWrite(sda, HIGH);
  delayMicroseconds(5);
  pinMode(sda, INPUT_PULLUP);
  pinMode(scl, INPUT_PULLUP);
  return digitalRead(sda) == HIGH;
}

const char* ElecrowDiagnostics::resetReasonString() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON:  return "power-on";
    case ESP_RST_EXT:      return "external pin";
    case ESP_RST_SW:       return "software";
    case ESP_RST_PANIC:    return "panic/exception";
    case ESP_RST_INT_WDT:  return "interrupt watchdog";
    case ESP_RST_TASK_WDT: return "task watchdog";
    case ESP_RST_WDT:      return "other watchdog";
    case ESP_RST_DEEPSLEEP:return "deep sleep wake";
    case ESP_RST_BROWNOUT: return "brownout (check 5V/2A supply)";
    case ESP_RST_SDIO:     return "SDIO";
    default:               return "unknown";
  }
}

void ElecrowDiagnostics::printSystemInfo(Print& out) {
  out.println(F("---- System ----"));
  out.printf("Chip     : %s rev %d, %d core(s), %u MHz\n", ESP.getChipModel(), (int)ESP.getChipRevision(),
             (int)ESP.getChipCores(), (unsigned)ESP.getCpuFreqMHz());
  out.printf("Flash    : %u bytes\n", (unsigned)ESP.getFlashChipSize());
  out.printf("SDK      : %s\n", ESP.getSdkVersion());
#if defined(ESP_ARDUINO_VERSION_MAJOR)
  out.printf("Arduino  : core %d.%d.%d\n", ESP_ARDUINO_VERSION_MAJOR, ESP_ARDUINO_VERSION_MINOR,
             ESP_ARDUINO_VERSION_PATCH);
#endif
  out.printf("Driver   : Elecrow_CrowPanel_7 %s\n", ELECROW_CROWPANEL7_VERSION);
  out.printf("Reset    : %s\n", resetReasonString());
  printMemory(out);
}
