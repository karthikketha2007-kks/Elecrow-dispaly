/**
 * @file ElecrowTouch.h
 * @brief GT911 capacitive touch driver (polling, up to 5 points) with
 *        calibration, rotation, gestures, callbacks and bus recovery.
 *
 * Register usage follows Elecrow's V3.0 PlatformIO example and the GT911
 * programming guide: product ID 0x8140, config 0x8047.., status 0x814E,
 * first point 0x814F (8 bytes per point), status cleared by writing 0.
 *
 * All reads are rate-limited (cfg.poll_interval_ms) so calling touched()
 * every loop iteration is cheap and never blocks for more than one I2C read.
 */
#pragma once
#include <functional>
#include "ElecrowConfig.h"
#include "ElecrowPCA9557.h"

/// One contact, in logical (rotated) screen coordinates.
struct ElecrowTouchPoint {
  int16_t x = 0;
  int16_t y = 0;
  uint16_t size = 0;  ///< contact area reported by the GT911
  uint8_t id = 0;     ///< GT911 track id (stable while the finger stays down)
};

enum class ElecrowGesture : uint8_t { None = 0, Tap, LongPress, SwipeLeft, SwipeRight, SwipeUp, SwipeDown };

enum class ElecrowTouchEventType : uint8_t {
  Press,      ///< first contact
  Move,       ///< contact moved (reported once per poll while moving)
  Release,    ///< finger lifted
  Tap,        ///< short press + release without moving
  LongPress,  ///< held without moving for cfg.long_press_ms (fires once)
  Swipe       ///< fast directional movement; see ElecrowTouchEvent::gesture
};

struct ElecrowTouchEvent {
  ElecrowTouchEventType type;
  ElecrowGesture gesture;   ///< for Tap/LongPress/Swipe
  int16_t x, y;             ///< current/last position
  int16_t start_x, start_y; ///< where the touch started
  uint32_t duration_ms;     ///< time since Press
  uint8_t points;           ///< contacts reported
};

using ElecrowTouchCallback = std::function<void(const ElecrowTouchEvent&)>;

/// Human readable gesture name.
const char* elecrowGestureName(ElecrowGesture g);

class ElecrowTouch {
public:
  static constexpr uint8_t MAX_POINTS = 5;

  /**
   * Initializes I2C (if not already running), performs the V3.0 PCA9557 reset
   * when @p rev is V3, @p pca is given and @p run_reset is true, then finds
   * the GT911. The expander is kept for automatic recovery.
   * @param panel_w/panel_h native panel size (800x480).
   */
  ElecrowError begin(const ElecrowTouchConfig& cfg, ElecrowBoardRevision rev, ElecrowPCA9557* pca,
                     uint16_t panel_w, uint16_t panel_h, bool run_reset = true);
  void end();

  /// Polls the controller (rate-limited, non-blocking). Returns true if a new
  /// sample was read. Fires callbacks. Safe to call as often as you like.
  bool update();

  // ---- state (call update() first, or use touched() which polls) -------------
  bool touched();                 ///< polls, then returns pressed state
  bool isPressed() const { return _pressed; }
  int16_t x() const { return _points[0].x; }
  int16_t y() const { return _points[0].y; }
  uint8_t count() const { return _count; }
  const ElecrowTouchPoint& point(uint8_t i) const { return _points[i < MAX_POINTS ? i : 0]; }
  bool getPoint(int16_t& x, int16_t& y);  ///< polls; true + coordinates if pressed
  int16_t startX() const { return _start_x; }  ///< where the current/last touch began
  int16_t startY() const { return _start_y; }
  uint32_t pressDuration() const { return _pressed ? millis() - _press_time : 0; }

  /// True if pressed and the first point is inside the rectangle.
  bool inArea(int16_t ax, int16_t ay, int16_t aw, int16_t ah) const;

  // ---- edge / gesture events (each read consumes the event) ------------------
  bool justPressed();
  bool justReleased();
  ElecrowGesture gesture();       ///< last completed gesture, then None

  void onEvent(ElecrowTouchCallback cb) { _callback = cb; }

  // ---- geometry ----------------------------------------------------------------
  /// Rotation uses LovyanGFX semantics (0..7). Called by ElecrowDisplay::setRotation().
  void setRotation(uint8_t rotation);
  uint8_t rotation() const { return _rotation; }

  /// Raw controller range that maps to the panel edges (native orientation).
  void setCalibration(uint16_t raw_x_min, uint16_t raw_x_max, uint16_t raw_y_min, uint16_t raw_y_max,
                      bool swap_xy = false, bool invert_x = false, bool invert_y = false);
  /// Reads one raw sample (no mapping). Returns false if not touched / error.
  bool readRaw(uint16_t& raw_x, uint16_t& raw_y);

  // ---- status / recovery ------------------------------------------------------
  bool ready() const { return _ready; }
  uint8_t address() const { return _addr; }
  const char* productId() const { return _product_id; }
  uint16_t controllerWidth() const { return _ctrl_w; }
  uint16_t controllerHeight() const { return _ctrl_h; }
  uint8_t configVersion() const { return _config_version; }
  uint32_t errorCount() const { return _errors_total; }
  uint32_t recoveryCount() const { return _recoveries; }
  ElecrowError lastError() const { return _last_error; }
  const ElecrowTouchConfig& config() const { return _cfg; }

  /// Re-initializes I2C, re-runs the V3.0 reset (if applicable) and re-probes.
  /// Blocks ~150 ms on V3.0. Called automatically after repeated I2C errors.
  bool recover();

private:
  bool startBus();
  bool probe();
  bool readRegs(uint16_t reg, uint8_t* buf, size_t len);
  bool writeReg(uint16_t reg, uint8_t value);
  void mapPoint(uint16_t rx, uint16_t ry, int16_t& x, int16_t& y) const;
  void handleSample(bool pressed);
  void emit(ElecrowTouchEventType type, ElecrowGesture g = ElecrowGesture::None);
  void commError();
  void forceRelease();

  ElecrowTouchConfig _cfg;
  ElecrowBoardRevision _rev = ElecrowBoardRevision::V1_V2;
  ElecrowPCA9557* _pca = nullptr;
  TwoWire* _wire = nullptr;
  uint16_t _panel_w = 800, _panel_h = 480;
  uint8_t _rotation = 0;

  bool _ready = false;
  uint8_t _addr = 0;
  char _product_id[5] = {0};
  uint8_t _config_version = 0;
  uint16_t _ctrl_w = 0, _ctrl_h = 0;

  ElecrowTouchPoint _points[MAX_POINTS];
  uint8_t _count = 0;
  bool _pressed = false;

  uint32_t _last_poll = 0;
  uint32_t _last_data = 0;

  // gesture tracking
  uint32_t _press_time = 0;
  int16_t _start_x = 0, _start_y = 0;
  int16_t _last_x = 0, _last_y = 0;
  bool _moved = false;
  bool _long_fired = false;

  bool _ev_pressed = false, _ev_released = false;
  ElecrowGesture _ev_gesture = ElecrowGesture::None;
  ElecrowTouchCallback _callback;

  uint8_t _consecutive_errors = 0;
  uint32_t _errors_total = 0;
  uint32_t _recoveries = 0;
  uint32_t _last_recovery = 0;
  ElecrowError _last_error = ElecrowError::NotInitialized;
};
