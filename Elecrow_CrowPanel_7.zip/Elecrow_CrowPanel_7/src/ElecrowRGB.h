/**
 * @file ElecrowRGB.h
 * @brief RGB565 parallel panel bring-up on the ESP32-S3 LCD_CAM peripheral,
 *        using LovyanGFX Bus_RGB + Panel_RGB (same classes Elecrow uses).
 *
 * The framebuffer (800 x 480 x 2 = 768,000 bytes) lives in PSRAM and is
 * scanned out continuously by GDMA. Every LovyanGFX drawing call writes into
 * it directly; LovyanGFX writes the CPU cache back after each operation
 * (auto-display), so drawing is visible without an explicit flush.
 */
#pragma once

#include <LovyanGFX.hpp>
#include <lgfx/v1/platforms/esp32s3/Bus_RGB.hpp>
#include <lgfx/v1/platforms/esp32s3/Panel_RGB.hpp>
#include "ElecrowConfig.h"

/// The LovyanGFX device for this board. Full LovyanGFX API (sprites, fonts,
/// JPEG/PNG decoders, ...) is available through ElecrowDisplay::gfx().
class ElecrowLGFX : public lgfx::LGFX_Device {
public:
  lgfx::Bus_RGB bus;
  lgfx::Panel_RGB panel;

  ElecrowLGFX() = default;
  /// Applies pins/timing from @p cfg. Must be called before init().
  void configure(const ElecrowConfig& cfg);
};

class ElecrowRGB {
public:
  /// Checks PSRAM, configures and starts the RGB interface.
  ElecrowError begin(const ElecrowConfig& cfg);

  ElecrowLGFX& gfx() { return _lcd; }
  bool ready() const { return _ready; }

  /// Framebuffer start (native orientation, RGB565 little-endian, stride = width).
  uint16_t* framebuffer();
  size_t framebufferBytes() const { return _fb_bytes; }
  uint16_t framebufferStride() const { return _stride; }

  float refreshRate() const { return _refresh_hz; }
  uint32_t initTimeMs() const { return _init_ms; }

private:
  ElecrowLGFX _lcd;
  bool _ready = false;
  size_t _fb_bytes = 0;
  uint16_t _stride = 0;
  float _refresh_hz = 0;
  uint32_t _init_ms = 0;
};
