/**
 * @file ElecrowPCA9557.h
 * @brief Minimal PCA9557 I2C GPIO-expander driver + the CrowPanel V3.0 touch
 *        reset sequence.
 *
 * Board V3.0 schematic (2024-04-20): A0=A1=A2=GND -> address 0x18,
 *   IO0 = TP-RESET (GT911 RESET), IO1 = INTE (GT911 INT),
 *   IO2 = LCD-RESET, IO3 = LCD-POWER-C (both through optional parts).
 *
 * The sequence in resetTouchV3() reproduces, register for register, what
 * Elecrow's official code does with the "PCA9557-arduino" library
 * (example/V3.0/Arduino/libraries/PCA9557, DEV_ADDR = 0x18):
 *
 *   Out.reset();               // CONFIG=0xFF, OUTPUT=0xFF, POLARITY=0x00
 *   Out.setMode(IO_OUTPUT);    // CONFIG=0x00 (all eight ports output)
 *   Out.setState(IO0, IO_LOW); // GT911 RESET low
 *   Out.setState(IO1, IO_LOW); // GT911 INT low  -> selects address 0x5D
 *   delay(20);
 *   Out.setState(IO0, IO_HIGH);// release reset
 *   delay(100);
 *   Out.setMode(IO1, IO_INPUT);// release INT so the GT911 can drive it
 *
 * Re-implemented here (instead of depending on that library) because it is not
 * in the Arduino / PlatformIO registries and its header comment wrongly says
 * the address is fixed at 0x41.
 */
#pragma once
#include <Arduino.h>
#include <Wire.h>

class ElecrowPCA9557 {
public:
  static constexpr uint8_t REG_INPUT    = 0x00;
  static constexpr uint8_t REG_OUTPUT   = 0x01;
  static constexpr uint8_t REG_POLARITY = 0x02;
  static constexpr uint8_t REG_CONFIG   = 0x03;  ///< bit = 1 -> input, 0 -> output

  bool begin(TwoWire& wire, uint8_t address = 0x18);
  bool present();

  bool writeReg(uint8_t reg, uint8_t value);
  bool readReg(uint8_t reg, uint8_t& value);

  /// Same as the library's reset(): all inputs, outputs latched high, no inversion.
  bool reset();
  bool setPinMode(uint8_t pin, bool input);
  bool setAllMode(bool input);
  bool setPin(uint8_t pin, bool high);
  bool readPin(uint8_t pin, bool& high);

  /// Official V3.0 GT911 reset/address-select sequence (blocks ~120 ms).
  bool resetTouchV3();

  uint8_t address() const { return _addr; }

private:
  bool updateBit(uint8_t reg, uint8_t pin, bool set);
  TwoWire* _wire = nullptr;
  uint8_t _addr = 0x18;
};
