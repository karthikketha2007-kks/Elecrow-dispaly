/*
 * 08_LVGL_Integration - LVGL on top of the Elecrow driver
 *
 * Requires the LVGL library (9.x recommended; 8.3.x also supported).
 * Arduino IDE: copy extras/lv_conf_v9.h (or lv_conf_v8.h) from this library
 *   to <Arduino>/libraries/lv_conf.h  (next to the lvgl folder, NOT inside it).
 * PlatformIO: see extras/platformio/platformio.ini ([env:lvgl9]); it
 *   configures LVGL with -D flags, no lv_conf.h needed.
 *
 * Demo: title, a button with a click counter, a slider that sets the real
 * backlight brightness, an arc showing a simulated value, a live chart.
 */
#include <lvgl.h>            // include LVGL first so the IDE / PlatformIO find it
#include <ElecrowDisplay.h>
#include <ElecrowLVGL.h>

ElecrowDisplay display;

static lv_obj_t* counterLabel;
static lv_obj_t* arc;
static lv_obj_t* arcLabel;
static lv_obj_t* chart;
static lv_chart_series_t* series;
static int clicks = 0;

// Written against the LVGL 9 API; two aliases make it build on LVGL 8.3 too.
#if LVGL_VERSION_MAJOR < 9
#define lv_screen_active lv_scr_act
#define lv_button_create lv_btn_create
#endif

static void onButton(lv_event_t* e) {
  (void)e;
  ++clicks;
  lv_label_set_text_fmt(counterLabel, "Clicked %d times", clicks);
}

static void onSlider(lv_event_t* e) {
  lv_obj_t* slider = (lv_obj_t*)lv_event_get_target(e);
  display.setBrightness((uint8_t)lv_slider_get_value(slider));
}

static void buildUI() {
  lv_obj_t* scr = lv_screen_active();
  lv_obj_set_style_bg_color(scr, lv_color_hex(0x12161E), 0);

  lv_obj_t* title = lv_label_create(scr);
  lv_label_set_text(title, "CrowPanel 7.0 + LVGL");
  lv_obj_set_style_text_color(title, lv_color_white(), 0);
  lv_obj_set_style_text_font(title, &lv_font_montserrat_28, 0);
  lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 16);

  lv_obj_t* btn = lv_button_create(scr);
  lv_obj_set_size(btn, 240, 80);
  lv_obj_align(btn, LV_ALIGN_TOP_LEFT, 40, 90);
  lv_obj_add_event_cb(btn, onButton, LV_EVENT_CLICKED, nullptr);
  lv_obj_t* bl = lv_label_create(btn);
  lv_label_set_text(bl, LV_SYMBOL_OK " Press me");
  lv_obj_center(bl);

  counterLabel = lv_label_create(scr);
  lv_label_set_text(counterLabel, "Clicked 0 times");
  lv_obj_set_style_text_color(counterLabel, lv_color_white(), 0);
  lv_obj_align_to(counterLabel, btn, LV_ALIGN_OUT_BOTTOM_MID, 0, 12);

  lv_obj_t* sl = lv_slider_create(scr);
  lv_obj_set_width(sl, 300);
  lv_slider_set_range(sl, 5, 255);
  lv_slider_set_value(sl, 255, LV_ANIM_OFF);
  lv_obj_align(sl, LV_ALIGN_TOP_LEFT, 40, 250);
  lv_obj_add_event_cb(sl, onSlider, LV_EVENT_VALUE_CHANGED, nullptr);
  lv_obj_t* sll = lv_label_create(scr);
  lv_label_set_text(sll, "Backlight");
  lv_obj_set_style_text_color(sll, lv_color_white(), 0);
  lv_obj_align_to(sll, sl, LV_ALIGN_OUT_TOP_LEFT, 0, -10);

  arc = lv_arc_create(scr);
  lv_obj_set_size(arc, 200, 200);
  lv_arc_set_range(arc, 0, 100);
  lv_obj_align(arc, LV_ALIGN_TOP_RIGHT, -60, 80);
  arcLabel = lv_label_create(scr);
  lv_obj_set_style_text_color(arcLabel, lv_color_white(), 0);
  lv_obj_set_style_text_font(arcLabel, &lv_font_montserrat_28, 0);
  lv_obj_align_to(arcLabel, arc, LV_ALIGN_CENTER, 0, 0);

  chart = lv_chart_create(scr);
  lv_obj_set_size(chart, 720, 130);
  lv_obj_align(chart, LV_ALIGN_BOTTOM_MID, 0, -16);
  lv_chart_set_point_count(chart, 60);
  lv_chart_set_range(chart, LV_CHART_AXIS_PRIMARY_Y, 0, 100);
  series = lv_chart_add_series(chart, lv_palette_main(LV_PALETTE_GREEN), LV_CHART_AXIS_PRIMARY_Y);
}

void setup() {
  Serial.begin(115200);
  if (!display.begin()) {
    Serial.printf("display init failed: %s\n", display.errorString());
    return;
  }
  ElecrowLVGLConfig lv;                 // defaults: Partial mode, 2 x 40-line buffers
  if (!ElecrowLVGL::begin(display, lv)) {
    Serial.println("LVGL init failed");
    return;
  }
  buildUI();
}

void loop() {
  if (!ElecrowLVGL::ready()) return;
  static uint32_t last = 0;
  if (millis() - last > 200) {
    last = millis();
    const int v = 50 + (int)(40 * sinf(millis() / 2000.0f));
    lv_arc_set_value(arc, v);
    lv_label_set_text_fmt(arcLabel, "%d%%", v);
    lv_chart_set_next_value(chart, series, v);
  }
  const uint32_t wait_ms = ElecrowLVGL::handler();
  delay(wait_ms > 5 ? 5 : wait_ms);  // short sleep lets the idle task run; keeps touch responsive
}
