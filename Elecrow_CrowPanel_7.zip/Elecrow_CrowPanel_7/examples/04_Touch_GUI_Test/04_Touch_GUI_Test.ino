/*
 * 04_Touch_GUI_Test - interactive widgets driven by touch
 *
 *  - 4 toggle buttons ("lights") with state indicators
 *  - brightness - / + buttons controlling the real backlight (PWM)
 *  - a progress bar showing the brightness
 *  - swipe left/right anywhere in the gesture area changes a page counter
 *  - long-press in the gesture area resets the counter
 * Everything is event driven; only changed areas are redrawn.
 */
#include <ElecrowDisplay.h>

ElecrowDisplay display;
ElecrowTheme theme;

ElecrowButton lights[4];
ElecrowButton btnDim, btnBright;
ElecrowProgressBar brightnessBar(60, 330, 680, 34);
int pageCounter = 0;
uint8_t brightness = 255;

static const int GESTURE_Y = 390;  // gesture area: y >= GESTURE_Y

static void drawIndicator(int i) {
  const int x = 60 + i * 175 + 75;
  display.fillCircle(x, 205, 12, lights[i].state() ? theme.accent : theme.surface);
  display.drawCircle(x, 205, 12, theme.border);
}

static void drawGestureArea(const char* msg) {
  display.fillRoundRectangle(20, GESTURE_Y, 760, 80, 12, theme.surface);
  display.setFont(&fonts::FreeSansBold12pt7b);
  display.setTextColor(theme.text, theme.surface);
  char buf[80];
  snprintf(buf, sizeof(buf), "Swipe here  |  page %d  |  %s", pageCounter, msg);
  display.drawTextCentered(buf, 400, GESTURE_Y + 40);
}

void setup() {
  Serial.begin(115200);
  if (!display.begin()) {
    Serial.printf("init failed: %s\n", display.errorString());
    return;
  }
  display.clear(theme.background);
  display.setFont(&fonts::FreeSansBold18pt7b);
  display.setTextColor(theme.text, theme.background);
  display.drawText("Touch GUI test", 20, 20);

  const char* names[4] = {"Living", "Kitchen", "Bedroom", "Garden"};
  for (int i = 0; i < 4; ++i) {
    lights[i].setBounds(60 + i * 175, 90, 150, 90);
    lights[i].setLabel(names[i]);
    lights[i].setTheme(theme);
    lights[i].setToggle(true);
    lights[i].setIcon(ElecrowIcon::Lightbulb);
    lights[i].setFont(&fonts::FreeSansBold9pt7b);
    lights[i].draw(display.gfx());
    drawIndicator(i);
  }
  btnDim.setBounds(60, 245, 160, 60);
  btnDim.setLabel("Dim");
  btnDim.setIcon(ElecrowIcon::Minus);
  btnBright.setBounds(580, 245, 160, 60);
  btnBright.setLabel("Bright");
  btnBright.setIcon(ElecrowIcon::Plus);
  for (ElecrowButton* b : {&btnDim, &btnBright}) { b->setTheme(theme); b->draw(display.gfx()); }
  display.setFont(&fonts::FreeSans12pt7b);
  display.drawTextCentered("Backlight", 400, 275);
  brightnessBar.setColors(theme.primary, theme.surface, theme.border);
  brightnessBar.setRange(0, 255);
  brightnessBar.setValue(display.gfx(), brightness, true);
  drawGestureArea("ready");
}

void loop() {
  if (!display.ready()) return;
  display.update();

  for (int i = 0; i < 4; ++i) {
    if (lights[i].update(display.gfx(), display.touch())) {
      drawIndicator(i);
      Serial.printf("%s -> %s\n", "light", lights[i].state() ? "ON" : "OFF");
    }
  }
  if (btnDim.update(display.gfx(), display.touch())) brightness = brightness > 30 ? brightness - 25 : 5;
  if (btnBright.update(display.gfx(), display.touch())) brightness = brightness < 230 ? brightness + 25 : 255;
  if (brightness != display.getBrightness()) {
    display.setBrightness(brightness);
    brightnessBar.setValue(display.gfx(), brightness);
  }

  ElecrowTouch& t = display.touch();
  if (t.startY() >= GESTURE_Y) {
    switch (t.gesture()) {
      case ElecrowGesture::SwipeLeft:  ++pageCounter; drawGestureArea("swipe left"); break;
      case ElecrowGesture::SwipeRight: --pageCounter; drawGestureArea("swipe right"); break;
      case ElecrowGesture::LongPress:  pageCounter = 0; drawGestureArea("long press: reset"); break;
      case ElecrowGesture::Tap:        drawGestureArea("tap"); break;
      default: break;
    }
  } else {
    t.gesture();  // discard gestures that started elsewhere
  }
}
