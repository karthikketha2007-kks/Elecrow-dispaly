/*
 * 07_Full_Demo - complete touchscreen application (Test 6)
 *
 *  Header : title, Wi-Fi + battery status icons, live clock
 *  Pages  : Home (gauges + status indicators), Sensors (live chart),
 *           Controls (toggle devices, fan speed), Settings (brightness,
 *           screen flip, system info)
 *  Nav    : bottom navigation bar, or swipe left/right in the content area
 *
 * Sensor values are simulated so the demo runs on a bare board; replace
 * readSensors() with real sensor code. Everything is non-blocking.
 */
#include <ElecrowDisplay.h>

ElecrowDisplay display;
ElecrowTheme theme;

// ---- layout -------------------------------------------------------------------
static const int W = 800, H = 480;
static const int HEADER_H = 56, NAV_H = 72;
static const int CONTENT_Y = HEADER_H, CONTENT_H = H - HEADER_H - NAV_H;

enum Page : uint8_t { PAGE_HOME, PAGE_SENSORS, PAGE_CONTROLS, PAGE_SETTINGS, PAGE_COUNT };
static Page page = PAGE_HOME;

ElecrowButton nav[PAGE_COUNT];
static const char* const NAV_LABELS[PAGE_COUNT] = {"Home", "Sensors", "Controls", "Settings"};
static const ElecrowIcon NAV_ICONS[PAGE_COUNT] = {ElecrowIcon::Home, ElecrowIcon::Thermometer, ElecrowIcon::Power,
                                                  ElecrowIcon::Settings};

// ---- simulated data ------------------------------------------------------------
struct Sensors { float temperature = 22.5f, humidity = 48.0f, power = 1.2f; bool link = true; bool alarm = false; } s;
ElecrowGauge gTemp, gHum, gPow;
ElecrowLineChart chartTemp, chartHum;

// ---- controls -------------------------------------------------------------------
ElecrowButton devices[6];
ElecrowButton fanDown, fanUp;
ElecrowProgressBar fanBar;
int fanSpeed = 40;

// ---- settings -------------------------------------------------------------------
ElecrowButton brDown, brUp, flipBtn;
ElecrowProgressBar brBar;
uint8_t brightness = 255;

// ---- clock (starts at the build time, counts with millis) ----------------------
static uint32_t clockBaseSec = 0;

static void initClock() {
  int hh = 0, mm = 0, ss = 0;
  sscanf(__TIME__, "%d:%d:%d", &hh, &mm, &ss);
  clockBaseSec = hh * 3600 + mm * 60 + ss;
}

// ================================================================================
static void drawHeader() {
  display.fillRectangle(0, 0, W, HEADER_H, theme.surface);
  display.drawFastHLine(0, HEADER_H - 1, W, theme.border);
  display.drawIcon(ElecrowIcon::Menu, 30, HEADER_H / 2, 28, theme.text, theme.surface);
  display.setFont(&fonts::FreeSansBold12pt7b);
  display.setTextColor(theme.text, theme.surface);
  display.drawText("CrowPanel Smart Panel", 60, 17);
}

static void drawStatusIcons() {
  display.fillRectangle(470, 8, 120, 40, theme.surface);
  display.drawIcon(ElecrowIcon::WiFi, 500, HEADER_H / 2, 30, s.link ? theme.accent : theme.text_muted, theme.surface);
  const int battery = 100 - (int)((millis() / 6000) % 100);
  display.drawIcon(ElecrowIcon::Battery, 555, HEADER_H / 2, 36, theme.text, theme.surface, battery);
}

static void drawClock() {
  const uint32_t t = (clockBaseSec + millis() / 1000) % 86400;
  char buf[16];
  snprintf(buf, sizeof(buf), "%02u:%02u:%02u", (unsigned)(t / 3600), (unsigned)((t / 60) % 60), (unsigned)(t % 60));
  display.setFont(&fonts::FreeMonoBold18pt7b);
  display.setTextColor(theme.text, theme.surface);
  display.drawTextRight(buf, W - 16, 12);
}

static void drawNav() {
  display.fillRectangle(0, H - NAV_H, W, NAV_H, theme.surface);
  display.drawFastHLine(0, H - NAV_H, W, theme.border);
  for (int i = 0; i < PAGE_COUNT; ++i) {
    nav[i].setColors(i == page ? theme.primary : theme.surface, theme.text, i == page ? theme.primary : theme.surface,
                     theme.primary);
    nav[i].draw(display.gfx());
  }
}

static void indicator(int x, int y, const char* label, bool ok, uint16_t on_color) {
  display.fillRoundRectangle(x, y, 220, 44, 22, theme.surface);
  display.fillCircle(x + 24, y + 22, 10, ok ? on_color : theme.text_muted);
  display.setFont(&fonts::FreeSans12pt7b);
  display.setTextColor(theme.text, theme.surface);
  display.drawText(label, x + 46, y + 12);
}

// ---- pages ---------------------------------------------------------------------------
static void drawHomeValues(bool force) {
  gTemp.setValue(display.gfx(), s.temperature, force);
  gHum.setValue(display.gfx(), s.humidity, force);
  gPow.setValue(display.gfx(), s.power, force);
  indicator(30, 300, "System OK", true, theme.accent);
  indicator(290, 300, "Sensor link", s.link, theme.accent);
  indicator(550, 300, s.alarm ? "ALARM" : "No alarm", s.alarm, theme.danger);
}

static void drawSensorsValues() {
  chartTemp.draw(display.gfx());
  chartHum.draw(display.gfx());
  display.setFont(&fonts::FreeSansBold12pt7b);
  display.setTextColor(theme.accent, theme.background);
  display.drawTextf(30, CONTENT_Y + 12, "Temperature %5.1f C   ", s.temperature);
  display.setTextColor(theme.primary, theme.background);
  display.drawTextf(420, CONTENT_Y + 12, "Humidity %5.1f %%   ", s.humidity);
}

static void drawPage() {
  display.fillRectangle(0, CONTENT_Y, W, CONTENT_H, theme.background);
  switch (page) {
    case PAGE_HOME:
      drawHomeValues(true);
      break;
    case PAGE_SENSORS:
      drawSensorsValues();
      break;
    case PAGE_CONTROLS:
      for (auto& d : devices) d.draw(display.gfx());
      display.setFont(&fonts::FreeSansBold12pt7b);
      display.setTextColor(theme.text, theme.background);
      display.drawText("Fan speed", 30, 268);
      fanDown.draw(display.gfx());
      fanUp.draw(display.gfx());
      fanBar.setValue(display.gfx(), fanSpeed, true);
      break;
    case PAGE_SETTINGS: {
      display.setFont(&fonts::FreeSansBold12pt7b);
      display.setTextColor(theme.text, theme.background);
      display.drawText("Brightness", 30, CONTENT_Y + 20);
      brDown.draw(display.gfx());
      brUp.draw(display.gfx());
      brBar.setValue(display.gfx(), brightness, true);
      flipBtn.draw(display.gfx());
      const ElecrowMemoryInfo m = ElecrowDiagnostics::memory();
      display.setFont(&fonts::FreeSans9pt7b);
      display.setTextColor(theme.text_muted, theme.background);
      display.drawTextf(30, 230, "Driver %s   Board %s   Touch %s", ELECROW_CROWPANEL7_VERSION,
                        display.boardRevisionString(), display.touchAvailable() ? "GT911 OK" : "not found");
      display.drawTextf(30, 256, "Heap free %u (min %u)   PSRAM free %u", (unsigned)m.internal_free,
                        (unsigned)m.internal_min_free, (unsigned)m.psram_free);
      display.drawTextf(30, 282, "Panel %dx%d  PCLK %.1f MHz  ~%.1f Hz", (int)display.width(), (int)display.height(),
                        display.config().timing.pclk_hz / 1e6f, display.rgb().refreshRate());
      break;
    }
    default: break;
  }
}

static void showPage(Page p) {
  page = p;
  drawNav();
  drawPage();
}

// ---- data ------------------------------------------------------------------------------
static void readSensors() {
  const float t = millis() / 1000.0f;
  s.temperature = 22.5f + 3.0f * sinf(t / 20.0f) + random(-10, 10) / 50.0f;
  s.humidity = 48.0f + 8.0f * sinf(t / 33.0f + 1.0f) + random(-10, 10) / 40.0f;
  s.power = 1.2f + 0.8f * (0.5f + 0.5f * sinf(t / 7.0f)) + fanSpeed / 200.0f;
  s.link = ((int)t % 30) < 27;
  s.alarm = s.temperature > 25.2f;
  chartTemp.add(s.temperature);
  chartHum.add(s.humidity);
}

// ================================================================================
static void layoutWidgets() {
  const int bw = W / PAGE_COUNT;
  for (int i = 0; i < PAGE_COUNT; ++i) {
    nav[i].setBounds(i * bw + 6, H - NAV_H + 8, bw - 12, NAV_H - 16);
    nav[i].setLabel(NAV_LABELS[i]);
    nav[i].setIcon(NAV_ICONS[i]);
    nav[i].setFont(&fonts::FreeSansBold9pt7b);
  }

  gTemp.setPosition(140, 175, 95);
  gTemp.setRange(10, 40);
  gTemp.setLabel("Temperature", "C");
  gTemp.setColors(theme.accent, theme.surface, theme.text, theme.background);
  gHum.setPosition(400, 175, 95);
  gHum.setRange(0, 100);
  gHum.setLabel("Humidity", "%");
  gHum.setDecimals(0);
  gHum.setColors(theme.primary, theme.surface, theme.text, theme.background);
  gPow.setPosition(660, 175, 95);
  gPow.setRange(0, 3);
  gPow.setLabel("Power", "kW");
  gPow.setDecimals(2);
  gPow.setColors(theme.warning, theme.surface, theme.text, theme.background);

  chartTemp.setBounds(30, CONTENT_Y + 50, 360, 280);
  chartTemp.setCapacity(120);
  chartTemp.setColors(theme.accent, theme.surface, theme.border);
  chartHum.setBounds(410, CONTENT_Y + 50, 360, 280);
  chartHum.setCapacity(120);
  chartHum.setColors(theme.primary, theme.surface, theme.border);

  const char* names[6] = {"Lights", "Heater", "Pump", "Door", "Alarm", "Camera"};
  const ElecrowIcon icons[6] = {ElecrowIcon::Lightbulb, ElecrowIcon::Thermometer, ElecrowIcon::Drop,
                                ElecrowIcon::Home, ElecrowIcon::Bell, ElecrowIcon::Info};
  for (int i = 0; i < 6; ++i) {
    devices[i].setBounds(30 + (i % 3) * 250, CONTENT_Y + 16 + (i / 3) * 90, 230, 76);
    devices[i].setLabel(names[i]);
    devices[i].setIcon(icons[i]);
    devices[i].setToggle(true);
    devices[i].setTheme(theme);
  }
  fanDown.setBounds(30, 300, 90, 56);
  fanDown.setIcon(ElecrowIcon::Minus);
  fanDown.setLabel("");
  fanUp.setBounds(680, 300, 90, 56);
  fanUp.setIcon(ElecrowIcon::Plus);
  fanUp.setLabel("");
  fanBar.setBounds(140, 310, 520, 36);
  fanBar.setColors(theme.accent, theme.surface, theme.border);

  brDown.setBounds(30, CONTENT_Y + 60, 90, 56);
  brDown.setIcon(ElecrowIcon::Minus);
  brDown.setLabel("");
  brUp.setBounds(680, CONTENT_Y + 60, 90, 56);
  brUp.setIcon(ElecrowIcon::Plus);
  brUp.setLabel("");
  brBar.setBounds(140, CONTENT_Y + 70, 520, 36);
  brBar.setRange(0, 255);
  brBar.setColors(theme.primary, theme.surface, theme.border);
  flipBtn.setBounds(30, 300, 260, 56);
  flipBtn.setLabel("Flip screen 180");
  flipBtn.setIcon(ElecrowIcon::ArrowUp);
  for (ElecrowButton* b : {&fanDown, &fanUp, &brDown, &brUp, &flipBtn}) b->setTheme(theme);
}

static void redrawAll() {
  display.clear(theme.background);
  drawHeader();
  drawStatusIcons();
  drawClock();
  showPage(page);
}

void setup() {
  Serial.begin(115200);
  if (!display.begin()) {
    Serial.printf("init failed: %s\n", display.errorString());
    return;
  }
  initClock();
  layoutWidgets();
  for (int i = 0; i < 30; ++i) readSensors();
  redrawAll();
}

void loop() {
  if (!display.ready()) return;
  display.update();
  ElecrowTouch& touch = display.touch();
  const uint32_t now = millis();

  // ---- periodic work -------------------------------------------------------------
  static uint32_t lastSecond = 0, lastSensor = 0;
  if (now - lastSecond >= 1000) {
    lastSecond = now;
    drawClock();
    drawStatusIcons();
  }
  if (now - lastSensor >= 1000) {
    lastSensor = now;
    readSensors();
    if (page == PAGE_HOME) drawHomeValues(false);
    else if (page == PAGE_SENSORS) drawSensorsValues();
  }

  // ---- navigation -------------------------------------------------------------------
  for (int i = 0; i < PAGE_COUNT; ++i) {
    if (nav[i].update(display.gfx(), touch) && i != page) { showPage((Page)i); return; }
  }
  if (touch.startY() > CONTENT_Y && touch.startY() < H - NAV_H) {
    const ElecrowGesture g = touch.gesture();
    if (g == ElecrowGesture::SwipeLeft) { showPage((Page)((page + 1) % PAGE_COUNT)); return; }
    if (g == ElecrowGesture::SwipeRight) { showPage((Page)((page + PAGE_COUNT - 1) % PAGE_COUNT)); return; }
  }

  // ---- page interaction ------------------------------------------------------------
  if (page == PAGE_CONTROLS) {
    for (auto& d : devices) {
      if (d.update(display.gfx(), touch)) Serial.printf("device -> %s\n", d.state() ? "ON" : "OFF");
    }
    if (fanDown.update(display.gfx(), touch)) { fanSpeed = max(0, fanSpeed - 10); fanBar.setValue(display.gfx(), fanSpeed); }
    if (fanUp.update(display.gfx(), touch)) { fanSpeed = min(100, fanSpeed + 10); fanBar.setValue(display.gfx(), fanSpeed); }
  } else if (page == PAGE_SETTINGS) {
    if (brDown.update(display.gfx(), touch)) brightness = brightness > 35 ? brightness - 30 : 5;
    if (brUp.update(display.gfx(), touch)) brightness = brightness < 225 ? brightness + 30 : 255;
    if (brightness != display.getBrightness()) {
      display.setBrightness(brightness);
      brBar.setValue(display.gfx(), brightness);
    }
    if (flipBtn.update(display.gfx(), touch)) {
      display.setRotation(display.getRotation() == 0 ? 2 : 0);
      redrawAll();
    }
  }
}
