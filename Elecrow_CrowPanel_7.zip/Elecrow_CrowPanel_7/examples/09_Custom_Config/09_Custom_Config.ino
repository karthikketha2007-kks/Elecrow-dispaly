/*
 * 09_Custom_Config - how a project overrides driver settings
 *
 * Start from ElecrowConfig::defaults() (the verified board values) and change
 * only what the project needs. Every field is documented in ElecrowConfig.h.
 * Pins/timing should stay at the defaults unless you have a measured reason.
 */
#include <ElecrowDisplay.h>

ElecrowDisplay display;

void setup() {
  Serial.begin(115200);

  ElecrowConfig cfg = ElecrowConfig::defaults();
  cfg.rotation = 2;                              // panel mounted upside down
  cfg.log_level = ElecrowLogLevel::Debug;        // verbose driver log on Serial
  cfg.clear_color = NAVY;                        // colour shown when the backlight turns on
  cfg.backlight.initial_brightness = 180;        // start dimmed (PWM)
  cfg.backlight.pwm_freq = 300;                  // Elecrow's legacy dimming frequency
  cfg.revision = ElecrowBoardRevision::Auto;     // or force V3 / V1_V2
  cfg.touch.poll_interval_ms = 15;               // GT911 read rate limit
  cfg.touch.long_press_ms = 800;
  cfg.touch.swipe_min_distance_px = 100;
  // cfg.touch.wire = &Wire1;                    // keep Wire free for other sensors
  // cfg.timing.pclk_hz = 12000000;              // lower PCLK if you see drift with heavy PSRAM traffic
  // cfg.touch.setCalibration via display.touch().setCalibration(...) after begin()

  if (!display.begin(cfg)) {
    Serial.printf("init failed: %s\n", display.errorString());
    return;
  }
  display.printDiagnostics(Serial);

  display.setFont(&fonts::FreeSansBold18pt7b);
  display.setTextColor(WHITE, NAVY);
  display.drawTextCentered("Custom configuration (rotation 2)", display.width() / 2, 60);
  display.setFont(&fonts::FreeSans12pt7b);
  display.drawTextf(40, 140, "Rotation %u, %dx%d, backlight %u", display.getRotation(), (int)display.width(),
                    (int)display.height(), display.getBrightness());
  display.drawTextf(40, 180, "Board %s, touch %s", display.boardRevisionString(),
                    display.touchAvailable() ? "OK" : "not found");
  display.drawText("Touch: coordinates follow the rotation.", 40, 220);

  // Optional: a manual calibration if your panel's touch is offset/mirrored.
  // display.touch().setCalibration(0, 799, 0, 479, /*swap*/ false, /*inv x*/ false, /*inv y*/ false);
}

void loop() {
  if (!display.ready()) return;
  display.update();
  int16_t x, y;
  if (display.getTouch(x, y)) {
    display.fillCircle(x, y, 5, YELLOW);
    display.setTextColor(WHITE, NAVY);
    display.drawTextf(40, 400, "x=%4d  y=%4d   ", x, y);
  }
}
