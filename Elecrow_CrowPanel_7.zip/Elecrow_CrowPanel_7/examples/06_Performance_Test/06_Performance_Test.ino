/*
 * 06_Performance_Test - stability / performance soak test (Test 5)
 *
 * Runs forever:
 *  - double-buffered animation: 12 bouncing balls rendered into an off-screen
 *    LGFX_Sprite (PSRAM) and pushed to the framebuffer each frame (no flicker)
 *  - direct-draw stress: random rectangles in a side panel
 *  - continuous touch polling (touch draws into the animation)
 *  - every 5 s: FPS, frame time, heap/PSRAM (current + minimum), touch I2C
 *    error/recovery counters, uptime -> Serial and on screen
 *
 * Leave it running for hours. Watch for: falling "min internal heap" (leak),
 * rising touch errors, watchdog resets (reset reason is printed at boot),
 * corrupted pixels or image shifting (PSRAM bandwidth / PCLK too high).
 */
#include <ElecrowDisplay.h>

ElecrowDisplay display;
LGFX_Sprite canvas;  // off-screen buffer, created in PSRAM

static const int CW = 560, CH = 400;  // animation area
static const int STRESS_X = 580, STRESS_W = 210;

struct Ball { float x, y, vx, vy; int r; uint16_t c; };
Ball balls[12];

uint32_t frames = 0, frame_us_total = 0, frame_us_max = 0, report_at = 0, stress_ops = 0;
int16_t touch_x = -1, touch_y = -1;

void setup() {
  Serial.begin(115200);
  if (!display.begin()) {
    Serial.printf("init failed: %s\n", display.errorString());
    return;
  }
  Serial.printf("Reset reason: %s\n", ElecrowDiagnostics::resetReasonString());

  canvas.setColorDepth(16);
  canvas.setPsram(true);
  if (!canvas.createSprite(CW, CH)) {
    Serial.println("Sprite allocation failed (needs ~450 KB PSRAM)");
  }
  for (int i = 0; i < 12; ++i) {
    balls[i] = {(float)random(30, CW - 30), (float)random(30, CH - 30), (float)random(-60, 60) / 10.0f,
                (float)random(-60, 60) / 10.0f, (int)random(10, 30), elecrowRGB565(random(80, 255), random(80, 255), random(80, 255))};
  }
  display.clear(BLACK);
  display.setFont(&fonts::FreeSansBold12pt7b);
  display.setTextColor(WHITE, BLACK);
  display.drawText("Stability / performance test", 10, 8);
  report_at = millis() + 5000;
}

static void renderFrame() {
  canvas.fillScreen(elecrowRGB565(10, 14, 24));
  for (int i = 0; i < CW; i += 40) canvas.drawFastVLine(i, 0, CH, elecrowRGB565(25, 30, 45));
  for (int i = 0; i < CH; i += 40) canvas.drawFastHLine(0, i, CW, elecrowRGB565(25, 30, 45));
  for (Ball& b : balls) {
    b.x += b.vx;
    b.y += b.vy;
    if (b.x < b.r || b.x > CW - b.r) b.vx = -b.vx;
    if (b.y < b.r || b.y > CH - b.r) b.vy = -b.vy;
    canvas.fillCircle((int)b.x, (int)b.y, b.r, b.c);
  }
  if (touch_x >= 0) canvas.drawCircle(touch_x, touch_y, 30, WHITE);
  canvas.setFont(&fonts::Font2);
  canvas.setTextColor(WHITE);
  canvas.setCursor(6, 6);
  canvas.printf("frame %u", (unsigned)frames);
  canvas.pushSprite(&display.gfx(), 10, 40);
}

static void report() {
  const ElecrowMemoryInfo m = ElecrowDiagnostics::memory();
  const float fps = frames / 5.0f;
  const float avg_ms = frames ? frame_us_total / 1000.0f / frames : 0;
  char line1[96], line2[96], line3[96];
  snprintf(line1, sizeof(line1), "FPS %.1f  frame avg %.1f ms max %.1f ms  stress %u ops/s", fps, avg_ms,
           frame_us_max / 1000.0f, (unsigned)(stress_ops / 5));
  snprintf(line2, sizeof(line2), "heap %u (min %u)  PSRAM free %u  uptime %lus", (unsigned)m.internal_free,
           (unsigned)m.internal_min_free, (unsigned)m.psram_free, (unsigned long)(millis() / 1000));
  snprintf(line3, sizeof(line3), "touch %s  I2C errors %u  recoveries %u", display.touchAvailable() ? "OK" : "n/a",
           (unsigned)display.touch().errorCount(), (unsigned)display.touch().recoveryCount());
  Serial.println(line1);
  Serial.println(line2);
  Serial.println(line3);
  display.setFont(&fonts::Font2);
  display.setTextColor(LIGHTGRAY, BLACK);
  display.fillRectangle(0, 442, 800, 38, BLACK);
  display.drawText(line1, 10, 443);
  display.drawText(line2, 10, 461);
  display.drawTextRight(line3, 790, 461);
  frames = frame_us_total = frame_us_max = stress_ops = 0;
}

void loop() {
  if (!display.ready()) return;
  display.update();
  int16_t x, y;
  if (display.getTouch(x, y) && x >= 10 && x < 10 + CW && y >= 40 && y < 40 + CH) {
    touch_x = x - 10;
    touch_y = y - 40;
  } else {
    touch_x = -1;
  }

  const uint32_t t0 = micros();
  if (canvas.getBuffer()) renderFrame();
  const uint32_t dt = micros() - t0;
  frame_us_total += dt;
  if (dt > frame_us_max) frame_us_max = dt;
  ++frames;

  // direct-draw stress in the side panel
  display.startWrite();
  for (int i = 0; i < 20; ++i) {
    display.fillRectangle(STRESS_X + random(0, STRESS_W - 20), 40 + random(0, CH - 20), 20, 20, (uint16_t)random(0, 0xFFFF));
    ++stress_ops;
  }
  display.endWrite();

  if ((int32_t)(millis() - report_at) >= 0) {
    report();
    report_at = millis() + 5000;
  }
  // loop() returns to the Arduino core every frame, which feeds the watchdog.
}
