/*
 * 02_Touch_Test - GT911 touch verification (Test 4)
 *
 *  - live X/Y of up to 5 fingers (multi-touch), drawn as coloured dots
 *  - 5 accuracy targets (4 corners + centre): touch each, the error in pixels is shown
 *  - gesture recognition: tap, long-press, swipes (also printed on Serial)
 *  - ROTATE button cycles rotation 0..3; touch coordinates follow automatically
 *  - CLEAR button wipes the drawing
 */
#include <ElecrowDisplay.h>

ElecrowDisplay display;
ElecrowButton btnRotate, btnClear;

static const uint16_t fingerColor[5] = {YELLOW, CYAN, MAGENTA, GREEN, ORANGE};
static int16_t targetX[5], targetY[5];

static void drawScreen() {
  const int w = display.width(), h = display.height();
  display.clear(BLACK);
  display.fillRectangle(0, 0, w, 50, DARKGRAY);
  display.setFont(&fonts::FreeSansBold12pt7b);
  display.setTextColor(WHITE, DARKGRAY);
  display.drawTextf(10, 14, "Touch test  rot %u  %dx%d", display.getRotation(), w, h);

  btnRotate.setBounds(w - 250, 5, 120, 40);
  btnClear.setBounds(w - 125, 5, 120, 40);
  btnRotate.draw(display.gfx());
  btnClear.draw(display.gfx());

  // accuracy targets
  const int m = 30;
  const int16_t tx[5] = {(int16_t)m, (int16_t)(w - 1 - m), (int16_t)m, (int16_t)(w - 1 - m), (int16_t)(w / 2)};
  const int16_t ty[5] = {(int16_t)(50 + m), (int16_t)(50 + m), (int16_t)(h - 1 - m), (int16_t)(h - 1 - m), (int16_t)(h / 2)};
  for (int i = 0; i < 5; ++i) {
    targetX[i] = tx[i];
    targetY[i] = ty[i];
    display.drawCircle(tx[i], ty[i], 12, RED);
    display.drawFastHLine(tx[i] - 18, ty[i], 37, RED);
    display.drawFastVLine(tx[i], ty[i] - 18, 37, RED);
  }
}

static void showInfo(const char* text, uint16_t color) {
  display.setFont(&fonts::FreeSans12pt7b);
  display.setTextColor(color, BLACK);
  display.fillRectangle(0, 52, 520, 30, BLACK);
  display.drawText(text, 10, 56);
}

void setup() {
  Serial.begin(115200);
  if (!display.begin()) {
    Serial.printf("init failed: %s\n", display.errorString());
    return;
  }
  if (!display.touchAvailable()) Serial.println("WARNING: touch controller not found");

  btnRotate.setLabel("ROTATE");
  btnClear.setLabel("CLEAR");
  btnRotate.setFont(&fonts::FreeSansBold9pt7b);
  btnClear.setFont(&fonts::FreeSansBold9pt7b);

  display.onTouch([](const ElecrowTouchEvent& e) {
    switch (e.type) {
      case ElecrowTouchEventType::Press:   Serial.printf("press   %4d,%4d\n", e.x, e.y); break;
      case ElecrowTouchEventType::Release: Serial.printf("release %4d,%4d after %u ms\n", e.x, e.y, (unsigned)e.duration_ms); break;
      case ElecrowTouchEventType::Tap:
      case ElecrowTouchEventType::LongPress:
      case ElecrowTouchEventType::Swipe:   Serial.printf("gesture %s\n", elecrowGestureName(e.gesture)); break;
      default: break;
    }
  });
  drawScreen();
}

void loop() {
  if (!display.ready()) return;
  display.update();  // polls GT911 (rate limited)

  if (btnRotate.update(display.gfx(), display.touch())) {
    display.setRotation((display.getRotation() + 1) & 3);
    drawScreen();
    return;
  }
  if (btnClear.update(display.gfx(), display.touch())) { drawScreen(); return; }

  ElecrowTouch& t = display.touch();
  if (t.isPressed() && t.y() > 50) {
    char buf[96];
    int n = snprintf(buf, sizeof(buf), "%u pt:", t.count());
    for (uint8_t i = 0; i < t.count(); ++i) {
      const ElecrowTouchPoint& p = t.point(i);
      display.fillCircle(p.x, p.y, 3, fingerColor[i % 5]);
      if (n < (int)sizeof(buf) - 16) n += snprintf(buf + n, sizeof(buf) - n, " (%d,%d)", p.x, p.y);
    }
    // accuracy: nearest target within 40 px
    for (int i = 0; i < 5; ++i) {
      const int dx = t.x() - targetX[i], dy = t.y() - targetY[i];
      if (dx * dx + dy * dy < 40 * 40 && n < (int)sizeof(buf) - 24) {
        n += snprintf(buf + n, sizeof(buf) - n, "  target err %d px", (int)sqrtf((float)(dx * dx + dy * dy)));
      }
    }
    static uint32_t last_text = 0;
    if (millis() - last_text > 60) { last_text = millis(); showInfo(buf, WHITE); }
  }

  const ElecrowGesture g = t.gesture();
  if (g != ElecrowGesture::None) {
    char buf[48];
    snprintf(buf, sizeof(buf), "gesture: %s", elecrowGestureName(g));
    showInfo(buf, GREEN);
  }
}
