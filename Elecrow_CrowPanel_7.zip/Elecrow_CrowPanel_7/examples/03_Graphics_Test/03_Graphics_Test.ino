/*
 * 03_Graphics_Test - drawing primitives, fonts, images, icons (Test 3)
 *
 * Six pages, advanced by tapping the screen (or every 4 s):
 *   1 text: built-in fonts, sizes, datums, colours, background-filled text
 *   2 lines & rectangles & rounded rectangles & triangles
 *   3 circles, ellipses, arcs, gradient
 *   4 images: RGB565 array, 1-bit bitmap, embedded PNG (scaled), transparency
 *   5 icons + widgets (progress bar, gauge, line chart)
 *   6 screen clearing speed (fillScreen timing printed)
 */
#include <ElecrowDisplay.h>
#include "test_image.h"

ElecrowDisplay display;

// 16x16 1-bit "smiley" bitmap, MSB first (Adafruit GFX format)
static const uint8_t SMILEY[] = {0x07, 0xE0, 0x18, 0x18, 0x20, 0x04, 0x40, 0x02, 0x4C, 0x32, 0x8C, 0x31, 0x80, 0x01, 0x80, 0x01,
                                 0x80, 0x01, 0x88, 0x11, 0x44, 0x22, 0x43, 0xC2, 0x20, 0x04, 0x18, 0x18, 0x07, 0xE0, 0x00, 0x00};

static uint16_t rgbImage[64 * 64];  // generated at start-up (8 KB, internal RAM)
static uint8_t page = 0;
uint16_t fingerprintColor(int i);
static uint32_t page_start = 0;

static void title(const char* t) {
  display.clear(BLACK);
  display.fillRectangle(0, 0, display.width(), 44, NAVY);
  display.setFont(&fonts::FreeSansBold12pt7b);
  display.setTextColor(WHITE, NAVY);
  display.drawTextf(12, 12, "%u/6  %s", page + 1, t);
}

static void pageText() {
  title("Text & fonts");
  display.setTextColor(WHITE, BLACK);
  const lgfx::IFont* fontsList[] = {&fonts::Font0, &fonts::Font2, &fonts::Font4, &fonts::FreeSans12pt7b,
                                    &fonts::FreeSerifBold18pt7b, &fonts::FreeMonoBold12pt7b, &fonts::DejaVu24, &fonts::Orbitron_Light_32};
  const char* names[] = {"Font0 8px", "Font2 16px", "Font4 26px", "FreeSans 12pt", "FreeSerifBold 18pt", "FreeMonoBold 12pt",
                         "DejaVu 24", "Orbitron 32"};
  int y = 56;
  for (int i = 0; i < 8; ++i) {
    display.setFont(fontsList[i]);
    display.drawText(names[i], 20, y);
    y += display.fontHeight() + 6;
  }
  display.setFont(&fonts::Font2);
  for (int s = 1; s <= 4; ++s) {
    display.setTextSize(s);
    display.setTextColor(s & 1 ? YELLOW : CYAN, BLACK);
    display.drawTextf(470, 40 + s * s * 14, "size %d", s);
  }
  display.setTextSize(1);
  display.setFont(&fonts::FreeSansBold12pt7b);
  display.setTextColor(BLACK, ORANGE);
  display.drawTextCentered(" centred, background filled ", 600, 400);
  display.setTextColor(GREEN);
  display.drawTextRight("right aligned", 790, 440);
}

static void pageShapes() {
  title("Lines, rectangles, triangles");
  display.startWrite();
  for (int i = 0; i < 20; ++i) display.drawLine(20, 60, 20 + i * 18, 260, elecrowRGB565(255, i * 12, 0));
  display.drawWideLine(20, 300, 380, 450, 6, CYAN);
  display.drawRectangle(420, 60, 160, 100, GREEN);
  display.fillRectangle(600, 60, 180, 100, BLUE);
  display.drawRoundRectangle(420, 180, 160, 100, 20, YELLOW);
  display.fillRoundRectangle(600, 180, 180, 100, 30, MAGENTA);
  display.drawTriangle(420, 450, 500, 300, 580, 450, WHITE);
  display.fillTriangle(600, 450, 690, 300, 780, 450, ORANGE);
  display.endWrite();
}

static void pageCircles() {
  title("Circles, ellipses, arcs, gradient");
  display.startWrite();
  for (int r = 10; r < 120; r += 12) display.drawCircle(140, 200, r, elecrowRGB565(0, 255 - r * 2, r * 2));
  display.fillCircle(140, 390, 60, RED);
  display.drawEllipse(420, 140, 120, 60, YELLOW);
  display.fillEllipse(420, 300, 90, 45, GREEN);
  display.fillArc(660, 200, 60, 100, 135, 405, DARKGRAY);
  display.fillArc(660, 200, 60, 100, 135, 300, CYAN);
  display.drawArc(660, 200, 105, 110, 0, 360, WHITE);
  display.endWrite();
  display.fillGradientRect(330, 380, 460, 80, BLUE, MAGENTA);
}

static void pageImages() {
  title("Images, bitmaps, PNG");
  display.drawImage(40, 70, 64, 64, rgbImage);
  display.drawText("RGB565 array", 20, 145);
  for (int i = 0; i < 4; ++i) display.drawBitmap(220 + i * 40, 80, SMILEY, 16, 16, fingerprintColor(i));
  display.drawBitmap(220, 120, SMILEY, 16, 16, BLACK, YELLOW);
  display.drawText("1-bit bitmaps", 220, 145);
  bool ok = display.drawPng(TEST_PNG, sizeof(TEST_PNG), 460, 70);
  ok &= display.drawPng(TEST_PNG, sizeof(TEST_PNG), 520, 60, 2.0f);
  ok &= display.drawPng(TEST_PNG, sizeof(TEST_PNG), 610, 40, 4.0f);
  display.drawText(ok ? "PNG 1x 2x 4x" : "PNG decode FAILED", 460, 180);
  display.fillRectangle(40, 230, 300, 200, DARKGREEN);
  display.drawImageTransparent(60, 250, 64, 64, rgbImage, rgbImage[0]);  // corner colour = transparent
  display.drawText("transparent key", 150, 270);
  // tiled
  for (int i = 0; i < 6; ++i) display.drawImage(380 + i * 66, 300, 64, 64, rgbImage);
}

uint16_t fingerprintColor(int i) {
  const uint16_t c[] = {WHITE, YELLOW, CYAN, PINK};
  return c[i & 3];
}

static void pageWidgets() {
  title("Icons & widgets");
  const ElecrowIcon icons[] = {ElecrowIcon::Home, ElecrowIcon::Settings, ElecrowIcon::WiFi, ElecrowIcon::Battery,
                               ElecrowIcon::Check, ElecrowIcon::Close, ElecrowIcon::ArrowLeft, ElecrowIcon::ArrowRight,
                               ElecrowIcon::ArrowUp, ElecrowIcon::ArrowDown, ElecrowIcon::Plus, ElecrowIcon::Minus,
                               ElecrowIcon::Power, ElecrowIcon::Thermometer, ElecrowIcon::Drop, ElecrowIcon::Bell,
                               ElecrowIcon::Info, ElecrowIcon::Warning, ElecrowIcon::Menu, ElecrowIcon::Lightbulb};
  for (int i = 0; i < 20; ++i) {
    display.drawIcon(icons[i], 50 + (i % 10) * 75, 90 + (i / 10) * 75, 48, i % 2 ? CYAN : WHITE, BLACK, 60);
  }
  ElecrowProgressBar bar(40, 260, 340, 34);
  bar.setValue(display.gfx(), 72);
  ElecrowGauge gauge(560, 330, 100);
  gauge.setLabel("Temp", "C");
  gauge.setValue(display.gfx(), 23.6f);
  ElecrowLineChart chart(40, 320, 340, 140);
  chart.setCapacity(60);
  for (int i = 0; i < 60; ++i) chart.add(sinf(i / 6.0f) * 10 + 20);
  chart.draw(display.gfx());
}

static void pageClear() {
  title("Clear speed");
  const uint16_t colors[] = {RED, GREEN, BLUE, BLACK};
  uint32_t total = 0;
  for (uint16_t c : colors) {
    const uint32_t t = micros();
    display.clear(c);
    total += micros() - t;
  }
  display.clear(BLACK);
  display.setFont(&fonts::FreeSansBold18pt7b);
  display.setTextColor(WHITE, BLACK);
  display.drawTextf(40, 200, "fillScreen: %.2f ms average", total / 4000.0f);
  Serial.printf("fillScreen average %.2f ms\n", total / 4000.0f);
}

void setup() {
  Serial.begin(115200);
  if (!display.begin()) {
    Serial.printf("init failed: %s\n", display.errorString());
    return;
  }
  for (int y = 0; y < 64; ++y)
    for (int x = 0; x < 64; ++x) rgbImage[y * 64 + x] = elecrowRGB565(x * 4, y * 4, 255 - x * 2);
  pageText();
  page_start = millis();
}

void loop() {
  if (!display.ready()) return;
  display.update();
  if (display.justPressed() || millis() - page_start > 4000) {
    page = (page + 1) % 6;
    switch (page) {
      case 0: pageText(); break;
      case 1: pageShapes(); break;
      case 2: pageCircles(); break;
      case 3: pageImages(); break;
      case 4: pageWidgets(); break;
      case 5: pageClear(); break;
    }
    page_start = millis();
  }
}
