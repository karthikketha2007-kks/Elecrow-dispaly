/*
 * 05_Color_Test - colour verification (Test 2)
 *
 * Pages: full RED, GREEN, BLUE, WHITE, BLACK, 8 colour bars, RGB gradients,
 * fine grey ramp, checkerboard. Advance by touching the screen, or
 * automatically every 3 s. Non-blocking (millis based).
 *
 * What to look for: a wrong colour on the full-screen pages means a swapped
 * RGB data line (check ElecrowPins.h); missing shades in the gradients means
 * a dead data bit; shimmering/shifting means PCLK/timing problems.
 */
#include <ElecrowDisplay.h>

ElecrowDisplay display;

static const uint32_t AUTO_ADVANCE_MS = 3000;
static uint8_t page = 0;
static uint32_t page_start = 0;

static void label(const char* text, uint16_t fg, uint16_t bg) {
  display.setFont(&fonts::FreeSansBold18pt7b);
  display.setTextColor(fg, bg);
  display.drawTextCentered(text, display.width() / 2, display.height() - 30);
}

static void drawPage(uint8_t p) {
  const int w = display.width(), h = display.height();
  switch (p) {
    case 0: display.clear(RED);   label("RED", WHITE, RED); break;
    case 1: display.clear(GREEN); label("GREEN", BLACK, GREEN); break;
    case 2: display.clear(BLUE);  label("BLUE", WHITE, BLUE); break;
    case 3: display.clear(WHITE); label("WHITE", BLACK, WHITE); break;
    case 4: display.clear(BLACK); label("BLACK", WHITE, BLACK); break;
    case 5: {
      const uint16_t bars[8] = {WHITE, YELLOW, CYAN, GREEN, MAGENTA, RED, BLUE, BLACK};
      for (int i = 0; i < 8; ++i) display.fillRectangle(i * w / 8, 0, (i + 1) * w / 8 - i * w / 8, h, bars[i]);
      label("COLOR BARS", WHITE, BLACK);
      break;
    }
    case 6: {
      display.startWrite();
      const int band = h / 4;
      for (int x = 0; x < w; ++x) {
        const uint8_t v = (uint8_t)(x * 255 / (w - 1));
        display.drawFastVLine(x, 0, band, elecrowRGB565(v, 0, 0));
        display.drawFastVLine(x, band, band, elecrowRGB565(0, v, 0));
        display.drawFastVLine(x, band * 2, band, elecrowRGB565(0, 0, v));
        display.drawFastVLine(x, band * 3, h - band * 3, elecrowRGB565(v, v, v));
      }
      display.endWrite();
      label("GRADIENTS R/G/B/GREY", WHITE, BLACK);
      break;
    }
    case 7: {
      // 32 grey steps (one per 5-bit red/blue level)
      for (int i = 0; i < 32; ++i) {
        const uint8_t v = (uint8_t)(i * 255 / 31);
        display.fillRectangle(i * w / 32, 0, (i + 1) * w / 32 - i * w / 32, h, elecrowRGB565(v, v, v));
      }
      label("32-STEP GREY RAMP", RED, BLACK);
      break;
    }
    case 8: {
      display.startWrite();
      for (int y = 0; y < h; y += 20)
        for (int x = 0; x < w; x += 20) display.fillRectangle(x, y, 20, 20, ((x + y) / 20) & 1 ? WHITE : BLACK);
      display.endWrite();
      label("CHECKERBOARD", RED, BLACK);
      break;
    }
  }
  Serial.printf("page %u\n", p);
}

void setup() {
  Serial.begin(115200);
  if (!display.begin()) {
    Serial.printf("init failed: %s\n", display.errorString());
    return;
  }
  drawPage(page);
  page_start = millis();
}

void loop() {
  if (!display.ready()) return;
  display.update();
  const bool touched = display.justPressed();
  if (touched || millis() - page_start >= AUTO_ADVANCE_MS) {
    page = (page + 1) % 9;
    drawPage(page);
    page_start = millis();
  }
}
