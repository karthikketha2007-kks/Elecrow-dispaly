# Elecrow_CrowPanel_7

A reusable display, touch and backlight driver for the **Elecrow CrowPanel ESP32 HMI 7.0" (DIS08070H)**: an ESP32-S3-WROOM-1-N4R8 with an 800 × 480 RGB565 parallel TFT and a GT911 capacitive touch controller.

You write `display.begin()` once and then build any UI on top: text, shapes, images, icons, charts, buttons, gestures, or a full LVGL application. The library contains no project logic.

```cpp
#include <ElecrowDisplay.h>
ElecrowDisplay display;

void setup() {
  Serial.begin(115200);
  if (!display.begin()) { Serial.println(display.errorString()); return; }
  display.clear();
  display.setBrightness(255);
  display.setFont(&fonts::FreeSansBold18pt7b);
  display.drawText("SMART HOME AUTOMATION", 100, 50);
}

void loop() {
  display.update();
  if (display.touched()) Serial.printf("Touch: %d, %d\n", display.touchX(), display.touchY());
}
```

## Features

- **Display**: the RGB panel runs on the ESP32-S3 LCD_CAM peripheral through LovyanGFX. The framebuffer lives in PSRAM, and PSRAM and memory are checked before the bus starts. Rotation 0–3. The full LovyanGFX API (sprites, fonts, JPEG/PNG/BMP) is available through `display.gfx()`.
- **Touch**: built-in GT911 driver with up to 5 points, calibration, rotation-aware coordinates, tap / long-press / swipe detection, event callbacks, rate-limited non-blocking polling, and automatic I2C bus and controller recovery.
- **Board V3.0**: runs the PCA9557 touch-timing sequence from Elecrow's wiki register for register. The board revision is detected automatically.
- **Backlight**: on/off (Elecrow's behaviour) or PWM dimming, with non-blocking fades. It stays off until the panel is ready.
- **UI helpers**: 24 colours plus `elecrowRGB565()`, a theme, 20 scalable vector icons, and Button, ProgressBar, Gauge and LineChart widgets.
- **Diagnostics**: clear error codes, memory report, pin validation, I2C scan and reset reason.
- **LVGL (optional)**: adapter for LVGL 9.x and 8.3.x with Partial (double buffer, internal RAM with PSRAM fallback) or Direct (zero-copy) rendering.

## Contents

| Path | What |
|---|---|
| `src/ElecrowDisplay.h` | **Main API**. Include only this one. |
| `src/ElecrowConfig.h`, `src/ElecrowPins.h` | Configuration struct and verified pin defaults |
| `src/ElecrowRGB.*` | RGB bus / LovyanGFX device |
| `src/ElecrowTouch.*`, `src/ElecrowPCA9557.*` | GT911 driver, V3.0 expander |
| `src/ElecrowBacklight.*`, `src/ElecrowDiagnostics.*` | Backlight, diagnostics |
| `src/ElecrowGraphics.*` | Colours, icons, widgets |
| `src/ElecrowLVGL.*` | Optional LVGL adapter |
| `examples/01…09` | Init test, touch test, graphics, touch GUI, colour test, performance/stability soak, full demo, LVGL, custom config |
| `docs/` | [HARDWARE](docs/HARDWARE.md) (pinout, verification, discrepancies), [API_REFERENCE](docs/API_REFERENCE.md), [INSTALLATION](docs/INSTALLATION.md), [TROUBLESHOOTING](docs/TROUBLESHOOTING.md), [AI_INTEGRATION_GUIDE](docs/AI_INTEGRATION_GUIDE.md), [VALIDATION](docs/VALIDATION.md) |
| `extras/` | `platformio/platformio.ini` template, `lv_conf_v9.h`, `lv_conf_v8.h`, `AI_PROMPT.txt` |

## Dependencies

| | Version | |
|---|---|---|
| Arduino-ESP32 core | 3.3.x (compiled against 3.3.8) | required |
| LovyanGFX | 1.2.25 | required |
| LVGL | 9.2.2 / 9.1.0 / 8.3.11 | optional |

Arduino IDE board settings: **ESP32S3 Dev Module, PSRAM = OPI PSRAM, Flash = 4MB, Partition = Huge APP**. See [INSTALLATION.md](docs/INSTALLATION.md).

## Status

All 9 examples compile without warnings in library or example code (`-Wall -Wextra`) for ESP32-S3 with Arduino core 3.3.8. The LVGL example also compiles against LVGL 9.2.2, 9.1.0 and 8.3.11. **None of it has been run on physical hardware yet.** See [VALIDATION.md](docs/VALIDATION.md) for exactly what is verified and what is not.

## License

MIT. LovyanGFX (FreeBSD) and LVGL (MIT) are separate dependencies.
