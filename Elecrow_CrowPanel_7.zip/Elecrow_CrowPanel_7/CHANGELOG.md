# Changelog

## 1.0.0 — 2026-11-02
First release.
- RGB565 panel bring-up via LovyanGFX 1.2.25 Bus_RGB/Panel_RGB, PSRAM pre-checks
- GT911 driver: 5 points, calibration, rotation, gestures, callbacks, I2C bus recovery
- V3.0 PCA9557 touch reset sequence (register-exact copy of Elecrow's sequence), auto revision detect
- PWM / on-off backlight with non-blocking fades
- Diagnostics: memory, pin validation, I2C scan, reset reason
- Widgets: button, progress bar, gauge, line chart; 20 vector icons; colour set + theme
- Optional LVGL adapter (9.x and 8.3.x), Partial and Direct render modes
- 9 examples, docs, AI integration guide
