# AI integration guide — Elecrow CrowPanel 7.0" universal display driver

This document is written for **AI coding assistants** (Claude, ChatGPT, Gemini, Copilot, …) and for people who brief them. It is self-contained. Read it fully before writing code for this board.

---

## 0. Reusable prompt (copy this into the AI chat, then add your project requirements)

```text
You are developing a project using the Elecrow CrowPanel 7.0-inch DIS08070H ESP32-S3 display.
Use the supplied Elecrow universal display driver (Arduino library "Elecrow_CrowPanel_7").
Do not rewrite or duplicate the low-level RGB display initialization, pin configuration,
touch initialization, or framebuffer management. First inspect the driver API and integration
documentation (docs/AI_INTEGRATION_GUIDE.md and docs/API_REFERENCE.md). Use the existing driver
functions to build the requested application UI. Preserve the driver architecture and do not
change hardware pin assignments without an explicit reason.

Hard rules:
1. #include <ElecrowDisplay.h>, create exactly one global `ElecrowDisplay display;`,
   call `display.begin()` first in setup() and check its return value.
2. Call `display.update()` (or `ElecrowLVGL::handler()` when using LVGL) on every loop() pass.
   Keep loop() non-blocking: use millis() timers, never long delay().
3. Never use TFT_eSPI, Arduino_GFX, ILI9341/ST7789 drivers or SPI display code. The panel is an
   800x480 RGB565 parallel panel driven by LovyanGFX inside this library.
4. Never touch GPIO 0-9, 14-16, 21, 39-41, 45-48 (RGB bus), GPIO2 (backlight) or GPIO19/20 as
   anything but I2C. Free for the application: GPIO38 (GPIO_D, see the V1/V2 caveat), UART1
   RX44/TX43, I2S 18/42/17, microSD SPI 11/13/12/10, the I2C bus 19/20 (shared, addresses
   0x5D/0x14/0x18 are taken).
5. Colours are RGB565 uint16_t (RED, GREEN, ... or elecrowRGB565(r,g,b)).
6. Use only functions listed in docs/API_REFERENCE.md or the public LovyanGFX API via
   display.gfx(). Do not invent functions.
7. Keep application code (UI, sensors, networking) in the project; do not edit the library.
Board build settings: ESP32S3 Dev Module, PSRAM = OPI PSRAM, Flash = 4MB, Partition = Huge APP
(PlatformIO: use extras/platformio/platformio.ini from the library).

Project requirements:
<describe your project here>
```

---

## 1. Hardware identification

| | |
|---|---|
| Product | Elecrow CrowPanel ESP32 HMI 7.0-inch, module **DIS08070H** |
| MCU | ESP32-S3-WROOM-1-**N4R8** (4 MB flash, 8 MB octal PSRAM), Wi-Fi + BLE 5 |
| Display | 800 × 480, 16-bit RGB565 **parallel RGB** interface (not SPI), TN panel |
| Touch | GT911 capacitive, I2C 0x5D/0x14, 5 points |
| Board revisions | V1.0/V2.0 (no expander) and V3.0 (PCA9557 at 0x18 resets the touch). Auto-detected. |

## 2. Required libraries

- Arduino-ESP32 core **3.3.x** (compiled against 3.3.8)
- **LovyanGFX 1.2.25** (mandatory)
- **Elecrow_CrowPanel_7** (this library)
- LVGL 9.x or 8.3.x — **only** if the project uses LVGL

## 3. Includes and initialization

```cpp
#include <ElecrowDisplay.h>

ElecrowDisplay display;

void setup() {
  Serial.begin(115200);
  if (!display.begin()) {                 // does everything: PSRAM check, RGB bus,
    Serial.println(display.errorString()); // framebuffer, PCA9557 (V3.0), GT911, backlight
    return;                                // the backlight stays off on failure
  }
  display.setRotation(0);                 // optional, 0-3
  display.setBrightness(255);             // optional, 0-255
}

void loop() {
  display.update();                       // touch polling + backlight fades
  // application logic using millis() timers
}
```

Custom settings: `ElecrowConfig cfg = ElecrowConfig::defaults(); cfg.rotation = 1; display.begin(cfg);`. Change pins or timing only with a documented reason.

## 4. Display API summary

```cpp
display.clear(BLACK);                       display.fillScreen(c);
display.setFont(&fonts::FreeSansBold18pt7b); display.setTextSize(1);
display.setTextColor(WHITE, BLACK);          // bg colour = flicker-free value updates
display.drawText("Temp", x, y);             display.drawTextf(x, y, "%.1f C", t);
display.drawTextCentered("Title", cx, cy);  display.drawTextRight("12:00", right_x, y);
display.drawPixel/ drawLine/ drawWideLine/ drawRectangle/ fillRectangle/
        drawRoundRectangle/ fillRoundRectangle/ drawCircle/ fillCircle/
        drawEllipse/ fillEllipse/ drawTriangle/ fillTriangle/ drawArc/ fillArc/
        fillGradientRect(...)
display.drawImage(x, y, w, h, rgb565_array); display.drawBitmap(x, y, bits, w, h, color);
display.drawJpg(buf, len, x, y);            display.drawPng(buf, len, x, y, scale);
display.drawIcon(ElecrowIcon::WiFi, cx, cy, 32, WHITE);
display.width(); display.height();          // logical size after rotation
display.startWrite(); ... display.endWrite(); // batch many draws
display.gfx()                               // full LovyanGFX device (sprites etc.)
```

Widgets (draw into `display.gfx()` or a sprite): `ElecrowButton`, `ElecrowProgressBar`, `ElecrowGauge`, `ElecrowLineChart`. `ElecrowTheme` holds a colour palette.

## 5. Touch API summary

```cpp
if (display.touched()) { int x = display.touchX(), y = display.touchY(); }
int16_t x, y; if (display.getTouch(x, y)) { ... }
display.touchedIn(x, y, w, h);              // pressed inside a rectangle
display.justPressed(); display.justReleased();  // edge events (consumed)
switch (display.gesture()) { case ElecrowGesture::SwipeLeft: ...; }   // Tap, LongPress, Swipe*
display.onTouch([](const ElecrowTouchEvent& e){ /* e.type, e.x, e.y, e.gesture */ });
ElecrowButton b(20, 20, 160, 60, "OK");  b.draw(display.gfx());
if (b.update(display.gfx(), display.touch())) { /* clicked */ }
display.touch().count(); display.touch().point(i);   // multi-touch (<=5)
```

Touch coordinates are already in screen coordinates for the current rotation.

## 6. LVGL integration

```cpp
#include <lvgl.h>
#include <ElecrowDisplay.h>
#include <ElecrowLVGL.h>
ElecrowDisplay display;
void setup() {
  display.begin();
  ElecrowLVGL::begin(display);       // registers display (flush) + GT911 (pointer) + tick
  lv_obj_t* l = lv_label_create(lv_screen_active());
  lv_label_set_text(l, "Hello");
}
void loop() { ElecrowLVGL::handler(); delay(5); }
```

- LVGL 9.x (preferred) or 8.3.x. `LV_COLOR_DEPTH 16` is required, plus `LV_COLOR_16_SWAP 0` on LVGL 8.
- PlatformIO: use `[env:lvgl9]` from `extras/platformio/platformio.ini`. Arduino IDE: copy `extras/lv_conf_v9.h` to `libraries/lv_conf.h`.
- SquareLine Studio: export for LVGL 8.3 or 9.x at 800×480, 16-bit colour, call `ui_init()` after `ElecrowLVGL::begin()`, and do not use the display/touch code SquareLine generates.
- Once LVGL runs, draw only with LVGL. `display.drawX()` output would be overwritten.

## 7. Peripheral pin conflicts

| Resource | Status |
|---|---|
| RGB bus GPIO 0,1,3,4,5,6,7,8,9,14,15,16,21,39,40,41,45,46,47,48 | **Reserved by the driver** |
| GPIO2 | Backlight, reserved |
| GPIO19/20 (I2C) | Shared bus. The driver starts `Wire` at 400 kHz. Add your sensors with `Wire` (same pins, do not call `Wire.begin()` with other pins). Taken addresses: 0x5D, 0x14, 0x18. |
| GPIO38 (GPIO_D) | Free on V3.0 (possibly linked to touch INT through R57). On **V1.0/V2.0 it is the GT911 INT line**, so do not drive it there. |
| UART1 44/43, I2S 18/42/17, SD 11/13/12/10 | Free; the driver never touches them |
| GPIO 26-37 | Flash and octal PSRAM, never usable |
| BOOT button | Same pin as PCLK, so it cannot be used as an input |

## 8. Memory considerations

- The framebuffer uses 768,000 bytes of PSRAM (allocated by `begin()`). Call `display.begin()` before Wi-Fi, LVGL or large allocations.
- About 7.2 MB of PSRAM remains for the application: images, sprites (`LGFX_Sprite::setPsram(true)`), LVGL objects.
- Internal RAM is precious (Wi-Fi/BLE need about 60–100 KB). LVGL draw buffers fall back to PSRAM automatically when internal RAM is short.
- Keep large `const` image arrays in flash (`static const uint16_t img[] = {...}`). They are drawn directly from flash.
- Avoid `String` concatenation in loops; use `snprintf` into a stack buffer.

## 9. Example project structure

```text
MyProject/
├── platformio.ini            (copied from library extras/platformio/platformio.ini)
├── lib/
│   └── Elecrow_CrowPanel_7/  (this library, unmodified)
├── include/
│   ├── app_config.h          (Wi-Fi credentials, thresholds)
│   └── ui_theme.h            (ElecrowTheme, fonts, layout constants)
└── src/
    ├── main.cpp              (setup/loop: display.begin(), scheduler)
    ├── ui_screens.cpp/.h     (page drawing + touch handling, uses ElecrowDisplay API)
    ├── sensors.cpp/.h        (sensor reading on millis() timers)
    └── network.cpp/.h        (Wi-Fi/MQTT/HTTP)
```

Pattern for a multi-page UI (see `examples/07_Full_Demo`):

- `enum Page` with `showPage(p)`, which clears the content area and draws static elements.
- `loop()`: `display.update()`, then periodic timers update only the values that changed (text with a background colour), then the touch handlers for the current page only.

## 10. Common errors and solutions

| Error | Solution |
|---|---|
| `PSRAM not found` | Enable OPI PSRAM (Arduino Tools menu / `qio_opi` in PlatformIO). |
| `GT911 touch controller not found` | See TROUBLESHOOTING.md. The display still works; `display.touchAvailable()` is false. |
| Text smears when a number changes | Use `setTextColor(fg, bg)` and pad strings (`"%5.1f"`). |
| Flicker during animation | Draw into an `LGFX_Sprite` in PSRAM, then `pushSprite()`. |
| Touch mirrored after rotation | Rotate only with `display.setRotation()`, never `display.gfx().setRotation()`. |
| `'RED' was not declared` clash with another library | Define `ELECROW_NO_GLOBAL_COLORS` and use `ElecrowColor::RED`. |
| Compile error about `fonts::` | Use `&fonts::FreeSans12pt7b` (with `&`). The font list is in LovyanGFX `lgfx_fonts.hpp`. |
| Sketch too big | Partition "Huge APP (3MB)". Big fonts and images take flash. |
| Calling `Wire.begin(…)` with other pins breaks touch | The I2C bus is fixed to 19/20. Reuse `Wire` as is. |

## 11. Checklist for the AI before delivering code

- [ ] One `ElecrowDisplay display;`, `begin()` checked, no other display library.
- [ ] `loop()` calls `display.update()` or `ElecrowLVGL::handler()` and never blocks.
- [ ] No reserved GPIO used. I2C devices share `Wire` on 19/20.
- [ ] Only documented functions used.
- [ ] Values redrawn with a background colour; static parts drawn once.
- [ ] Board settings documented: OPI PSRAM, 4 MB, Huge APP.
