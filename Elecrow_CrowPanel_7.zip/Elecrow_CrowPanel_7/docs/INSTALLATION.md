# Installation

## Dependencies

| Library | Version | Required? | Why |
|---|---|---|---|
| Arduino-ESP32 core | **3.3.8** (compiled and checked). 3.x expected to work. 2.0.x code paths exist but were **not compiled** here. | yes | ESP32-S3 support |
| LovyanGFX (lovyan03) | **1.2.25** (upstream, unpatched) | yes | RGB bus, framebuffer, graphics, fonts, image decoders |
| LVGL | 9.2.2 recommended; 9.1.0 and 8.3.11 also compiled | optional | Only if you include `ElecrowLVGL.h` |

There are no other dependencies. The GT911 and PCA9557 drivers are built in, so you do **not** need TAMC_GT911 or the PCA9557 library.

Do not install a second display library that also drives this panel (TFT_eSPI, Arduino_GFX with an RGB panel, …) in the same sketch.

## Arduino IDE (2.x)

1. **Board package**: Boards Manager → "esp32 by Espressif Systems" → install **3.3.x**.
2. **LovyanGFX**: Library Manager → "LovyanGFX" → install **1.2.25**.
3. **This library**: Sketch → Include Library → Add .ZIP Library… → select `Elecrow_CrowPanel_7.zip`. You can also copy the `Elecrow_CrowPanel_7` folder into `<sketchbook>/libraries/`.
4. **Tools menu** (these are required):

| Setting | Value |
|---|---|
| Board | ESP32S3 Dev Module |
| PSRAM | **OPI PSRAM** |
| Flash Size | **4MB (32Mb)** |
| Flash Mode | QIO 80MHz |
| Partition Scheme | Huge APP (3MB No OTA/1MB SPIFFS) — or "Default 4MB with spiffs" if you need OTA and the sketch fits |
| CPU Frequency | 240MHz (WiFi) |
| USB CDC On Boot | Disabled (the USB-C port is a CH340 UART, not native USB) |
| Upload Speed | 921600 (use 460800 if uploads fail) |

5. Open File → Examples → Elecrow_CrowPanel_7 → `01_Display_Test`, upload, and open the Serial Monitor at **115200**.

**LVGL with the Arduino IDE:** install "lvgl" from the Library Manager. Copy `extras/lv_conf_v9.h` (LVGL 9) or `extras/lv_conf_v8.h` (LVGL 8) to `<sketchbook>/libraries/lv_conf.h`, next to the `lvgl` folder, not inside it. Then open `08_LVGL_Integration`.

## PlatformIO

1. Copy `extras/platformio/platformio.ini` into your project root.
2. Put this library in `<project>/lib/Elecrow_CrowPanel_7/`, or add it to `lib_deps` (`symlink:///path/to/Elecrow_CrowPanel_7` or a git URL).
3. `pio run -t upload -t monitor`

The template has three environments: `crowpanel7` (graphics only), `lvgl9` and `lvgl8`. LVGL is configured with `-D` flags (`LV_CONF_SKIP`), so no `lv_conf.h` is needed.

These lines are what make the board work. Do not drop them:

```ini
board = esp32-s3-devkitc-1
board_build.arduino.memory_type = qio_opi   ; octal PSRAM
board_build.psram_type = opi
board_upload.flash_size = 4MB
board_upload.maximum_size = 4194304
board_build.partitions = huge_app.csv
build_flags = -DBOARD_HAS_PSRAM
```

The template uses the pioarduino platform 55.03.38 (Arduino core 3.3.8), the same one Elecrow's V3.0 PlatformIO example uses. The official `platformio/espressif32` platform still ships Arduino core 2.0.x, which this library was not compiled against.

## ESP-IDF

The library is an Arduino library (it uses `Wire`, `Print`, `millis`). Use it under ESP-IDF as an **Arduino-as-component** project (arduino-esp32 3.x component with LovyanGFX as another component). A pure ESP-IDF build without the Arduino component is not supported.

## Minimal sketch

```cpp
#include <ElecrowDisplay.h>
ElecrowDisplay display;

void setup() {
  Serial.begin(115200);
  if (!display.begin()) { Serial.println(display.errorString()); return; }
  display.setFont(&fonts::FreeSansBold18pt7b);
  display.drawText("Hello CrowPanel", 40, 40);
}

void loop() {
  display.update();
  if (display.touched()) display.fillCircle(display.touchX(), display.touchY(), 4, YELLOW);
}
```
