# API reference — Elecrow_CrowPanel_7 v1.0.0

One header is enough for most projects:

```cpp
#include <ElecrowDisplay.h>   // display + touch + backlight + widgets + colours
ElecrowDisplay display;       // one global instance
```

All colours are **RGB565 `uint16_t`**. All coordinates are **logical** (they follow `setRotation()`). Every drawing call is a no-op if `begin()` failed, so a failed init never crashes the sketch.

---

## 1. Lifecycle — `ElecrowDisplay`

| Function | Description |
|---|---|
| `bool begin()` | Initialize with verified defaults. Returns `false` on error. A second call returns the first result without re-initializing. |
| `bool begin(const ElecrowConfig& cfg)` | Initialize with a custom configuration (see §8). |
| `void update()` | Call from `loop()`. Polls touch (rate-limited, non-blocking) and advances backlight fades. |
| `bool ready()` | `true` after a successful `begin()`. |
| `ElecrowError error()` / `const char* errorString()` | Why `begin()` failed (§9). |
| `ElecrowBoardRevision boardRevision()` / `boardRevisionString()` | `V1_V2` or `V3` (auto-detected). |
| `bool touchAvailable()` | GT911 found and working. |
| `void printDiagnostics(Print& out = Serial)` | Chip, memory, pins, panel, touch status and an I2C scan. |
| `const ElecrowConfig& config()` | The configuration in use. |

`begin()` order: backlight OFF → validate pins → I2C → detect revision → PCA9557 touch reset (V3.0) → PSRAM check → RGB bus + framebuffer → clear → GT911 → backlight ON.

## 2. Screen

| Function | Description |
|---|---|
| `int32_t width()`, `int32_t height()` | Logical size (800×480, or 480×800 when rotated 1/3). |
| `void setRotation(uint8_t r)` / `uint8_t getRotation()` | 0, 1, 2, 3 = 0°, 90°, 180°, 270°. 4–7 = mirrored variants. Touch follows automatically. |
| `void setBrightness(uint8_t)` / `uint8_t getBrightness()` | 0 = off, 255 = full (digital HIGH), 1–254 = PWM. |
| `void setBackgroundColor(uint16_t)` / `backgroundColor()` | Colour used by `clear()`. |
| `void clear()` / `void clear(uint16_t color)` / `void fillScreen(uint16_t)` | Fill the whole screen. |
| `void startWrite()` / `void endWrite()` | Batch many drawing calls (one cache write-back at `endWrite()`). |
| `void flush()` | Force the cache write-back. Normally not needed. |

Drawing is immediate. The panel scans the PSRAM framebuffer continuously, and LovyanGFX writes the CPU cache back after each call. There is no "present" step. For animation without flicker, draw into an `LGFX_Sprite` and push it (see §7 and `06_Performance_Test`).

## 3. Text

| Function | Description |
|---|---|
| `setFont(const lgfx::IFont*)` | e.g. `&fonts::FreeSansBold18pt7b`, `&fonts::DejaVu24`, `&fonts::Font4`; `nullptr` = default 8 px font. |
| `setTextSize(float)` / `setTextSize(float sx, float sy)` | Scale factor. Bitmap fonts look best at integer sizes. |
| `setTextColor(uint16_t fg)` | Transparent background. |
| `setTextColor(uint16_t fg, uint16_t bg)` | Fills behind glyphs, so redrawing a changing value does not smear. |
| `setTextDatum(lgfx::textdatum_t)` | Anchor point, e.g. `lgfx::textdatum_t::middle_center`, `top_right`. |
| `setTextWrap(bool)`, `setCursor(x, y)` | For `print()`. |
| `int32_t drawText(const char*/String, x, y)` | Draw at (x, y) using the current datum. Returns width in px. |
| `int32_t drawTextCentered(text, cx, cy)` | Centred on (cx, cy). |
| `int32_t drawTextRight(text, right_x, y)` | Right-aligned. |
| `int32_t drawTextf(x, y, fmt, ...)` | printf-style (max 255 chars). |
| `int32_t textWidth(text)`, `int32_t fontHeight()` | Measure text. |
| `print()`, `println()`, `printf()` | `ElecrowDisplay` is an Arduino `Print`; text goes to the cursor. |

Fonts: every LovyanGFX font is available under `fonts::` (FreeSans/Serif/Mono 9–24 pt incl. Bold/Oblique, DejaVu 9–72, Orbitron, Font0/2/4/6/7/8, efont CJK, …).

## 4. Primitives

| Function | Notes |
|---|---|
| `drawPixel(x, y, c)` | |
| `drawLine(x0, y0, x1, y1, c)` | |
| `drawWideLine(x0, y0, x1, y1, width, c)` | Anti-aliased thick line. |
| `drawFastHLine(x, y, w, c)`, `drawFastVLine(x, y, h, c)` | |
| `drawRectangle(x, y, w, h, c)`, `fillRectangle(x, y, w, h, c)` | |
| `drawRoundRectangle(x, y, w, h, r, c)`, `fillRoundRectangle(...)` | |
| `drawCircle(x, y, r, c)`, `fillCircle(x, y, r, c)` | |
| `drawEllipse(x, y, rx, ry, c)`, `fillEllipse(...)` | |
| `drawTriangle(x0, y0, x1, y1, x2, y2, c)`, `fillTriangle(...)` | |
| `drawArc(x, y, r0, r1, a0, a1, c)`, `fillArc(...)` | Ring between radii r0–r1. Degrees: 0 = 3 o'clock, clockwise. |
| `fillGradientRect(x, y, w, h, top, bottom)` | Vertical gradient. |

## 5. Images

| Function | Notes |
|---|---|
| `drawImage(x, y, w, h, const uint16_t* data, bool byte_swapped = false)` | RGB565 array, little-endian (LVGL image converter, most tools). Set `byte_swapped` for big-endian (TFT_eSPI-style) arrays. |
| `drawImageTransparent(x, y, w, h, data, transparent, byte_swapped = false)` | Skips pixels equal to `transparent`. |
| `drawBitmap(x, y, bmp, w, h, fg)` / `(..., fg, bg)` | 1-bit, MSB first, rows padded to bytes (Adafruit GFX / image2cpp format). Use for icons. |
| `drawXBitmap(x, y, bmp, w, h, fg)` | 1-bit XBM (LSB first). |
| `bool drawJpg(data, len, x = 0, y = 0, scale = 1.0f)` | JPEG from memory (flash or PSRAM). |
| `bool drawPng(data, len, x = 0, y = 0, scale = 1.0f)` | PNG from memory. |
| `bool drawBmp(data, len, x = 0, y = 0)` | BMP from memory. |
| `drawIcon(ElecrowIcon, cx, cy, size, color, bg = 0, value = -1)` | Built-in vector icon (§6). |

From an SD card or LittleFS, use LovyanGFX directly: include `<SD.h>` **before** `<ElecrowDisplay.h>`, then `display.gfx().drawJpgFile(SD, "/photo.jpg", x, y);`.

## 6. Colours, icons and widgets — `ElecrowGraphics.h`

**Colours** (global, or `ElecrowColor::NAME` if you define `ELECROW_NO_GLOBAL_COLORS`):
`BLACK WHITE RED GREEN BLUE YELLOW CYAN MAGENTA ORANGE GRAY/GREY DARKGRAY LIGHTGRAY NAVY DARKGREEN DARKCYAN MAROON PURPLE OLIVE PINK BROWN GOLD SKYBLUE VIOLET`

- `constexpr uint16_t elecrowRGB565(r, g, b)` — your own colour from 8-bit components.
- `uint16_t elecrowBlend565(a, b, alpha)` — mix two colours (alpha 0 = a, 255 = b).
- `ElecrowTheme` — a set of UI colours (`background, surface, primary, accent, warning, danger, text, text_muted, border`).

**Icons** (`ElecrowIcon::`): `Home Settings WiFi Battery Check Close ArrowLeft ArrowRight ArrowUp ArrowDown Plus Minus Power Thermometer Drop Bell Info Warning Menu Lightbulb`. They scale to any size. `Battery` takes `value` = 0–100.

Widgets draw into any `lgfx::LovyanGFX&`: pass `display.gfx()` for the screen, or a sprite.

| Class | Key methods |
|---|---|
| `ElecrowButton(x, y, w, h, label)` | `setLabel`, `setIcon`, `setTheme`, `setColors(fill, text, border, pressed_fill)`, `setFont`, `setRadius`, `setToggle(bool)`, `state()`, `setEnabled`, `draw(g)`, `contains(x, y)`, **`bool update(g, display.touch())`** returns `true` once per click (press and release inside). Any number of buttons can share one touch controller. |
| `ElecrowProgressBar(x, y, w, h)` | `setRange(min, max)`, `setColors(bar, track, border)`, `showPercent(bool)`, `setValue(g, v, force = false)` (redraws only on change). |
| `ElecrowGauge(cx, cy, r)` | `setRange`, `setLabel(label, unit)`, `setDecimals`, `setColors(arc, track, text, bg)`, `setValue(g, v, force = false)`. |
| `ElecrowLineChart(x, y, w, h)` | `setCapacity(n ≤ 200)`, `setRange(min, max)` (equal values = autoscale), `setColors(line, bg, grid)`, `add(v)`, `draw(g)`. Fixed ring buffer, no heap use. |

## 7. Direct access to the sub-drivers

| Accessor | Type | Use it for |
|---|---|---|
| `display.gfx()` | `ElecrowLGFX&` (a `lgfx::LGFX_Device`) | The full LovyanGFX API: sprites, `drawJpgFile`, smooth fonts, `pushImage` variants, `readRect`, … |
| `display.touch()` | `ElecrowTouch&` | Multi-touch, gestures, calibration, statistics |
| `display.backlight()` | `ElecrowBacklight&` | `fadeTo(level, ms)` (non-blocking), `on()`, `off()` |
| `display.rgb()` | `ElecrowRGB&` | `framebuffer()`, `framebufferBytes()`, `refreshRate()` |
| `display.expander()` | `ElecrowPCA9557&` | V3.0 expander registers (advanced) |

Off-screen double buffering:

```cpp
LGFX_Sprite canvas(&display.gfx());
canvas.setColorDepth(16);
canvas.setPsram(true);
canvas.createSprite(400, 300);        // check the return value
canvas.fillScreen(BLACK);
canvas.drawString("frame", 10, 10);
canvas.pushSprite(200, 100);          // one copy, no flicker
```

## 8. Touch — `ElecrowTouch` (also through `ElecrowDisplay` shortcuts)

| Shortcut on `display` | Same on `display.touch()` | Description |
|---|---|---|
| `touched()` | `touched()` | Poll, then `true` while pressed |
| `touchX()`, `touchY()` | `x()`, `y()` | First point (logical coordinates) |
| `getTouch(x, y)` | `getPoint(x, y)` | Poll; `true` plus coordinates if pressed |
| `touchCount()` | `count()`, `point(i)` | Number of points (≤ 5); `ElecrowTouchPoint{x, y, size, id}` |
| `touchedIn(x, y, w, h)` | `inArea(...)` | Pressed inside a rectangle |
| `justPressed()`, `justReleased()` | same | Edge events, consumed when read |
| `gesture()` | `gesture()` | `ElecrowGesture::{None, Tap, LongPress, SwipeLeft, SwipeRight, SwipeUp, SwipeDown}`, consumed when read |
| `onTouch(cb)` | `onEvent(cb)` | `void cb(const ElecrowTouchEvent& e)` with `e.type` = `Press/Move/Release/Tap/LongPress/Swipe`, `e.gesture`, `e.x/y`, `e.start_x/y`, `e.duration_ms`, `e.points`. Runs inside `update()`, never in an interrupt. |

More on `display.touch()`: `isPressed()`, `startX()/startY()`, `pressDuration()`, `update()` (returns `true` when a new sample was read), `setCalibration(xmin, xmax, ymin, ymax, swap, invX, invY)`, `readRaw(rx, ry)`, `ready()`, `address()`, `productId()`, `controllerWidth()/Height()`, `errorCount()`, `recoveryCount()`, `lastError()`, `recover()`.

Rules: the controller is read at most every `poll_interval_ms` (10 ms default), so call any of these as often as you like. After `errors_before_recovery` consecutive I2C failures the driver clears the bus, re-initializes I2C, replays the V3.0 reset and re-probes (at most once per `recovery_interval_ms`; this blocks about 150 ms).

`elecrowGestureName(g)` returns `"tap"`, `"swipe-left"`, and so on.

## 9. Configuration — `ElecrowConfig` (see `ElecrowConfig.h` for every field)

```cpp
ElecrowConfig cfg = ElecrowConfig::defaults();
cfg.rotation = 1;
cfg.log_level = ElecrowLogLevel::Warning;
cfg.touch.wire = &Wire1;
display.begin(cfg);
```

| Group | Fields (default) |
|---|---|
| top level | `width` 800, `height` 480, `rotation` 0, `revision` Auto, `pca9557_address` 0x18, `clear_on_begin` true, `clear_color` 0, `backlight_on_begin` true, `require_touch` false, `log` &Serial, `log_level` Info |
| `rgb` | `data[16]`, `de` 41, `vsync` 40, `hsync` 39, `pclk` 0 |
| `timing` | `pclk_hz` 15 000 000, porches/polarities per HARDWARE.md §3, `refreshRate(w, h)` |
| `touch` | `enabled` true, `wire` &Wire, `sda` 19, `scl` 20, `i2c_freq` 400 000, `address` 0 (auto), `int_pin` −1, `poll_interval_ms` 10, `release_timeout_ms` 0 (off), `use_controller_resolution` true, `raw_*`, `swap_xy/invert_x/invert_y` false, `long_press_ms` 600, `tap_max_ms` 400, `move_tolerance_px` 12, `swipe_min_distance_px` 80, `swipe_max_ms` 800, `errors_before_recovery` 5, `recovery_interval_ms` 1000 |
| `backlight` | `pin` 2, `pwm` true, `pwm_freq` 300, `pwm_resolution` 8, `pwm_channel` 7 (core 2.x only), `initial_brightness` 255 |

## 10. Errors — `ElecrowError`

`None, NotInitialized, AlreadyInitialized, InvalidConfig, InvalidPin, PinConflict, NoPSRAM, PSRAMTooSmall, FramebufferAllocFailed, RGBInitFailed, I2CInitFailed, PCA9557NotFound, TouchNotFound, TouchCommFailed, OutOfMemory, LVGLInitFailed` — `elecrowErrorString(e)` gives a sentence that includes the fix.

## 11. Diagnostics — `ElecrowDiagnostics` (static)

`memory()` → `ElecrowMemoryInfo{psram_found, psram_total, psram_free, psram_largest_block, internal_free, internal_min_free, internal_largest_block, dma_free}`, `printMemory(out)`, `printSystemInfo(out)`, `resetReasonString()`, `i2cScan(wire, out)`, `i2cProbe(wire, addr)`, `i2cBusClear(sda, scl)`, `isUsableOutputPin(pin)`, `validatePins(cfg)`, `printPinMap(out, cfg)`, `setLog(out, level)`. Log macros: `ELECROW_LOGE/W/I/D(fmt, ...)`.

## 12. LVGL adapter — `ElecrowLVGL.h` (optional)

```cpp
#include <lvgl.h>
#include <ElecrowDisplay.h>
#include <ElecrowLVGL.h>
display.begin();
ElecrowLVGL::begin(display);           // or begin(display, cfg)
// build UI with LVGL
loop(): ElecrowLVGL::handler();        // instead of lv_timer_handler()
```

| Member | Description |
|---|---|
| `static bool begin(ElecrowDisplay&, const ElecrowLVGLConfig& = {})` | `lv_init()` if needed, then creates the display, buffers, tick and touch input device. Call after `display.begin()` / `setRotation()`. |
| `static uint32_t handler()` | Runs LVGL timers (and the tick on LVGL 8 without `LV_TICK_CUSTOM`). Returns ms until next run. |
| `static bool setRotation(uint8_t)` | Rotates panel, touch and LVGL together (Partial mode). |
| `ready()`, `bufferBytes()`, `buffersInPSRAM()`, `mode()`, `lvDisplay()`, `lvInput()` | Status and handles. |

`ElecrowLVGLConfig`: `mode` (`Partial` default / `Direct`), `buffer_lines` 40, `double_buffer` true, `prefer_internal_ram` true, `min_internal_free` 65536, `enable_touch` true.

Supported: LVGL 9.x (compiled with 9.1.0 and 9.2.2) and 8.3.x (compiled with 8.3.11). Requires `LV_COLOR_DEPTH 16` and, on LVGL 8, `LV_COLOR_16_SWAP 0` (enforced with `#error`).
