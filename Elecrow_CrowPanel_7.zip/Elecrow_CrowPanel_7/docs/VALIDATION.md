# Validation status — v1.0.0

## What was verified

### Compilation (done, 2026-11-02)

Toolchain: PlatformIO, pioarduino platform 55.03.38, **Arduino-ESP32 core 3.3.8** (ESP-IDF 5.5), xtensa-esp-elf GCC 14.2. Board `esp32-s3-devkitc-1` with `qio_opi`, 4 MB flash, `huge_app.csv`, `-DBOARD_HAS_PSRAM -Wall -Wextra`. LovyanGFX 1.2.25 from its git tag.

| Build | Result | RAM (static) | Flash |
|---|---|---:|---:|
| 01_Display_Test | ✅ | 25.3 KB | 460 KB |
| 02_Touch_Test | ✅ | 25.4 KB | 471 KB |
| 03_Graphics_Test | ✅ | 33.5 KB | 518 KB |
| 04_Touch_GUI_Test | ✅ | 25.7 KB | 479 KB |
| 05_Color_Test | ✅ | 25.3 KB | 451 KB |
| 06_Performance_Test | ✅ | 25.9 KB | 458 KB |
| 07_Full_Demo | ✅ | 28.2 KB | 510 KB |
| 08_LVGL_Integration, LVGL 9.2.2 (-D config) | ✅ | 91.4 KB | 689 KB |
| 08_LVGL_Integration, LVGL 9.1.0 (-D config) | ✅ | 91.4 KB | 664 KB |
| 08_LVGL_Integration, LVGL 8.3.11 (-D config) | ✅ | 75.9 KB | 655 KB |
| 08_LVGL_Integration, LVGL 9.2.2 + `extras/lv_conf_v9.h` | ✅ | 25.9 KB | 688 KB |
| 08_LVGL_Integration, LVGL 8.3.11 + `extras/lv_conf_v8.h` | ✅ | 26.7 KB | 654 KB |
| 09_Custom_Config | ✅ | 25.3 KB | 457 KB |

Warnings in library or example code: **0**. The remaining warnings come from the Arduino core and LovyanGFX headers (`-Wmissing-field-initializers`).

(The RAM difference between the LVGL builds is LVGL's built-in 64 KB / 48 KB memory pool. The supplied lv_conf files use the system heap instead.)

### Desk checks against the official sources (done)

- All 20 RGB/sync pins and the backlight pin compared with the net names in the V3.0 Eagle schematic.
- I2C pins, PCA9557 address pins (A0–A2 → GND = 0x18) and PCA9557 IO0/IO1 → TP-RESET/INTE checked in the schematic.
- The PCA9557 sequence compared operation by operation with Elecrow's `PCA9557` library source (`reset()`, `setMode()`, `setState()`).
- GT911 register usage compared with Elecrow's V3.0 PlatformIO `touch.h`.
- Rotation inverse transform derived from LovyanGFX `Panel_FrameBufferBase::drawPixelPreclipped()`.
- LovyanGFX `Bus_RGB` config field names and framebuffer allocation read from the 1.2.25 source.
- Panel timing compared with the LCD datasheet LI0704122Z (see HARDWARE.md D1/D2).

## What was NOT verified

| Item | Status |
|---|---|
| **Running on a physical CrowPanel 7.0"** | **Not done.** No code was flashed or run on hardware. Every behaviour below is unverified until you run the examples. |
| Arduino IDE build | Not run (Arduino's download servers were unreachable from the build machine). The same core and compiler were used through PlatformIO, and the sketches avoid patterns that depend on Arduino's prototype generator. |
| Arduino-ESP32 core 2.0.x | Not compiled. The core-2.x LEDC code path exists but is untested. |
| The registry `lib_deps` lines in `extras/platformio/platformio.ini` | The PlatformIO registry was unreachable; compilation used identical versions from git. |
| Live Elecrow wiki page | Not re-fetched (elecrow.com blocked by network policy); the copy pasted in the request was used. |
| Backlight PWM dimming linearity / flicker | The boost driver's EN-pin PWM response was not checked against its datasheet. 0 and 255 reproduce Elecrow's digital on/off exactly. |
| PCLK above 15 MHz with the single-buffer upstream LovyanGFX | Untested; see HARDWARE.md D1. |
| LVGL Direct mode | Compiles. Cache write-back per flushed area is implemented but not observed on hardware. |
| GT911 behaviour while a finger is held still (continuous reporting) | Taken from the GT911 programming model. `release_timeout_ms` is off by default so a still long-press cannot be cut short. |
| Touch recovery path | Compiles. It needs a real fault (e.g. briefly shorting SDA) to exercise. |

## Hardware test plan (please run, in this order)

1. `01_Display_Test`: all status lines green, the serial report shows the board revision and GT911 found.
2. `05_Color_Test`: correct full-screen colours, smooth gradients, no missing grey steps.
3. `02_Touch_Test`: dots follow the finger, all 5 targets under ~10 px error, ROTATE through 0–3 keeps touch aligned, swipes and long-press recognised.
4. `03_Graphics_Test`, `04_Touch_GUI_Test`: visual check; the brightness buttons dim the backlight.
5. `06_Performance_Test`: leave it running for at least 2 h. Note FPS, check that `min heap` is stable and touch errors stay at 0, and watch for no resets or image drift.
6. `07_Full_Demo`, `08_LVGL_Integration`: navigation, swipe, slider-controlled backlight.
7. Optional: repeat 5 with `cfg.timing.pclk_hz = 24000000` to decide the PCLK question (D1).

Report results (including the serial output of `printDiagnostics()`) so the defaults can be confirmed or adjusted.
