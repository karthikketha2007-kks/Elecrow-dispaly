# Hardware reference and verification report

Board: **Elecrow CrowPanel ESP32 HMI 7.0" — module DIS08070H** (PCB name WZ8048C070)

| Item | Value |
|---|---|
| MCU module | ESP32-S3-WROOM-1-N4R8: 4 MB quad flash, 8 MB **octal** PSRAM, 240 MHz dual core |
| Panel | 7.0" TN TFT, 800 × 480, LCD module LI0704122Z, driver ICs EK9716BD3 + EK73002ACGB |
| Interface | RGB565 parallel (16 data lines + DE/HSYNC/VSYNC/PCLK), DE mode |
| Touch | GT911 capacitive, I2C, up to 5 points |
| Backlight | Single LED string, boost constant-current driver, EN on GPIO2 (active HIGH) |
| Supply | 5 V / 2 A (USB-C or header); Li-ion battery connector with charger |

## 1. Sources and how each value was verified

| Source | Where | Used for |
|---|---|---|
| Elecrow wiki page `esp32-display-7-0-inch.html` | Pasted by the user into the request. **elecrow.com was not reachable from the build machine (network policy), so the live page was not re-fetched**; the pasted copy was used. | LGFX bus config, pin table, V3.0 PCA9557 sequence |
| Elecrow GitHub `Elecrow-RD/CrowPanel-7.0-HMI-ESP32-Display-800x480` (cloned 2026-11-01) | `example/V3.0/Arduino/Course/*`, `example/V3.0/PlatformIO70/*`, `example/V1.0_and_V2.0/Arduino/*` | Working init order, PCLK, PCA9557 address/sequence, GT911 registers, library versions |
| Eagle schematics V2.0 (2023-12-04) and V3.0 (2024-04-20) in the same repo | Parsed the `.sch` XML net list | Every RGB / I2C / backlight / touch net, PCA9557 address pins, GPIO38 wiring |
| LCD datasheet `Datasheet/LI0704122Z(800480-RGB)_specification.pdf` | Section 6.4.3 timing table | Allowed PCLK range and porch values |
| `Eagle_SCH&PCB/V3.0/readme.md` | A hardware guide in the repo (its header says it was written by an AI tool, 2026-07-29) | Treated as secondary only; every value taken from it was re-checked against the schematic |
| LovyanGFX 1.2.25 source | `src/lgfx/v1/platforms/esp32s3/Bus_RGB.*`, `Panel_RGB.*`, `panel/Panel_FrameBufferBase.*` | Config field names, framebuffer allocation, rotation maths, cache write-back |

## 2. Pin map (defaults in `src/ElecrowPins.h`)

### RGB bus — all 20 lines match the V3.0 schematic net names

| RGB565 bit | GPIO | Schematic net | Note |
|---|---:|---|---|
| B0 | 15 | IO15_B3 | |
| B1 | 7 | IO7_B4 | |
| B2 | 6 | IO6_B5 | |
| B3 | 5 | IO5_B6 | |
| B4 | 4 | IO4_B7 | |
| G0 | 9 | IO9_G2 | |
| G1 | 46 | IO46_G3 | strapping pin |
| G2 | 3 | IO3_G4 | strapping pin (JTAG select) |
| G3 | 8 | IO8_G5 | |
| G4 | 16 | IO16_G6 | |
| G5 | 1 | IO1_G7 | |
| R0 | 14 | IO14_R3 | |
| R1 | 21 | IO21_R4 | |
| R2 | 47 | IO47_R5 | |
| R3 | 48 | IO48_R6 | |
| R4 | 45 | IO45_R7 | strapping pin (VDD_SPI) |
| DE | 41 | IO41_DE | |
| VSYNC | 40 | IO40_VSYNC | |
| HSYNC | 39 | IO39_HSYNC | |
| PCLK | 0 | IO0_BOOT_CLK | **also the BOOT button** |
| Backlight EN | 2 | IO2_LCD_BL_CTR | to boost driver EN |

The schematic labels the data lines B3–B7 / G2–G7 / R3–R7 because the FPC is a 24-bit connector and only the top bits are wired. In RGB565 terms they are B0–B4 / G0–G5 / R0–R4. Your prompt and the wiki use the RGB565 names; they are the same wires.

### Other interfaces (the display driver never initializes these)

| Function | GPIO | Notes |
|---|---|---|
| I2C SDA / SCL | 19 / 20 | Shared by GT911, PCA9557 (V3.0), the I2C header and the GPIO_D header. 4.7 kΩ pull-ups on board. |
| GPIO_D | 38 | See conflict D5 below |
| UART1 header RX / TX | 44 / 43 | UART0 is the USB-C CH340 port |
| I2S LRCLK / BCLK / SDIN | 18 / 42 / 17 | NS4168 amplifier, speaker connector |
| microSD MOSI / MISO / CLK / CS | 11 / 13 / 12 / 10 | SPI |
| Not available | 26–32 (flash), 33–37 (octal PSRAM), 22–25 (do not exist) | Rejected by `ElecrowDiagnostics::isUsableOutputPin()` |

### I2C addresses

| Device | Address | Evidence |
|---|---|---|
| GT911 | 0x5D (INT low at reset) or 0x14 (INT high) | Elecrow PIO code uses 0x5D; the driver tries both |
| PCA9557 (V3.0 only) | 0x18 | V3.0 schematic: A0 = A1 = A2 = GND; Elecrow library `DEV_ADDR = 0x18` |

### PCA9557 ports (V3.0 schematic)

| Port | Net | Used by Elecrow code |
|---|---|---|
| IO0 | TP-RESET → GT911 RESET | yes |
| IO1 | INTE → GT911 INT | yes |
| IO2 | LCD-RESET (through optional R59) | no |
| IO3 | LCD-POWER-C (through optional R60) | no |
| IO4–IO7 | not connected | no |

## 3. RGB timing

| Parameter | Driver default | Wiki and your prompt | Elecrow V3.0 examples | LCD datasheet (typ.) |
|---|---:|---:|---:|---:|
| PCLK | **15 MHz** | 15 MHz | **24 MHz** | **33.3 MHz (min 20, max 50)** |
| HSYNC polarity | 0 | 0 | 0 | — |
| H front porch | 40 | 40 | 40 | 40 |
| H pulse width | 48 | 48 | 48 | 48 |
| H back porch | 40 | 40 | 40 | 40 |
| VSYNC polarity | 0 | 0 | 0 | — |
| V front porch | 1 | 1 | 1 | **13** |
| V pulse width | 31 | 31 | 31 | **1** |
| V back porch | 13 | 13 | 13 | **31** |
| pclk_active_neg | 1 | 1 | 1 | — |
| de_idle_high | 0 | 0 | 0 | — |
| pclk_idle_high | 0 | 0 | 0 | — |

Frame rate = PCLK / ((800+40+48+40) × (480+1+31+13)) = PCLK / 487,200, so about **30.8 Hz at 15 MHz** and **49.3 Hz at 24 MHz**.

## 4. Discrepancies found (none of them change the defaults without your decision)

| ID | Topic | What the sources say | What the driver does |
|---|---|---|---|
| D1 | **PCLK** | The wiki and the V1.0/V2.0 example use 15 MHz. Both V3.0 examples (Arduino and PlatformIO) use **24 MHz**. The LCD datasheet gives **20–50 MHz, typ. 33.3 MHz**, so 15 MHz is below the panel's specified minimum. | Keeps **15 MHz**, as your prompt instructs. Change it with `cfg.timing.pclk_hz = 24000000`. Elecrow's 24 MHz is paired with a patched LovyanGFX that double-buffers. This driver uses upstream LovyanGFX with one PSRAM framebuffer, so if you raise PCLK, run `06_Performance_Test` and watch for image drift while PSRAM is busy. |
| D2 | Vertical porches | Elecrow uses front/pulse/back = 1/31/13. The datasheet's typical values are 13/1/31. The total is 45 lines either way. | Keeps Elecrow's values. The panel runs in DE mode (MODE pin), where only DE marks valid data, which is why the order does not matter in practice. Not changed because Elecrow's values are proven on hardware. |
| D3 | PCA9557 address | The header comment in Elecrow's PCA9557 library says 0x41. Its code and the schematic say **0x18**. | Uses 0x18 (configurable via `cfg.pca9557_address`). |
| D4 | PCA9557 port modes | The wiki/Arduino sequence calls `setMode(IO_OUTPUT)`, which makes **all 8 ports outputs** (IO2 LCD-RESET and IO3 LCD-POWER-C are then driven HIGH from the reset latch). Elecrow's own PlatformIO V3.0 code configures **only IO0/IO1** as outputs. | Reproduces the wiki/Arduino sequence register for register (`ElecrowPCA9557::resetTouchV3()`), because that is the documented one and the one in your prompt. |
| D5 | **GPIO38 / GPIO_D is shared with touch INT** | V2.0 schematic: the GT911 INT pin (touch FPC pin 4) is wired **directly to IO38**, which is also the GPIO_D header. V3.0 moves INT to PCA9557 IO1 but keeps **R57 between INTE and IO38** (whether R57 is fitted is not visible in the files). | The driver never touches GPIO38. On V1.0/V2.0, driving GPIO38 from your application fights the GT911 INT output, and its level at reset picks the GT911 address. The driver tries both 0x5D and 0x14 for that reason. Treat GPIO_D as "use with care". |
| D6 | V1.0/V2.0 touch reset | The GT911 RESET is tied to the ESP32 EN line through R40. Software cannot reset it. | On V1/V2, touch recovery is bus-level only (I2C bus clear + re-init + re-probe). On V3.0 recovery also replays the PCA9557 reset. |
| D7 | Touch coordinate mapping | The Arduino example uses TAMC_GT911 with `ROTATION_NORMAL` (inverts) plus `map(800→0, 480→0)` (inverts again), so the result is the identity. The PlatformIO example uses raw GT911 values directly. | Uses raw coordinates as native panel pixels, scaled by the X/Y resolution read from the GT911 config (0x8048). Manual calibration, swap and invert are available. |
| D8 | Touch library | Elecrow uses TAMC_GT911 1.0.2 (Arduino) or hand-written register code (PlatformIO). | Own register-level GT911 driver using the same registers as Elecrow's PlatformIO code. No extra dependency. |
| D9 | Library versions | The repo readme lists LVGL 8.3.3. The V3.0 examples use LVGL 9.1.0, a bundled LovyanGFX 1.2.21, and a patched LovyanGFX 1.2.25 (adds `presentFrameBuffer()`). | Depends on **unpatched LovyanGFX 1.2.25**. LVGL is optional; 9.1.0, 9.2.2 and 8.3.11 were compiled. |
| D10 | Wiki "2 × UART0" | The pin table puts the UART header on IO44/IO43, which is **UART1**. UART0 is the USB-C / CH340 port. | Documented as UART1. |
| D11 | Backlight | V3.0 code drives GPIO2 as a plain digital HIGH. Older code used LEDC PWM at 300 Hz / 8 bit. | Brightness 255 = digital HIGH (Elecrow's behaviour), 0 = LOW, 1–254 = LEDC PWM at 300 Hz (configurable). The PWM response of the boost driver's EN pin was **not** verified against its datasheet. |
| D12 | I2C peripheral | The Elecrow PlatformIO example uses `Wire1` and re-initializes it after `lcd.begin()`. The Arduino example uses `Wire`. No reason is documented. | Uses `Wire` by default; set `cfg.touch.wire = &Wire1` to move it. |
| D13 | Reset-pin comment | `touch.h` has `TOUCH_GT911_RST -1//38`. | GPIO38 is not the touch reset on any revision. Ignored. |

## 5. Board revisions

| Revision | How to tell | Touch reset / INT | Driver behaviour |
|---|---|---|---|
| V1.0 | No PCA9557 | RESET tied to EN, INT on GPIO38 | `ElecrowBoardRevision::V1_V2`, no reset sequence |
| V2.0 | No PCA9557 (adds auto-download circuit) | same as V1.0 | same |
| V3.0 | PCA9557 answers at 0x18 | RESET = PCA9557 IO0, INT = PCA9557 IO1 | runs the PCA9557 sequence before the RGB bus starts |

`ElecrowBoardRevision::Auto` (the default) probes 0x18. You can force a revision in the config.

## 6. Memory

| Buffer | Size | Location |
|---|---|---|
| RGB framebuffer (scanned out by GDMA) | 800 × 480 × 2 = **768,000 B** | PSRAM (must be one contiguous block) |
| Framebuffer line table | 480 × 4 = 1,920 B | internal DMA RAM |
| GDMA descriptors | ~190 × 12 B | internal DMA RAM |
| LVGL draw buffers (optional, Partial mode) | 2 × 800 × 40 × 2 = 128,000 B (default) | internal RAM if at least 64 KB stays free, otherwise PSRAM |
| LVGL Direct mode | 0 extra | renders into the framebuffer |
| Full-screen `LGFX_Sprite` (optional, for double buffering) | 768,000 B | PSRAM |

`begin()` checks `psramFound()` and the largest free PSRAM block **before** it starts the bus, because LovyanGFX's `Bus_RGB::init()` does not check its own allocation.

## 7. Electrical and safety notes (from the schematic)

- **GPIO0** is PCLK *and* the BOOT button. Do not hold BOOT while the display runs, and do not use it as an application button.
- **GPIO45, GPIO46, GPIO3** are strapping pins used as RGB outputs. Do not load them externally.
- The LCD bias rails reach about +18 V (VGH), −8 V (VGL) and +10 V (AVDD). Do not probe the FPC carelessly.
- The speaker output (NS4168) is differential. Never ground either SPK terminal.
- Use a real 5 V / 2 A supply. Brown-outs show up as `reset reason: brownout` in `printDiagnostics()`.
