# Troubleshooting

Start every investigation with `display.printDiagnostics(Serial);` at 115200 baud. It prints the reset reason, PSRAM and heap, the pin map, panel timing, touch status and an I2C scan.

## Init failures (`display.begin()` returns false)

| `errorString()` | Cause | Fix |
|---|---|---|
| PSRAM not found | PSRAM not enabled in the build | Arduino: Tools → PSRAM → **OPI PSRAM**. PlatformIO: `board_build.arduino.memory_type = qio_opi` and `-DBOARD_HAS_PSRAM`. |
| not enough free PSRAM for the framebuffer | Something allocated large PSRAM blocks before `begin()` | Call `display.begin()` first in `setup()`, before Wi-Fi, LVGL, sprites or big buffers. |
| invalid GPIO / same GPIO used twice | A custom `ElecrowConfig` pin is wrong | Read the log lines above the error. GPIO 26–37 are flash/PSRAM and cannot be used. |
| RGB panel / LCD_CAM init failed | LCD_CAM or GDMA already in use, or a broken custom config | Make sure no other display library starts the RGB bus. |

## Display problems

| Symptom | Likely cause | What to do |
|---|---|---|
| Backlight on, screen black | `begin()` failed (backlight should then be off), or you draw before `begin()` | Check `display.ready()` and the Serial log. |
| Screen stays dark, log says ready | Backlight brightness 0, or GPIO2 reused by your code | `display.setBrightness(255)`. Do not touch GPIO2. |
| Colours wrong (red shows as blue, …) | Pin order changed in a custom config | Use `ElecrowConfig::defaults()`. Run `05_Color_Test`. |
| Missing shades or banding in gradients | One RGB data line not driven (bad custom pin, damaged FPC) | `05_Color_Test` page 7 shows which bit is missing. |
| Image shifts sideways, rolls or jitters, mostly during heavy drawing or Wi-Fi | PSRAM bandwidth: GDMA cannot fetch the framebuffer in time | Keep PCLK at 15 MHz (default). Avoid flash writes or large PSRAM memcpy during display. Draw big scenes into a sprite and push once. Do not raise CPU load with tight PSRAM loops. |
| Flicker in some lighting, or panel looks unstable | PCLK 15 MHz is below the LCD datasheet minimum of 20 MHz (see HARDWARE.md, D1) | Try `cfg.timing.pclk_hz = 24000000` (Elecrow's V3.0 value) and run `06_Performance_Test` for a while. |
| Flicker while animating | Drawing directly into the scanned framebuffer (single buffer) | Render into an `LGFX_Sprite` (PSRAM) and `pushSprite()`, as in `06_Performance_Test`. |
| Tearing in LVGL Direct mode | Single framebuffer, no vsync swap | Use Partial mode (default). |
| Short white flash at power-on | Backlight enabled before the panel had data | The driver keeps the backlight off until `begin()` finishes. Make sure your code does not drive GPIO2 earlier. |
| Upload fails or board stuck in download mode | GPIO0 (PCLK) is the BOOT button | Do not hold BOOT. Press RESET after upload if needed. On V1.0 boards hold BOOT, press RESET, then upload. |

## Touch problems

| Symptom | Likely cause | What to do |
|---|---|---|
| "GT911 touch controller not found" | V3.0 reset sequence not run, bus problem, or a damaged FPC | Check that the log says `board revision detected: V3.0` on V3 boards. Run `ElecrowDiagnostics::i2cScan(Wire, Serial)`: you should see 0x5D (or 0x14) and 0x18 on V3. Unplug I2C/GPIO_D accessories and retry. |
| Touch works for a while, then stops (V3.0) | The issue Elecrow fixed with the PCA9557 timing control | The driver already runs the V3.0 sequence and recovers automatically. Check `touch().recoveryCount()` and `errorCount()`. |
| Touch coordinates mirrored or swapped | Rotation set on `gfx()` directly instead of `display.setRotation()`, or a panel variant with a different GT911 config | Always rotate with `display.setRotation()`. If raw axes really differ, use `display.touch().setCalibration(0, 799, 0, 479, swap, invX, invY)`. |
| Touch offset by a few pixels | GT911 config resolution does not match the panel | Use `02_Touch_Test` targets to measure, then `setCalibration()` with measured raw min/max. |
| Touch dead when an I2C sensor is plugged in | Address clash or overloaded pull-ups | GT911 = 0x5D/0x14, PCA9557 = 0x18. Avoid devices on those addresses. Long cables plus extra pull-ups can break 400 kHz, so try `cfg.touch.i2c_freq = 100000`. |
| Touch dead on V1.0/V2.0 after using GPIO_D (GPIO38) | GPIO38 is the GT911 INT line on V1/V2 | Do not drive GPIO38 on V1/V2 boards, or keep it as an input. |
| Callbacks never fire | `update()` not called | Call `display.update()` (or `touched()`, `getTouch()`) every loop iteration. |
| Buttons react to touches that started elsewhere | — | By design they do not. `ElecrowButton` only reacts to touches that start inside it. |

## LVGL problems

| Symptom | Fix |
|---|---|
| `#error "ElecrowLVGL needs LV_COLOR_DEPTH 16"` | Set `LV_COLOR_DEPTH 16` in lv_conf.h, or `-DLV_COLOR_DEPTH=16`. |
| `#error "... LV_COLOR_16_SWAP 0"` | LVGL 8: set `LV_COLOR_16_SWAP 0`. The RGB panel takes native little-endian RGB565. |
| `lvgl.h: No such file` | Install LVGL. Include `<lvgl.h>` before `<ElecrowLVGL.h>` in the sketch. |
| `lv_font_montserrat_28` undefined | Enable it: `LV_FONT_MONTSERRAT_28 1` (or `-DLV_FONT_MONTSERRAT_28=1`). |
| UI frozen | Call `ElecrowLVGL::handler()` in `loop()`. Do not block `loop()` for long. |
| Out of memory when creating many objects | LVGL 9: use `LV_USE_STDLIB_MALLOC LV_STDLIB_CLIB` (as in `extras/lv_conf_v9.h`). LVGL 8: `LV_MEM_CUSTOM 1`. The system heap can then use PSRAM. |
| Drawing with `display.drawX()` disappears | LVGL owns the screen and redraws over it. Use LVGL objects, or an `lv_canvas`. |
| Wi-Fi fails to start after LVGL begin | Internal RAM used by the draw buffers. Set `ElecrowLVGLConfig::buffer_lines = 20`, or `prefer_internal_ram = false`. |

## Stability / watchdog

- Never put long `delay()`s or busy loops in `loop()`. All driver calls are non-blocking, except automatic touch recovery (about 150 ms, at most once per second).
- Task watchdog resets during heavy drawing usually mean a very long `startWrite()` batch in a loop that never returns. Return from `loop()` regularly.
- `brownout` reset reason: the supply cannot deliver the backlight plus Wi-Fi peak current. Use 5 V / 2 A.
- Watch `internal_min_free` in `06_Performance_Test`. If it keeps falling over hours, the application leaks memory (the driver allocates nothing after `begin()`).
